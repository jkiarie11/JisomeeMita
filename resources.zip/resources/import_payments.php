<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Payments Reconciliation</title>
<link rel="stylesheet" href="./jquery-ui-1.10.4/themes/base/jquery.ui.all.css">

<script src="./jquery-ui-1.10.4/jquery-1.10.2.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.core.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.widget.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.datepicker.js"></script>
        
        <script>
	$(function() {
		$( "#datepicker" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
  $( "#datepickerto" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
	});
	</script>
  
 
</head>
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:900px;align:center;}
#disc{position:relative; left:5px; top:2px; border:1px solid  #CCCCFF;width:890px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}


</style>
  
<style>
.labels{
position:absolute;
margin-left:100px;
margin-top:2px;
margin-bottom:2px;


}

.required { background-color:#FF0 }

.labels2{
position:absolute;
margin-left:600px;
margin-top:2px;
margin-bottom:2px;




}

#label{
position:relative;
margin-left:10px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#label2{
position:relative;
margin-left:400px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-top:200px;
margin-left:20px;
margin-right:550px;
height:500px;

}



#new_acc_fieldset1{

/*margin:10px,100px,10px,100px;*/
margin-left:25px;
margin-right:400px;
margin-bottom:400px;
margin-top:0px;
border:0;

}



#test{
margin-left:200px;
height:25px;
margin-top:150px;
}



#validator{
border:5px ridge  #FFFFFF; left:2px; width:800px; height:200px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:170px; position:absolute;

padding:5px;
background-color:#FF6633;



}
#communication{
border:5px ; left:1px; width:800px; height:500px;  border-radius:5px; top:262px; position:absolute;

padding:5px;




}

#reading{
border:2px ; left:3px; width:440px;  top:539px; position:absolute;






}

#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:3px; position:absolute;
margin-left:0px;
margin-right:0px;
top:230px;
left:100px;
width:800px;

}


         
       
</style>


<?php

function test_req($key, $default = '') {
    if(isset($_POST[$key]) and
       !empty($_POST[$key])) {
        return $_POST[$key];
    } else {
        return $default;
    }
}
//echo htmlentities(test_req('my_field'))

//echo 'onetwothree';

$result = "";
$content= "";
$error="";


$national_id="";
$phone_no=0;
$postal_address="";
$land_reg="";
$street="";
$gps_coord="";
$meter_route_no=0;
$email="";
$meter_nosss= "";
$loan_amount=0;
$repayment_period= 0;
$logged_in='ADMIN';//until we get the correct user from logon window









 
 


		
		
?>	


<div id="disciplinary">

 <input type="submit"  name="test" id="test" style="visibility:hidden"  value="Update data"  />






</table>
</fieldset>
</div>



     



<div id="working_csv">
<?php



 global $file_full_path;
function get_file_extension($file_name) {
    return end(explode('.',$file_name));
}
 
function errors($error){
    if (!empty($error))
    {
            $i = 0;
            while ($i < count($error)){
            $showError.= '<div class="msg-error">'.$error[$i].'</div>';
            $i ++;}
            return $showError;
    }// close if empty errors
} // close function


function process_dir($dir,$recursive = FALSE) {
    
    global $file_path;
    
    echo 'file path is '.$file_path;
  
    if (is_dir($dir)) {
      for ($list = array(),$handle = opendir($dir); (FALSE !== ($file = readdir($handle)));) {
          $p++;
         
        if (($file != '.' && $file != '..') && (file_exists($path = $dir.'/'.$file))) {
            
          if (is_dir($path) && ($recursive)) {
            $list = array_merge($list, process_dir($path, TRUE));
            
          } else {
            $entry = array('filename' => $file, 'dirpath' => $dir);
            

                
                 

            $entry['modtime'] = filemtime($path);

            do if (!is_dir($path)) {
 
                $entry['size'] = filesize($path);
                if (strstr(pathinfo($path,PATHINFO_BASENAME),'csv')) {
                  
                 
                  if (!$entry['handle'] = fopen($path,r)) $entry['handle'] = "FAIL";
                  $ls_file = substr($path,strlen($path)-16,16);
                 
                  $file_path[$p]=$path;
                  echo 'file path is '.$file_path[$p].'<BR>';
                
                }
 
 
                break;
            } else {
 
              break;
            } while (FALSE);
            $list[] = $entry;
          }
        }
      }
      closedir($handle);
      return $list;
    } else return FALSE;
  }//end function
  
  
 






if(isset($_POST['upfile'])){
 
if (!$error){

$logged_in = "'Admin On ".date("d/m/y")."'";
 
$tot = 0;
$handle = fopen($_FILES["uploaded"]["tmp_name"], "r");
//paste below here
while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
    for ($c=0; $c < 1; $c++) {
	
			
           
            //only run if the first column if not equal to firstname
            if($data[0] !='Account Holder:' && $data[0] !='Short Code:' && $data[0] !='Account:' && $data[0] !='Time Period:' && $data[0] !='Receipt No.' && $data[0] !='Operator:'){
	      //echo "SELECT transaction_id FROM safaricom_payments where transaction_id = '".$data[0]."'<BR>";
            
	      $result = mysql_query("SELECT transaction_id FROM safaricom_payments where transaction_id = '".$data[0]."'");
	     
	      $num_rows = mysql_num_rows($result);
	     
	   //  echo "account no is $data[0] and number offf rows is $num_rows <BR>";
	      
	      
	      if($num_rows==0){
		
		
		  if (substr($data[1],0,4)=='2015') {
		 
	//	     $ls_transaction_date='';
		   $ls_initiation_date=$data[1];
		  
		    $ls_transaction_details = $data[2];
		    $ls_transaction_status = $data[3];
		    $ld_paid_in = $data[5];
		    $ld_withdrawn = $data[4];
		    $ld_balance = $data[6];
		    $ls_transction_type = $data[8];
		    $ls_other_info = $data[9];
		}
			
		 else {
			if (strlen($data[1])==14) {
			  $ls_transaction_date=substr($data[1], 4, 4).'/'.substr($data[1],2,1).'/'.substr($data[1],0,1).' '. substr($data[1], 9);
			  $ls_initiation_date=substr($data[2], 4, 4).'/'.substr($data[1],2,1).'/'.substr($data[1],0,1).' '. substr($data[1], 9);
			}
			if (strlen($data[1])==15) {
			  $ls_transaction_date=substr($data[1], 5, 4).'/'.substr($data[1],3,1).'/'.substr($data[1],0,2).' '. substr($data[1], 10);
			  $ls_initiation_date=substr($data[2], 5, 4).'/'.substr($data[1],3,1).'/'.substr($data[1],0,2).' '. substr($data[1], 10);
			}
			if (strlen($data[1])==19) {
			  $ls_transaction_date=substr($data[1], 6, 4).'/'.substr($data[1],3,2).'/'.substr($data[1],0,2).' '. substr($data[1], 11);
			  $ls_initiation_date=substr($data[2], 6, 4).'/'.substr($data[1],3,2).'/'.substr($data[1],0,2).' '. substr($data[1], 11);
			}
			
			$ls_transaction_details = $data[3];
			$ls_transaction_status = $data[4];
			$ld_paid_in = $data[5];
			$ld_withdrawn = $data[6];
			$ld_balance = $data[7];
			$ls_transaction_type = $data[8];
			$ls_other_info = $data[9];
			
			
		}
            
           
           
     /**      echo "REPLACE INTO safaricom_payments(
	      transaction_id,transaction_date,initiation_time,transaction_details,
	      transaction_status, paid_in,  withdrawn,
	      balance ,    transaction_type ,  other_party_info                )VALUES(
	      '".mysql_real_escape_string($data[0])."',
	      '".$ls_transaction_date."',
	      '".$ls_initiation_date."',
	      '".$ls_transaction_details."',
	      '".$ls_transaction_status."',
	      '".$ld_paid_in."',
	      '".$ld_withdrawn."',
	      '".$ld_balance."',
	      '".$ls_transaction_type."',
	      '".$ls_other_info."'	

	      )";*/

	    mysql_query("REPLACE INTO safaricom_payments(
	      transaction_id,transaction_date,initiation_time,transaction_details,
	      transaction_status, paid_in,  withdrawn,
	      balance ,    transaction_type ,  other_party_info                )VALUES(
	      '".mysql_real_escape_string($data[0])."',
	      '".$ls_transaction_date."',
	      '".$ls_initiation_date."',
	      '".$ls_transaction_details."',
	      '".$ls_transaction_status."',
	      '".$ld_paid_in."',
	      '".$ld_withdrawn."',
	      '".$ld_balance."',
	      '".$ls_transaction_type."',
	      '".$ls_other_info."'	

	      )" )or die(mysql_error());
                
             
              
              $tot++;
              $ls_date = $data[1];
              
              } //endif of num_rows
               
            }//endif of if data
 
    } //endfor of for
  // echo 'file full path is '.$file_full_path;
    
}  //endwhile of fgetcsv




fclose($handle);




if($tot> 0) {
$content.= "<div class='success' id='message'> CSV File Imported, $tot records updated </div>";
}
else {
  $content.= "<div class='success' id='message'> File Already Imported, No Data To Import </div>";
 }
}// end no error
}//close if isset upfile




 
$er = errors($error);
$content.= <<<EOF
<h3>Import CSV Data</h3>
$er
<form enctype="multipart/form-data" action="" method="post">
    File:<input name="uploaded" type="file" maxlength="80" /><input type="submit" name="upfile" left="30px" width = 500 value="Upload File" '<BR>'>
     <label for="label"  class="label" title="Account Name"> Date :
          </label>
           <input type="text" name="datefrom" id="datepicker" value=$ls_date />
            />
           
           
</form>
EOF;
echo $content;
?>

</div>

