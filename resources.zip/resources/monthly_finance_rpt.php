<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>All Payments</title>
<link rel="stylesheet" href="./jquery-ui-1.10.4/themes/base/jquery.ui.all.css">
<script src="./jquery-ui-1.10.4/jquery-1.10.2.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.core.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.widget.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.datepicker.js"></script>
        
        <script>
	$(function() {
		$( "#datepicker" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
  $( "#datepickerto" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
	});
	</script>
</head>
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:900px;align:center;}
#disc{position:relative; left:5px; top:2px; border:1px solid  #CCCCFF;width:890px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}


</style>
<div id="active_accounts">
<fieldset><legend>Monthly Financial Report</legend>
 <form method="post" action="#" >
  
  
		<label for="label"  class="search" title="Account Name"> From :
          </label>
           <input type="text" name="datefrom" id="datepicker" value="<?php  echo $search_value_from; ?>"   />
    
    &nbsp;&nbsp; &nbsp;&nbsp;
    <label for="label"  class="search" title="Account No"> To :
          </label>
     <input type="text" name="dateto" id="datepickerto" value="<?php  echo $search_value_to; ?>"  />
     <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
      <input type="submit"  name="export_data" id="export_btns"  value="Export"  /><br><br/>   
		
      </form>

<div id="disciplinary">

<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>Month</th><th>Readings Count</th><th>Readings Amount</th><th>Invoice Amount</th><th>Water Collection</th><th>Loan Collection</th><th>Total Collection</th></tr>
<?php 


    
     $search_value_from=mysql_real_escape_string($_POST['datefrom']);
        $search_value_to=mysql_real_escape_string($_POST['dateto']);
        $date_from=substr($search_value_from,6,4).'-'.substr($search_value_from,3,2).'-'.substr($search_value_from,0,2);
        $date_to=substr($search_value_to,6,4).'-'.substr($search_value_to,3,2).'-'.substr($search_value_to,0,2);
       // echo $date_from;
     //   echo $date_to;

    $i=0;
    
  if (strlen($date_from) > 2) {
  $querynn=  "SELECT concat(monthname(reading_date),' - ',year(reading_date)) reading_month,count(*) count_readings,sum(amount) reading_amount,
(SELECT  sum(amount) FROM `invoice` where (month(periodbegin) = month(reading_date) and year(periodbegin) = year(reading_date)) and monthly_invoice = 1)
invoice_amount,
(SELECT  sum(amount) FROM `payment` where (month(date) = month(reading_date) and year(date) = year(reading_date)) and payment_for in (1,3)) water_collection,
(SELECT  sum(amount) FROM `payment` where (month(date) = month(reading_date) and  year(date) = year(reading_date)) and payment_for in (2)) loan_collection,
(SELECT  sum(amount) FROM `payment` where (month(date) = month(reading_date) and  year(date) = year(reading_date))) total_collection
FROM account_reading where  month(reading_date) between month('$date_from') and month('$date_to') group by  concat(monthname(reading_date),' - ',year(reading_date)) order by reading_date ";
  //   $querynn="select distinct 	acc_no, customer_name, phone_no,phone_no2,phone_no3 from account_details where entry_time between '$date_from' and  '$date_to' and account_status = 'inactive' ";
 //echo $querynn;
 }
else {
   // $querynn="select distinct 	acc_no, customer_name, phone_no,phone_no2,phone_no3 from account_details where account_status = 'inactive'";
    $querynn = "SELECT concat(monthname(reading_date),' - ',year(reading_date)) reading_month,count(*) count_readings,sum(amount) reading_amount,
(SELECT  sum(amount) FROM `invoice` where (month(periodbegin) = month(reading_date) and year(periodbegin) = year(reading_date)) and monthly_invoice = 1)
invoice_amount,
(SELECT  sum(amount) FROM `payment` where (month(date) = month(reading_date) and year(date) = year(reading_date)) and payment_for in (1,3)) water_collection,
(SELECT  sum(amount) FROM `payment` where (month(date) = month(reading_date) and year(date) = year(reading_date)) and payment_for in (2)) loan_collection,
(SELECT  sum(amount) FROM `payment` where (month(date) = month(reading_date)  and year(date) = year(reading_date))) total_collection
FROM account_reading group by  concat(monthname(reading_date),' - ',year(reading_date))  order by reading_date";
}
 
 //echo $querynn;
 
 $resultss = mysql_query($querynn);
 
 if(isset($_POST['export_data'])){
    
   
    
   

    // Pick a filename and destination directory for the file
    // Remember that the folder where you want to write the file has to be writable
    $filename = "/tmp/monthly_financial_export_".time().".csv";

    // Actually create the file
    // The w+ parameter will wipe out and overwrite any existing file with the same name
    $handle = fopen($filename, 'w+');

    // Write the spreadsheet column titles / labels
    fputcsv($handle, array('Reading Month','Reading Count','Reading Amount','Invoice Amount','Water Collection','Loan Collection','Total Collection'));

    

    // Finish writing the file
  //  fclose($handle);
    
    //exit;
}   

if(isset($_POST['search_account'])||isset($_POST['export_data'])){
    
  
			

    while($rows=mysql_fetch_array($resultss)){
        $reading_month=$rows['reading_month'];
        $reading_amount=$rows['reading_amount'];
        $total_reading+=$reading_amount;
        $reading_amount = number_format($reading_amount);
        
       
        $reading_count=$rows['count_readings'];
       
        $invoice_amount=$rows['invoice_amount'];
        $total_invoice+=$invoice_amount;
        $invoice_amount = number_format($invoice_amount);
       
        
        $water_collection=$rows['water_collection'];
        $total_water+=$water_collection;
        $water_collection = number_format($water_collection);
        $loan_collection=$rows['loan_collection'];
        $total_loan+=$loan_collection;
        $loan_collection = number_format($loan_collection);
       
        
        $total_collection=$rows['total_collection'];
        $total_net+=$total_collection;
        $total_collection = number_format($total_collection);
        
        
       
         if(isset($_POST['export_data'])){
           fputcsv($handle, array($reading_month, $reading_count,$reading_amount,$invoice_amount, $water_collection, $loan_collection,$total_collection));  
         }

        $i++;  
                                
                        
                                
                                 
                                
                                         

 ?>
 <style>
 .btn{
 margin:0px;
 

 
 </style>
<tr bgcolor="#CCCCCC"><td><?php echo $reading_month;?> </td><td><?php echo $reading_count; ?></td><td><?php echo $reading_amount; ?></td><td><?php echo $invoice_amount;  ?></td><td><?php echo $water_collection;  ?></td><td><?php echo  $loan_collection;?></td><td><?php echo  $total_collection;?></td><?php
                          

			 
 }
 
    $total_reading = number_format($total_reading);
    $total_invoice = number_format($total_invoice);
    $total_water = number_format($total_water);
    $total_loan = number_format($total_loan);
    $total_net = number_format($total_net);
			
}

 // Finish writing the file
    fclose($handle);

?>
<tr bgcolor="#CCCCCC"><td><?php echo ''; ?></td><td><?php echo '';  ?></td><td><?php echo $total_reading;  ?></td><td><?php echo $total_invoice;?> </td><td><?php echo $total_water;?></td><td><?php echo $total_loan;?></td><td><?php echo $total_net;?></td><td><?php echo '';?> </td></tr>


</table>
</fieldset>

</div>
