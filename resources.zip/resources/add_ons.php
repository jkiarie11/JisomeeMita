<style>
.labels{
position:absolute;
margin-left:200px;
margin-top:2px;
margin-bottom:2px;




}
#acc_combo{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#label{
position:relative;
margin-left:100px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-left:50px;
margin-right:350px;

}
#create_acc_btn{
margin-left:170px;
height:25px;
}
#create_acc_btn:hover{
margin-left:170px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:600px; width:270px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:250px; position:absolute;

padding:5px;
background-color:#FF6633;



}
#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}
</style>


<style>
.search{
position:absolute;
margin-left:100px;

}
#search_field{
position:absolute;
margin-left:500px;

}
#search_btn{
position:absolute;
margin-left:680px;

}
#search_regulator{
margin-left:145px;
margin-right:100px;
height:50px;

}
</style>
<?php  
$results="Alerts!";

$logged_username = $_SESSION['username'];


//echo $logged_username;
//change to actual user in production
$querynn="select contactname from user where username = '$logged_username' ";
$resultnn=mysql_query($querynn);
while($rownn=mysql_fetch_array($resultnn)){
    $loggedin_user=$rownn['contactname'];




    //


}



?>

<div id="create_new_account">




<form action="#" method="post" id="new_acc_fieldset">
<fieldset ><legend>Add Mobile Maji Service</legend>

		<label for="label" title="Please Enter  Name" class="labels">Service Name:
          </label><br />
		  <input type="text" name="service_name" id="label" class="text" value="<?php if(isset($_POST['service_name'])) echo $_POST['service_name']; ?>" /><br />
		  
		  <label for="label" title="Please Enter The Service Description" class="labels">Service Description:
          </label><br />
		  <input type="text" name="service_description" id="label" class="text" value="<?php if(isset($_POST['service_description'])) echo $_POST['service_description'];?>" /><br />

		 
		  
			<br />


		  
          
		  <label for="label" title="User Name" class="labels">Current User Name
          </label><br />
          <input type="text" name="payer" id="label" class="text" value="<?php echo $loggedin_user;
		   ?> " readonly/><br />
		  
		  <input type="submit"  name="payments" id="create_acc_btn"  value="Save Reading"  />
         
</fieldset>
</form>

<?php




if(isset($_POST['payments'])) {
	
		$expected = array('service_name', 'service_description','payer');
		$required = array('service_name', 'service_description','payer');
		$missing = array();

			foreach ($_POST as $key => $value) {
			$temp = is_array($value) ? $value : trim($value);
			if (empty($temp) && in_array($key, $required)) {
			array_push($missing, $key);
				}
			elseif (in_array($key, $expected)) {
			${$key} = $temp;
					}
				}
				if(!empty($missing)){
					$result = "Please enter the highlighted values.";
				}
				


				
			}


			
			
			////inserting  the payments created 
				if(isset($_POST['payments'])&& !$result) {
				$service_name=$_POST['service_name'];
				$service_description=$_POST['service_description'];
				$payer=$_POST['payer'];
				
				////////////////////////
				$query="select count(*) from user where password='$pass' and  username='$user'";
				
				//password='$pass' and
				$result=mysql_query($query);
				$count=mysql_result($result,0,0);
				/////////////////////
				
				
				

				
				
				


				
				
				//$_POST['meter_no'];
				
					$query="insert into product
					(name, service_description, who_entered,date_entered)
					values
					( '$service_name','$service_description', '$payer',
					now())";
					
					
					$result1=mysql_query($query)
				or die(mysql_error());
				
				$result='Your add-on Has been entered successfully ';


	
				
		}		
		
  ?>
</div>
<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
</div>