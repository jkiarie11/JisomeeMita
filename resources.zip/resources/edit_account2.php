
<style>
.labels{
position:absolute;
margin-left:150px;
margin-top:2px;
margin-bottom:2px;




}

.labels2{
position:absolute;
margin-left:500px;
margin-top:2px;
margin-bottom:2px;




}

#label{
position:relative;
margin-left:50px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#label2{
position:relative;
margin-left:400px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-top:100px;
margin-left:5px;
margin-right:450px;

}

#new_acc_fieldset1{

/*margin:10px,100px,10px,100px;*/
margin-left:5px;
margin-right:450px;

}


#new_acc_fieldset2{

/*margin:10px,100px,10px,100px;*/

margin-left:400px;
margin-right:70px;
margin-top:-30px;

}

#new_acc_fieldset3{

/*margin:10px,100px,10px,100px;*/

margin-left:350px;
margin-right:70px;
margin-top:-30px;

}



#validator{
border:5px ridge  #FFFFFF; left:500px; width:400px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:170px; position:absolute;

padding:5px;
background-color:#FF6633;



}

#communication{
border:2px ; left:475px; width:440px;  top:439px; position:absolute;






}

#reading{
border:2px ; left:475px; width:440px;  top:839px; position:absolute;






}




#search_btn{
position:absolute;
top:500;
margin-left:350px;

}

#create_acc_btn{
margin-left:330px;
top:-300;
height:30px;
}

#create_acc_btn:hover{
margin-left:330px;
background-color:#000000;
color:#FFFFFF;
height:30px;

}

#ViewMap{
margin-left:320px;
top:-270;
height:30px;
position:absolute;
}

#ViewMap:hover{
margin-left:330px;
background-color:#000000;
color:#FFFFFF;
height:30px;

}

#deactivate_acc_btn{
margin-left:100px;
top:-30px;
height:30px;



}

#deactivate_acc_btn:hover{
margin-left:100px;
background-color:#000000;
color:#FFFFFF;
height:30px;

}


#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}

#mappos{font-size:15pt;
        top :100;
        left:100;
        color:#CC6600;
		font-family:verdana;}
</style>
<?php

function test_req($key, $default = '') {
    if(isset($_REQUEST[$key]) and
       !empty($_REQUEST[$key])) {
        return $_REQUEST[$key];
    } else {
        return $default;
    }
}

//Using GET

$ls_search_value = $_GET['varname'];

if (strlen($ls_search_value) > 0){
    $search_value =$ls_search_value;
    $query="select * from account_details  where  acc_no = '$search_value' ";
}







if(isset($_POST['search_account'])){
	

	$search_value=mysql_real_escape_string($_POST['acc_nos']);
	//echo 'posted'.$search_value;

	//$query="select 	*	from 	neobill.account_details  where customer_name like '%$search_value%'  or phone_no like '%$search_value%' and account_status='active'	limit 0, 50";

	$query="select * from account_details  where  acc_no = '$search_value' ";
	
	

}

$result=mysql_query($query);
$i=0;
while($row=mysql_fetch_array($result)){
    
        
	$i++;
	$account_no=$row['acc_no'];
	
	$customer_name=$row['customer_name'];

	$national_id=$row['national_id'];
	$phone_no=$row['phone_no'];
        $phone_no2=$row['phone_no2'];
        $phone_no3=$row['phone_no3'];
	$dateTime= $row['entry_time'];
	$logged_in=$row['entry_user'];
	$met=$row['meter_no'];
	$postal_address=$row['postal_address'];
	$land_reg=$row['land_reg_meter_no']; 
	$street= $row['street'];
        $location_details = $row['location_details'];
	$gps_coord=$row['gps_coordinates'];
          //echo 'https://www.google.com/maps/preview/@-0.171704,35.8592033,14z';
        if($location_details<> '' && $gps_coord <> '' && $gps_coord <> '0') {
            
             $ls_desc = 'http://maps.google.com/maps?q=LR NO-'.$land_reg.':METER NO-'.$met.'+%28'.$customer_name.'%29@'.$gps_coord.'&t=h&z=18&output=embed';
             
            //   $ls_desc = 'http://maps.google.com/maps?q='.$land_reg.'+%28'.$customer_name.'%29@'.$gps_coord.'&t=h&z=18&output=embed';

          //   echo $ls_desc;
             
           //  echo 'https://maps.google.com/maps?q=A+house+right+over+here+%28Hello+from%29@13.795494,+100.566345&t=h&z=18&output=embed';
           
       
            
           echo '<a href="'.$ls_desc.'" target="_blank"><img src="download.jpg" style="left:392px;position:absolute;top:585px; width:70px; height:30px;border:none" alt="View Map" height="30" width="42"></a>';
             
            //   echo "<input type = 'submit' id='Submit' name='ViewMap' value='View Map' >";            
           
            
        
            
          
            
            
          //  echo $ls_desc;
             
        }
        
	$zone=$row['zone'];
        $meter_no=$row['meter_no'];
	$email=$row['email'];
        $location_details=$row['location_details'];
        $loan_amount=$row['loan_amount'];
        $loan_balance=$row['loan_balance'];
        $interest_amount=$row['interest_amount'];
        $interest_balance=$row['interest_balance'];
        
        $repayment_period=$row['repayment_period'];
        $last_cms_reading=$row['last_cms_reading'];
        $last_cms_reading_date=$row['last_cms_reading_date'];
        $rebate_amount=$row['rebate_amount'];
        $last_cms_balance=$row['last_cms_balance'];
        
        //////////////////
         
                              
                                
        ////////////////
	
}

$result = "";
$content= "";
$error="";

/* $account_no=$account_no;
$customer_name=$customer_name;
$national_id=$nat_id;
$phone_no=0;
$postal_address="";
$land_reg="";
$street="";
$gps_coord="";
$meter_route_no=0;
$email="";
$meter_nosss= ""; */
$logged_in='ADMIN';//until we get the correct user from logon window


if(isset($_POST['create_acc_btn'])) {
   
	
		$expected = array('account_no','customer_name', 'national_id','phone_no','land_reg','meter_no');
		$required = array('account_no','customer_name', 'national_id','phone_no','land_reg','meter_no');
		$missing = array();

			foreach ($_POST as $key => $value) {
			$temp = is_array($value) ? $value : trim($value);
			if (empty($temp) && in_array($key, $required)) {
			array_push($missing, $key);
				}
			elseif (in_array($key, $expected)) {
			${$key} = $temp;
					}
				}
				if(!empty($missing)){
					$result = "Please enter the highlighted values.";
				}
				
				
				
				
				//
				
				if (!is_numeric(trim($_POST['phone_no'])) ||($_POST['phone_no'] < 1)){
					
					$result = "The phone number  can only contain numerical values.";
				}
				
					
				
					
					
				/*if () {
					$result = "The adm. no cannot be less than zero.";
				} */
			//	elseif ($no == 1) {
					//$result = 'Sorry, a student with that admission number is already registrered.';
				//}
				if  ((!ereg('^[a-zA-Z0-9_\.\-]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$', $_POST['email'])) && (!empty($_POST['email']))){
					if ($_POST['email'] <> 'N/A') {
                                            $result = 'The email address you entered does not seem to be valid. Please re-enter.';
                                        }
				}	
			}
			
			
			////inserting  the account created 
				
			if(isset($_POST['create_acc_btn'])) {
				$account_no=$_POST['account_no'];
                               	$customer_name=$_POST['customer_name'];
				$national_id=$_POST['national_id'];
				$phone_no=trim($_POST['phone_no']);
                                $phone_no2=trim($_POST['phone_no2']);
                                $phone_no3=trim($_POST['phone_no3']);
				$postal_address=$_POST['postal_address'];
				$land_reg=$_POST['land_reg'];
				$street=$_POST['street'];
				$gps_coord=$_POST['gps_coordinates'];
				$zone=$_POST['zone'];
				$email=$_POST['email'];
				$meter_no=$_POST['meter_no'];
                                $location_details=$_POST['location_details'];
                                $loan_amount=$_POST['loan_amount'];
                                $interest_amount=$_POST['interest_amount'];
                                
                                $loan_balance=$_POST['loan_balance'];
                                $interest_balance=$_POST['interest_balance'];
                                $repayment_period=$_POST['repayment_period'];
                                $last_cms_reading=$_POST['last_cms_reading'];
                                $last_cms_reading_date=$_POST['last_cms_reading_date'];
                                $rebate_amount=$_POST['rebate_amount'];
                                $rebate_amount=$_POST['rebate_amount'];
                                
                                
                                if(strlen($loan_balance)==0||$loan_balance==0){
                                   $loan_balance=$loan_amount; 
                                   
                                   
                                }
                                
                               
                                
                                if(strlen($interest_balance)==0||$interest_balance==0){
                                   $interest_balance=$interest_amount; 
                                   
                                    
                                }
                                
                            }
                            
				
				
				
				
				//$_POST['meter_no'];
				
				
				
				
		if(isset($_POST['create_acc_btn']) && !$result){
                   

                    $logged_name = 'Admin On '.date("d/m/y");
                     //////inserting the account details
                    //$status='pending';


                    $query ="";

                    $query = "update account_details set customer_name = '$customer_name', national_id = '$national_id',phone_no2 = '$phone_no2',phone_no3 = '$phone_no3', phone_no = '$phone_no',"
                            . "postal_address = '$postal_address',land_reg_meter_no = '$land_reg',street = '$street',"
                            . "gps_coordinates= '$gps_coord',zone = '$zone', "
                            . "email = '$email',entry_user = '$logged_name' ,entry_time = NOW(),"
                            . " meter_no = '$meter_no',location_details = '$location_details',loan_amount = '$loan_amount',interest_amount = '$interest_amount'"
                            . ",loan_balance = '$loan_balance',interest_balance = '$interest_balance',rebate_amount = '$rebate_amount' where acc_no = '$account_no'" ;






$result1=mysql_query($query)
or die(mysql_error());

  $result='Your account Has been edited successfully ';
  
  $queryfff="select meter_no,customer_name from account_details order by meter_no desc limit 1";
   $resultfff=mysql_query($queryfff);
 $i=0;
 while($row=mysql_fetch_array($resultfff)){
 
  
    $dateTime= $row['meter_no'];
  $logged_in=$row['customer_name'];
   $meter_nosss='Account Name:  '.$logged_in.'<br />  your Meter No: is '.$dateTime ;
  }
 
 }
 
 
 if(isset($_POST['deactivate_acc_btn'])){
     
     
     if ( !empty($_POST['customer_name'])) {
	$search_value=$_POST['account_no'];
     
       // echo $search_value;
	//echo 'posted'.$search_value;

	//$query="select 	*	from 	neobill.account_details  where customer_name like '%$search_value%'  or phone_no like '%$search_value%' and account_status='active'	limit 0, 50";

	
     
     //$query = "test";
        $query="update account_details set account_status = 'inactive' where  acc_no = '$search_value' ";
        
        $result1=mysql_query($query)
        or die(mysql_error());

        $result='Your account Has been deactivated successfully ';
	
	
        
     }
     

}
		
		
?>		 

<div id="view_account">

<form action="#" method="post" id="new_acc_fieldset1">
    
  <fieldset id="search_regulator"><legend>Actions</legend>   

<label for="label"  class="search" title="Account No"> Account No
          </label>
          <input type="text" name="acc_nos" id="search_field" class="text" value="<?php  echo $ls_search_value; ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  /><br><br/>
                   
                   
 </fieldset>


<fieldset ><legend>Personal Details</legend>  
            <label for="label" title="Please Enter the Account No" class="labels"> Account Number
          </label><br />       
           <input type="text" name="account_no" id="label" class="text" value="<?php echo htmlentities(test_req('account_no',$account_no));  ?>"/><br />

	 <label for="label" title="Please Enter the Customer Name" class="labels"> Customer Name
          </label><br />
          <input type="text" name="customer_name" id="label" class="text" value="<?php echo htmlentities(test_req('customer_name',$customer_name)); ?>" /><br />

          <label for="label" title="Please Enter National ID" class="labels"<td align="right"><font color="#ff0000">*</font> National ID
          </label><br />    
          <input type="text" name="national_id" id="label" class="text" value="<?php echo  htmlentities(test_req('national_id',$national_id)); ?>" /><br />
 </fieldset>
 
 
 <fieldset ><legend>Geographical Details</legend>   
		  <label for="label" title="Please Enter the Land Reg No" class="labels"<td align="right"><font color="#ff0000">*</font>Land Reg No:
          </label><br />
          <input type="text" name="land_reg" id="label" class="text"  value="<?php echo  htmlentities(test_req('land_reg',$land_reg)); ?>" /><br />
		  <label for="label" title="Please Enter the Street" class="labels">Street:
          </label><br />
          <input type="text" name="street" id="label" class="text"  value="<?php echo htmlentities(test_req('street',$street)); ?>" /><br />
         
         
          <label for="label" title="Please Enter the Locatin Details" class="labels">Location Details:
          </label><br />
          
           
           
          <input type="text" name="location_details" id="label" class="text"  value="<?php echo htmlentities(test_req('location_details',$location_details)); ?>" /><br />
		    <label for="label" title="Please Enter the GPS Cordinates" class="labels">GPS Cordinates:
          </label><br />
          <input type="text" name="gps_coordinates" id="label" class="text" value="<?php echo htmlentities(test_req('gps_coordinates',$gps_coord)); ?>" /><br />
		   <label for="label" title="Please Enter the Zone" class="labels">Zone:
          </label><br />
    <input type="text" name="zone" id="label" class="text" value="<?php echo htmlentities(test_req('zone',$zone));?>" /><br />
</fieldset>
                   
<fieldset ><legend>Other Details</legend>   
    <label for="label" title="Please Enter the Meter No" class="labels"<td align="right"><font color="#ff0000">*</font>Meter No:

    </label><br />
    <input type="text" name="meter_no" id="label" class="text" value="<?php echo htmlentities(test_req('meter_no',$meter_no));?>" /><br />
    <label for="label" title="Please Enter the Loan Amount" class="labels">Loan Amount:
    </label><br />
    <input type="text" name="loan_amount" id="label" class="text" value="<?php echo htmlentities(test_req('loan_amount',$loan_amount));?>" /><br />
    <label for="label" title="Please Enter the Interest Amount" class="labels">Interest Amount:
    </label><br />
    <input type="text" name="interest_amount" id="label" class="text" value="<?php echo htmlentities(test_req('interest_amount',$interest_amount));?>" /><br />
    <label for="label" title="Please Enter the Loan Balance" class="labels">Loan Balance:
    </label><br />
    <input type="text" name="loan_balance" id="label" class="text" value="<?php echo htmlentities(test_req('loan_balance',$loan_balance));?>" readonly/><br />
     <label for="label" title="Please Enter the Interest Balance" class="labels">Interest Balance:
    </label><br />
    <input type="text" name="interest_balance" id="label" class="text" value="<?php echo htmlentities(test_req('interest_balance',$interest_balance));?>" readonly/><br />
      <label for="label" title="Please Enter the Repayment Period" class="labels">Repayment Period:
    </label><br />
    <input type="text" name="repayment_period" id="label" class="text" value="<?php echo htmlentities(test_req('repayment_period',$repayment_period));?>" readonly/><br />
   
    
	</fieldset>	 
         <input type="submit"  name="create_acc_btn" id="create_acc_btn"  value="Save Account>>"  />      
         <input type="submit"  name="deactivate_acc_btn" id="deactivate_acc_btn"  value="Deactivate Account" onSubmit="return confirm('Do you want to delete?');" />
                  
         

                    
    


</div>
		  
                 
         <div id="communication"><fieldset ><legend>Communication Details</legend>    
         
        <label for="label" title="Please Enter the Phone No" class="labels"<td align="right"><font color="#ff0000">*</font>Phone No
             </label><br />
           
          
          
          <input type="text" name="phone_no" id="label" class="text" value="<?php echo $phone_no; ?> " /><br />
          <label for="label" title="Please Enter the Phone No2" class="labels">Alternative Phone No:
          </label><br />
          <input type="text" name="phone_no2" id="label" class="text" value="<?php echo $phone_no2; ?> " /><br />
          <label for="label" title="Please Enter the Phone No3" class="labels">Alternative Phone No2:
          </label><br />
          <input type="text" name="phone_no3" id="label" class="text" value="<?php echo $phone_no3; ?> " /><br />
		  <label for="label" title="Please Enter the Postal Address" class="labels">Postal Address:
          </label><br />
            <input type="text" name="postal_address" id="label" class="text"  value="<?php echo $postal_address; ?>" /><br />
        <label for="label" title="Please Enter the email Address" class="labels">Email Address
          </label><br />
          <input type="text" name="email" id="label" class="text"  value="<?php echo $email; ?>" /><br />
          
                
              
           </fieldset>   
          
             
             <fieldset ><legend>Reading Details</legend>    
         
        <label for="label" title="Please Enter the Last CMS Reading" class="labels"<td align="right"><font color="#ff0000">*</font>Last CMS Reading
             </label><br />
          
          <input type="text" name="last_cms_reading" id="label" class="text" value="<?php echo $last_cms_reading; ?> " readonly/><br />
          <label for="label" title="Please Enter the Last Reading Date" class="labels">Last reading date:
          </label><br />
          <input type="text" name="last_cms_reading_date" id="label" class="text" value="<?php echo $last_cms_reading_date; ?> " readonly/><br />
           <label for="label" title="Please Enter the Rebate Amount" class="labels">Rebate Amount:
          </label><br />
          <input type="text" name="rebate_amount" id="label" class="text" value="<?php echo $rebate_amount; ?> " /><br />
            <label for="label" title="Please Enter the CMS Balance Amount" class="labels">Last CMS Balance:
          </label><br />
          <input type="text" name="last_cms_balance" id="label" class="text" value="<?php echo $last_cms_balance; ?> " readonly/><br />
          
          
                
              
           </fieldset>   
         
           
     
</form>
    
</div>
<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
</div>


