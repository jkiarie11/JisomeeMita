
<style>
.labels{
position:absolute;
margin-left:100px;
margin-top:2px;
margin-bottom:2px;




}

.required { background-color:#FF0 }

.labels2{
position:absolute;
margin-left:600px;
margin-top:2px;
margin-bottom:2px;




}

#label{
position:relative;
margin-left:10px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#label2{
position:relative;
margin-left:400px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-top:100px;
margin-left:5px;
margin-right:450px;

}



#new_acc_fieldset1{

/*margin:10px,100px,10px,100px;*/
margin-left:5px;
margin-right:450px;

}


#create_acc_btn{
margin-left:100px;
height:25px;
}


#create_acc_btn:hover{
margin-left:100px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:500px; width:400px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:170px; position:absolute;

padding:5px;
background-color:#FF6633;



}
#communication{
border:5px ; left:500px; width:400px; height:100px;  border-radius:5px; top:462px; position:absolute;

padding:5px;




}

#reading{
border:2px ; left:475px; width:440px;  top:839px; position:absolute;






}

#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}


         
       
</style>


<?php

function test_req($key, $default = '') {
    if(isset($_POST[$key]) and
       !empty($_POST[$key])) {
        return $_POST[$key];
    } else {
        return $default;
    }
}
//echo htmlentities(test_req('my_field'))

$result = "";
$content= "";
$error="";


$national_id="";
$phone_no=0;
$postal_address="";
$land_reg="";
$street="";
$gps_coord="";
$meter_route_no=0;
$email="";
$meter_nosss= "";
$loan_amount=0;
$repayment_period= 0;
$logged_in='ADMIN';//until we get the correct user from logon window
if(isset($_POST['search_account'])) {
    $logged_username = $_SESSION['username'];
    $search_value = mysql_real_escape_string($_POST['search_quotation']);
    
   
    
    


    IF (!empty($search_value)){




        $querrn="select * from quotations where quotation_no = $search_value and acc_no <> '' and quotation_no not in (select quotation_no from account_details where quotation_no = $search_value)";
        
        $quote_found =0;
        $resultnn=mysql_query($querrn);
     //  echo $querrn;
        while($rownn=mysql_fetch_array($resultnn)){
            $quotation_no=$rownn['quotation_no'];
            $acc_no=$rownn['acc_no'];
            //echo $account_no;
            $customer_name = $rownn['customer_name'];
             $quote_found =1;
            
             

            



        }
        
        if($quote_found ==1) {
        
            $querrn="select * from billing_settings";


            $resultnn=mysql_query($querrn);
         //  echo $querrn;
            while($rownn=mysql_fetch_array($resultnn)){
                $loan_amount=$rownn['loan_amount'];
                $loan_balance=$rownn['loan_amount'];
                $interest_amount=$rownn['interest_amount'];
                $interest_balance=$rownn['interest_amount'];
                $repayment_period=$rownn['repayment_period'];

            }
        }
       
        
        
    }
}




if(isset($_POST['for updating loan balances'])) {//put create_acc_btn for production  // for updating loan balances
    
   // echo 'now starting';
    
      $querrn = "SELECT billing_month  FROM billing_settings";
      
       $resultnn=mysql_query($querrn);
       
        while($rownn=mysql_fetch_array($resultnn)){
            $billing_month=$rownn['billing_month']; 
        }
    
    //get date
    
      $querrn = "SELECT *  FROM account_details";
      
       $resultnn=mysql_query($querrn);
            $j=0;
            while($rownn=mysql_fetch_array($resultnn)){
                
                
                $acc_no=$rownn['acc_no'];
                $loan_interest_date=$rownn['loan_interest_date'];
                $loan_amount=$rownn['loan_amount'];
                $loan_balance=$rownn['loan_balance'];
                $loan_interest=$loan_balance*(0.16/12);
                $new_loan_balance=$loan_balance+$loan_interest;
               

                if($billing_month > $loan_interest_date){
                  // echo "$acc_no";
                    $j++;
                  //  echo "UPDATE account_details set loan_balance = '$new_loan_balance',loan_interest_date = '$billing_month' where acc_no = '$acc_no'";
                    mysql_query("UPDATE account_details set loan_balance = '$new_loan_balance',loan_interest_date = '$billing_month' where acc_no = '$acc_no'" )or die(mysql_error());

                    //$result=mysql_query($query);
               //   echo $query;
                
               }  
               else {
                   // echo 'billing month is '.$billing_month.' loan interest date is '.$loan_interest_date;
                   //echo 'not greater than';
               }
               

            }
               
   
	
            if($j>0){
                echo "The no of rows updated is '$j'";
            }
            else{
                echo 'No records updated';
            }
				

    
    
   
 
 }


if(isset($_POST['test'])) {//put create_acc_btn for production
    
   // echo 'now starting';
    
      $querrn = "SELECT *  FROM duplicate_nos";
      
       $resultnn=mysql_query($querrn);
          
            while($rownn=mysql_fetch_array($resultnn)){
                
                $j=0;
                $acc_no=$rownn['acc_no'];
                
                $loan_amount=$rownn['loan_amount'];
                
                $query = "SELECT *  FROM duplicate_nos where phone_no = '$phone_no' ";
                
                 $result=mysql_query($query);
               //   echo $query;
                 while($rown2=mysql_fetch_array($result)){
                     $j++;
                    $phone_no2=$rown2['phone_no'];
                   // echo 'phone_no2 is '.$phone_no2;
                    
                    $account_extension2=$rown2['account_extension'];
                   
                    $acc_to_change=$rown2['acc_no'];
                    if(strlen($account_extension2)==0){
                        if($j==1){
                          $extension_set='A';
                        }
                        elseif($j==2){
                           $extension_set='B'; 
                        }
                        elseif($j==3){
                           $extension_set='C'; 
                        }
                        elseif($j==4){
                           $extension_set='D'; 
                        }
                        elseif($j==5){
                           $extension_set='E'; 
                        }
                        
                         echo 'account_set no is '.$extension_set;
                        
                        mysql_query("UPDATE duplicate_nos set account_extension = '$extension_set' where acc_no = '$acc_to_change'" )or die(mysql_error());
                        
                        
                    }
                     
                 }
                 
               

            }
               
   
	
   
				

    
    
   
 
 }
		
		
?>		 
<form action="#" method="post" id="new_acc_fieldset1">
<div id="create_new_account">
    


    <fieldset id="search_regulator"><legend>Actions</legend>


    <label for="label"  class="search" title="Quotation Number"> Quotation No:
    </label>
    <input type="text" name="search_quotation" id="search_field" class="text"
       value="<?php  ?>"  />
    <input type="submit"  name="search_account" id="search_btn"  value="Search"  />


</fieldset>


<fieldset ><legend>Personal Details</legend>
    
     
    
    <label for="label" title="Please Enter the Quotation No" class="labels"> Quotation No
          </label><br />
          <input type="text" name="quotation_no" id="label" class="text" value="<?php echo htmlentities(test_req('quotation_no',$quotation_no)); ?>" readonly/><br />

		<label for="label" title="Please Enter the Account No" class="labels"> Account No
          </label><br />
          <input type="text" name="acc_no" id="label" class="text" value="<?php echo htmlentities(test_req('acc_no',$acc_no)); ?>" readonly/><br />
		 <label for="label" title="Please Enter the Customer Name" class="labels"> Customer Name
          </label><br />
          <input type="text" name="customer_name" id="label" class="text" value="<?php echo htmlentities(test_req('customer_name',$customer_name));  ?>" readonly/><br />
        
          <label for="label" title="Please Enter the National Id" class="labels" <td align="right"><font color="#ff0000">*</font>National Id
          
          </label><br />
		  <input type="text" name="national_id" id="label"  class="text" value="<?php echo htmlentities(test_req('national_id',$national_id)); ?>" /><br />
                  
</fieldset>
 <fieldset ><legend>Geographical Details</legend>   
     
          <label for="label" title="Please Enter the Land Reg No" class="labels" <td align="right"><font color="#ff0000">*</font>Land Reg No:
          </label><br />
          <input type="text" name="land_reg" id="label" class="text"  value="<?php echo htmlentities(test_req('land_reg',$land_reg)); ?>" /><br />
		  <label for="label" title="Please Enter the Street" class="labels">Street:
          </label><br />
          <input type="text" name="street" id="label" class="text"  value="<?php echo htmlentities(test_req('street',$street)); ?>" /><br />
          <label for="label" title="Please Enter the location details" class="labels">Location Details:
          </label><br />
          <input type="text" name="location_details" id="label" class="text"  value="<?php echo htmlentities(test_req('location_details',$location_details)); ?>" /><br />
		    <label for="label" title="Please Enter the GPS Cordinates" class="labels">GPS Cordinates:
          </label><br />
          <input type="text" name="gps_coordinates" id="label" class="text" value="<?php echo htmlentities(test_req('gps_coordinates',$gps_coordinates)); ?>" /><br />
		   <label for="label" title="Please Enter the Zone" class="labels">Zone:
          </label><br />
		  <input type="text" name="zone" id="label" class="text" value="<?php echo htmlentities(test_req('zone',$zone));?>" /><br />
                 
                   
		
  </fieldset>
    
    <fieldset ><legend>Other Details.</legend>    
         
           <label for="label" title="Please Enter the Meter No" class="labels" <td align="right"><font color="#ff0000">*</font>Meter No:
          </label><br />
		  <input type="text" name="meter_no" id="label" class="text" value="<?php echo htmlentities(test_req('meter_no',$meter_no));?>" /><br />
		  <label for="label" title="Please Enter the Loan Amount" class="labels">Loan Amount:
          </label><br />
   
   
    
		  <input type="text" name="loan_amount" id="label" class="text" value="<?php echo htmlentities(test_req('loan_amount',$loan_amount));?>" readonly/><br />
                  <label for="label" title="Please Enter the Interest Amount" class="labels">Interest Amount:
    </label><br />
    <input type="text" name="interest_amount" id="label" class="text" value="<?php echo htmlentities(test_req('interest_amount',$interest_amount));?>" readonly/><br />
    <label for="label" title="Please Enter the Loan Balance" class="labels">Loan Balance:
    </label><br />
    <input type="text" name="loan_balance" id="label" class="text" value="<?php echo htmlentities(test_req('loan_balance',$loan_balance));?>" readonly/><br />
     <label for="label" title="Please Enter the Interest Balance" class="labels">Interest Balance:
    </label><br />
    <input type="text" name="interest_balance" id="label" class="text" value="<?php echo htmlentities(test_req('interest_balance',$interest_balance));?>" readonly/><br />
    <label for="label" title="Please Enter the Repayment Period" class="labels">Repayment Period:
    </label><br />
    <input type="text" name="repayment_period" id="label" class="text" value="<?php echo htmlentities(test_req('repayment_period',$repayment_period)) ;?>" /><br />
   
     
                  
                   
		  
		 
         
</fieldset>
    
    

    


</div>
    
    <div id="communication" ><fieldset ><legend>Communication Details</legend>    
         
           <label for="label" title="Please Enter the Phone No" class="labels" <td align="right"><font color="#ff0000">*</font>Phone No:
          </label><br />
          <input type="tel" name="phone_no" id="label" class="text" value="<?php echo htmlentities(test_req('phone_no',$phone_no)) ; ?> " /><br />
           <label for="label" title="Please Enter the Phone No2" class="labels">Altenative Phone No:
          </label><br />
          <input type="text" name="phone_no2" id="label" class="text" value="<?php echo htmlentities(test_req('phone_no2',$phone_no2)) ; ?> " /><br />

           <label for="label" title="Please Enter the Phone No" class="labels">Alternative Phone No2:
          </label><br />
          <input type="text" name="phone_no3" id="label" class="text" value="<?php echo htmlentities(test_req('phone_no3',$phone_no3)) ; ?> " /><br />

		  <label for="label" title="Please Enter the Postal Address" class="labels">Postal Address:
          </label><br />
<input type="text" name="postal_address" id="label" class="text"  value="<?php echo htmlentities(test_req('postal_address',$postal_address)) ; ?>" /><br />
		  <label for="label" title="Please Enter the email Address" class="labels">Email Address
          </label><br />
          <input type="text" name="email" id="label" class="text"  value="<?php echo htmlentities(test_req('email',$email)) ; ?>" /><br />
      
        
               </fieldset>
        
        
            <fieldset ><legend>Reading Details</legend>    
         
        <label for="label" title="Please Enter the Last CMS Reading" class="labels"<td align="right"><font color="#ff0000">*</font>Last CMS Reading
             </label><br />
           
          
          
          <input type="text" name="last_cms_reading" id="label" class="text" value="<?php echo htmlentities(test_req('last_cms_reading',$last_cms_reading)) ;  ?> " /><br />
          <label for="label" title="Please Enter the Last Reading Date" class="labels">Last reading date:
          </label><br />
          <input type="text" name="last_cms_reading_date" id="label" class="text" value="<?php echo htmlentities(test_req('last_cms_reading_date',$last_cms_reading_date)) ?> " /><br />
            <label for="label" title="Please Enter the Rebate Amount" class="labels">Rebate Amount:
          </label><br />
          <input type="text" name="rebate_amount" id="label" class="text" value="<?php echo htmlentities(test_req('rebate_amount',$rebate_amount)) ; ?> " /><br />
            <label for="label" title="Please Enter the CMS Balance Amount" class="labels">Last CMS Balance:
          </label><br />
          <input type="text" name="last_cms_balance" id="label" class="text" value="<?php echo htmlentities(test_req('last_cms_balance',$last_cms_balance)) ; ; ?> " /><br />
          
          
                
              
           </fieldset>   
          <input type="submit"  name="create_acc_btn" id="create_acc_btn"  value="Update data>>"  />
        
    <br /></div>


     
     
        
      
     
      
		
    
    
      
</form>
     

<div id="validator">
<?php echo $result.'<br />'/*. $meter_nosss*/; ?>
</div>

<div id="working_csv">
<?php 
function get_file_extension($file_name) {
    return end(explode('.',$file_name));
}
 
function errors($error){
    if (!empty($error))
    {
            $i = 0;
            while ($i < count($error)){
            $showError.= '<div class="msg-error">'.$error[$i].'</div>';
            $i ++;}
            return $showError;
    }// close if empty errors
} // close function
 
 
if (isset($_POST['upfile'])){
// check feilds are not empty
 
if(get_file_extension($_FILES["uploaded"]["name"])!= 'csv')
{
$error[] = 'Only CSV files accepted!';
}
 
if (!$error){

$logged_in = "'Admin On ".date("d/m/y")."'";
 
$tot = 0;
$handle = fopen($_FILES["uploaded"]["tmp_name"], "r");
while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
    for ($c=0; $c < 1; $c++) {
	
			
           
            //only run if the first column if not equal to firstname
            if($data[0] !='ACCOUNT'){
                mysql_query("UPDATE account_details_notimported set last_cms_reading_date = '".mysql_real_escape_string($data[1])."',
                    last_cms_reading='".mysql_real_escape_string($data[2])."',
                        last_cms_balance='".mysql_real_escape_string($data[3])."' "
                        . "where acc_no = 'ES".mysql_real_escape_string($data[0])."'" )or die(mysql_error());
                
                 /*mysql_query("UPDATE account_details set last_cms_reading_date = '".mysql_real_escape_string($data[1])."',
                    last_cms_reading='".mysql_real_escape_string($data[2])."',
                        last_cms_balance='".mysql_real_escape_string($data[3])."' "
                        . "where acc_no = 'ES".mysql_real_escape_string($data[0])."'" )or die(mysql_error());*/
                
               /*  mysql_query("REPLACE INTO account_balances(
                acc_no,reading_date,reading,
                total_balance
                )VALUES(
                    '".mysql_real_escape_string($data[0])."',
                    '".mysql_real_escape_string($data[1])."',
                    '".mysql_real_escape_string($data[2])."',
					'".mysql_real_escape_string($data[3])."'
                                                       
					
                )" )or die(mysql_error());*/
                
              /*  echo "UPDATE account_details_test set last_cms_reading = '".mysql_real_escape_string($data[1])."',
                    last_cms_reading_date='".mysql_real_escape_string($data[2])."',
                        last_cms_balance='".mysql_real_escape_string($data[3])."' "
                        . "where acc_no = 'ES".mysql_real_escape_string($data[0])."'";*/
                
              //  return;
               
            }
 
    $tot++;}
}


fclose($handle);
$content.= "<div class='success' id='message'> CSV File Imported, $tot records updated </div>";
 
}// end no error
}//close if isset upfile
 
$er = errors($error);
$content.= <<<EOF
<h3>Import CSV Data</h3>
$er
<form enctype="multipart/form-data" action="" method="post">
    File:<input name="uploaded" type="file" maxlength="20" /><input type="submit" name="upfile" value="Upload File">
</form>
EOF;
echo $content;
?>

</div>
