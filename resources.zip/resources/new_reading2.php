<style>
.labels{
position:absolute;
margin-left:200px;
margin-top:2px;
margin-bottom:2px;




}
#acc_combo{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#label{
position:relative;
margin-left:100px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-left:50px;
margin-right:350px;

}
#create_acc_btn{
margin-left:170px;
height:25px;
}
#create_acc_btn:hover{
margin-left:170px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:600px; width:270px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:250px; position:absolute;

padding:5px;
background-color:#FF6633;



}
#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}
</style>


<style>
.search{
position:absolute;
margin-left:100px;

}
#search_field{
position:absolute;
margin-left:500px;

}
#search_btn{
position:absolute;
margin-left:680px;

}
#search_regulator{
margin-left:145px;
margin-right:100px;
height:50px;

}
</style>
<?php  
$results="Alerts!";

if(isset($_POST['search_account'])){

$search_value=$_POST['acc_name'];

 
 $querynn="select * from account_reading where account_no like '%$search_value%' ";
 $resultnn=mysql_query($querynn);
 while($rownn=mysql_fetch_array($resultnn)){
 $acc_noss=$rownn['meter_no'];

 $acc_names=$rownn['customer_name'];
 

 
 }
}

?>

<div id="create_new_account">

<fieldset id="search_regulator"><legend>Actions</legend>
  <form method="post" action="#" >

		<label for="label"  class="search" title="Account Name"> Account No:
          </label>
          <input type="text" name="acc_name" id="search_field" class="text"
		   value="<?php if(isset($_POST['acc_name'])) echo $_POST['acc_name']; ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
		
      </form>
	  </fieldset>


<form action="#" method="post" id="new_acc_fieldset">
<fieldset ><legend>Enter The Payment Details.</legend> 

		<label for="label" title="Please Enter  Amount Paid" class="labels">Account No:
          </label><br />
		  <input type="text" name="acc_nos" id="label" class="text" value="<?php  echo $acc_noss;  ?>" /><br />
		  
		  <label for="label" title="Please Enter The Reading" class="labels">Account Name:
          </label><br />
		  <input type="text" name="acc_name" id="label" class="text" value="<?php echo $acc_names; ?>" /><br />
		  <label for="label" title="Please Enter Meter No" class="labels">Meter No:
          </label><br />
		  <input type="text" name="meter_no" id="label" class="text" value="<?php if(isset($_POST['meter_no'])) echo $_POST['invoice_id']; ?>" /><br />
		  
		 
		  
			<br />

          <label for="label" title="Please Enter Reading" class="labels">Reading
          </label><br />
		  <input type="text" name="reading" id="label" class="text" value="<?php if(isset($_POST['reading']))echo $_POST['reading']; ?>" /><br />
		  
          
		  <label for="label" title="Please Enter the Meter Reader" class="labels">Meter Reader Name
          </label><br />
          <input type="text" name="payer" id="label" class="text" value="<?php if(isset($_POST['payer'])) {echo $_POST['payer'];}
		   ?> " /><br />
		  
		  <input type="submit"  name="payments" id="create_acc_btn"  value="Save Reading"  />
         
</fieldset>
</form>

<?php
if(isset($_POST['payments'])) {
	
		$expected = array('acc_now', 'acc_name','invoice_id','mode_of_payment','amount_paid','payer');
		$required = array('acc_now', 'acc_name','invoice_id','mode_of_payment','amount_paid','payer');
		$missing = array();

			foreach ($_POST as $key => $value) {
			$temp = is_array($value) ? $value : trim($value);
			if (empty($temp) && in_array($key, $required)) {
			array_push($missing, $key);
				}
			elseif (in_array($key, $expected)) {
			${$key} = $temp;
					}
				}
				if(!empty($missing)){
					$result = "Please enter the highlighted values.";
				}
				
				if (!is_numeric($_POST['amount_paid'])||($_POST['amount_paid'] < 1)){
					$result = "The Amount Paid can only contain numerical values.";
				}

				
			}
			
			
			////inserting  the payments created 
				if(isset($_POST['payments'])&& !$result) {
				$acc_nos=$_POST['acc_nos'];
				$acc_name=$_POST['acc_name'];
				$invoice_id=$_POST['invoice_id'];
				$mode_of_payment=$_POST['mode_of_payment'];
				$amount_paid=$_POST['amount_paid'];
				$payer=$_POST['payer'];
				
				
				
				
				
				//$_POST['meter_no'];
				
			$query="insert into payment
	(invoiceid, date, amount, type_of_payment, payers_name, 
	meter_no, acc_name)
	values
	( '$invoice_id',NOW(),'$amount_paid', '$mode_of_payment', '$payer', 
	'$acc_nos','$acc_name')";
	
	
	$result1=mysql_query($query)
or die(mysql_error());

$result='Your account Has been created successfully ';
	
				
		}		
		
  ?>
</div>
<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
</div>