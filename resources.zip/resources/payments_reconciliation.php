<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>All Payments</title>
<link rel="stylesheet" href="./jquery-ui-1.10.4/themes/base/jquery.ui.all.css">
<script src="./jquery-ui-1.10.4/jquery-1.10.2.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.core.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.widget.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.datepicker.js"></script>
        
        <script>
	$(function() {
		$( "#datepicker" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
  $( "#datepickerto" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
	});
	</script>
</head>
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:1200px;align:center;}
#disc{position:relative; left:5px; top:2px; border:1px solid  #CCCCFF;width:890px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}


</style>
<div id="active_accounts"> 
<fieldset><legend>Payments Reconciliation</legend>
 <form method="post" action="#" >
  
  
		<label for="label"  class="search" title="Account Name"> From :
          </label>
           <input type="text" name="datefrom" id="datepicker" value="<?php  echo $search_value_from; ?>"   />
    
    &nbsp;&nbsp; &nbsp;&nbsp;
    <label for="label"  class="search" title="Account No"> To :
          </label>
   
     <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
      <input type="submit"  name="export_data" id="export_btns"  value="Export"  /><br><br/>   
		
      </form>

<div id="disciplinary">

<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>#No</th><th>Transaction ID</th><th>Transaction Date</th><th>Initiation Time</th><th>Transaction Details</th><th>Transaction Status</th><th>Paid In</th><th>Withdrawn </th><th>Balance </th><th>Transaction Type</th><th>Other Party Info</th></tr
<?php 


    
     $search_value_from=mysql_real_escape_string($_POST['datefrom']);
     
     
       
        $date_from=substr($search_value_from,6,4).'-'.substr($search_value_from,3,2).'-'.substr($search_value_from,0,2);
       echo $date_from;
       
       
    $i=0;
    
   if (strlen($date_from) > 0) {
   $queryss="select    transaction_id,transaction_date,initiation_time,transaction_details, transaction_status, 
	      paid_in,  withdrawn, balance ,    transaction_type ,  other_party_info     from safaricom_payments
	      where date_format(transaction_date,'%Y-%m-%d') = '$date_from' and transaction_id not in 
	      (select transaction_id from payment)  "	      ;
	      }    
else {
    $queryss="select    transaction_id,transaction_date,initiation_time,transaction_details, transaction_status, 
	      paid_in,  withdrawn, balance ,    transaction_type ,  other_party_info     from safaricom_payments
	      where date_format(transaction_date,'%Y-%m-%d') = '$date_from' and transaction_id not in 
	      (select transaction_id from payment)  ";    
	      }
 
 $resultss = mysql_query($queryss);
 
 if(isset($_POST['export_data'])){
    
   
    
   

    // Pick a filename and destination directory for the file
    // Remember that the folder where you want to write the file has to be writable
    $filename = "/tmp/payments_reconciliation_export_".time().".csv";

    // Actually create the file
    // The w+ parameter will wipe out and overwrite any existing file with the same name
    $handle = fopen($filename, 'w+');

    // Write the spreadsheet column titles / labels
    
    fputcsv($handle, array('Transaction Id','Transaction Date','Initiation Time','Transaction Details','Transaction Status','Paid In','Balance','Transaction Type','Other Party Info'));

    

    // Finish writing the file
  //  fclose($handle);
    
    //exit;
}   

if(isset($_POST['search_account'])||isset($_POST['export_data'])){
    
   echo $queryss;
			

    while($rows=mysql_fetch_array($resultss)){
           $transaction_id=$rows['transaction_id'];
        $transaction_date=$rows['transaction_date'];
        $initiation_time=$rows['initiation_time'];
        $transaction_details=$rows['transaction_details'];
        $transaction_status=$rows['transaction_status'];
      
        $paid_in=$rows['paid_in'];
        $withdrawn=$rows['withdrawn'];
        $balance=$rows['balance'];
        $transaction_type=$rows['transaction_type'];
        $other_party_info=$rows['other_party_info'];
        $total_amount+=$paid_in;
        
         if(isset($_POST['export_data'])){
           fputcsv($handle, array($transaction_id, $transaction_date,$initiation_time, $transaction_details, $transaction_status,$paid_in,$withdrawn,$balance,$transaction_type,$other_party_info));  
         }

        $i++;  
                                
                        
                                
                                 
                                
                                         

 ?>
 <style>

 

 
 </style>
<tr bgcolor="#CCCCCC"><td><?php echo $i;?> </td><td><?php echo $transaction_id; ?></td><td><?php echo $transaction_date;  ?></td><td><?php echo $initiation_time;  ?></td><td><?php echo $transaction_details;  ?></td><td><?php echo  $transaction_status;?></td><td><?php echo  $paid_in;?></td><td><?php echo $withdrawn;?> </td><td><?php echo $balance;?> </td><td><?php echo $transaction_type;?> </td><td><?php echo $other_party_info;?> </td><?php
                          

			 
 }
 
    $total_amount = number_format($total_amount);
			
}

 // Finish writing the file
    fclose($handle);

?>
<tr bgcolor="#CCCCCC"><td><?php echo ''; ?></td><td><?php echo '';  ?></td><td><?php echo '';  ?></td><td><?php echo '';?> </td><td><?php echo '';?></td><td><?php echo 'Total';?></td><td><?php echo $total_amount;?></td><td><?php echo $net_paid;?> </td></tr>


</table>
</fieldset>

</div>
