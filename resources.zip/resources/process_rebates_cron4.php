
<?php  
$results="Alerts!";


    
     $logged_username = $_SESSION['username'];

    $search_value=mysql_real_escape_string($_POST['acc_name']);


     $querynn="select * from account_details where first_payment = 1";
     $resultnn=mysql_query($querynn);
     while($rownn=mysql_fetch_array($resultnn)){
         $account_no=$rownn['acc_no'];
         $rebate_amount=$rownn['rebate_amount'];
         $reason_for_adjustment='REBATES';
         $adjustment_type='CR';
         
         $query="update account_details set first_payment=2 where acc_no = '$account_no'";
        
          $result=mysql_query($query)
        or die(mysql_error());
         
          
        $querynn="select count(*) as count_adj from adjustments where adjustment_reason  = 'REBATES' and acc_no= '$account_no'";
        $resultn2=mysql_query($querynn);
        
        while($rown2=mysql_fetch_array($resultnn)){
            $count_adj=$rown2['count_adj']; 
        }
        
        if($count_adj==0){
             $query="insert into adjustments
            (adjustment_reason, acc_no, amount,adjustment_type,adjustment_date)
            values
            ('$reason_for_adjustment','$account_no', '$rebate_amount','$adjustment_type',NOW())";


            $result=mysql_query($query)
            or die(mysql_error());
            
        }
       

       


     }
 






 

?>

