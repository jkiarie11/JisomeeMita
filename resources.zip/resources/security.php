
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:900px;}
#disc{position:relative; left:5px; top:10px; border:1px solid  #CCCCFF;width:890px; }
#disc td{text-align:left;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}
</style>

<?php  

function test_req($key, $default = '') {
    if(isset($_REQUEST[$key]) and
       !empty($_REQUEST[$key])) {
        return $_REQUEST[$key];
    } else {
        return $default;
    }
}

$ls_search_value = $_GET['varname'];



if (strlen($ls_search_value) > 0){
    
    $search_value =$ls_search_value;
  //  $query="select * from user  where  username = '$search_value' ";
}
?>
<div id="active_accounts">
<fieldset><legend>System Security</legend>
  <form method="post" action="#" >
  
  
		<label for="label"  class="search" title="User Name"> User Name
          </label>
          <input type="text" name="acc_name" id="search_field" class="text" value="<?php echo htmlentities(test_req('user_name',$ls_search_value));  ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
                   
                    
		
      </form>
    
    
<div id="disciplinary">
<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>User Name</th><th>Screen Code</th><th>Screen Name</th><th>Allowed</th><th>Action</th></tr>
<?php 



if(isset($_POST['save_record'])){
     

}


//if(isset($_POST['search_account'])){

 $search_value=mysql_real_escape_string($_POST['acc_name']);
 
 if(strlen($search_value)==0){
     $search_value=$ls_search_value;
 }

 $i=0;
  
 $query="select distinct username from user where username = '$search_value'";
 $result=mysql_query($query);
 
 

 
 while($row=mysql_fetch_array($result)){
  $paramname= $row['username'];
  if (strlen($paramname) == 0) {
      return;
  }
  
$querys="select s.screen_code as screen_code,s.screen_name as screen_name,u.username as username,u.allowed as allowed "
        . "from system_screens s left join userights u on s.screen_code = u.screen_code where username = '$paramname' "
        . "union select s.screen_code as screen_code,s.screen_name as screen_name,u.username as username,"
        . "u.allowed as allowed from system_screens s left join userights u on s.screen_code = u.screen_code "
        . "where concat( s.screen_code, s.screen_name) not in (select concat( s.screen_code, s.screen_name)"
        . " from system_screens s left join userights u on s.screen_code = u.screen_code where username = '$paramname')";

//$querys="select s.screen_code as screen_code,s.screen_name as screen_name,u.username as username,u.allowed as allowed from system_screens s left join userights u on s.screen_code = u.screen_code   ";
//echo $querys;
$results=mysql_query($querys);
$i++;



while($rows=mysql_fetch_array($results)){
    $username= $rows['username'];
     
      $screen_code = $rows["screen_code"];

     $screen_name = $rows["screen_name"];
     $allowed = $rows["allowed"];
    $ls_checked ='<input type="checkbox" disabled="disabled" onclick="return false" name="vehicle" checked ><BR>';
    $ls_action ='<a href="std_rollovers.php?choice=remove_user_right&varname='.$username.'&varname2='.$screen_code.'&varname3='.$screen_name.'">Remove Right</a>';
    
     
    
     if (empty($username) ||$allowed==0 ){
        $username = $paramname;
        $ls_checked ='<input type="checkbox" disabled="disabled" onclick="return false" name="vehicle"  ><BR>';
       $ls_action ='<a href="std_rollovers.php?choice=add_user_right&varname='.$username.'&varname2='.$screen_code.'&varname3='.$screen_name.'">Assign Right</a>';
     }
     
    if ($username <> $paramname) {
        $username = $paramname;
        $ls_checked ='<input type="checkbox" disabled="disabled" onclick="return false" name="vehicle" ><BR>';
        $ls_action ='<a href="std_rollovers.php?choice=add_user_right&varname='.$username.'&varname2='.$screen_code.'&varname3='.$screen_name.'">Assign Right</a>';
     }
     
    
     
    
     
     
    

			  
		// echo"<tr bgcolor='#CCCCCC'>";	  
			 
 ?>
<tr bgcolor="#CCCCCC"><td><?php echo $username?> </td><td><?php echo $screen_code?> </td><td><?php echo $screen_name;?></td><td><?php echo  $ls_checked;?></td><td><?php echo  $ls_action;?></td></tr>
<?php 
			 }
 }
 


//}



?>


</table>
</fieldset>
   

</div>
