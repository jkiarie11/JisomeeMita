
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:900px;align:center;}
#disc{position:relative; left:5px; top:2px; border:1px solid  #CCCCFF;width:890px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}
</style>
<div id="active_accounts">
<fieldset><legend>Outstanding Invoices</legend>
 <form method="post" action="#" >
  
  
		<label for="label"  class="search" title="Account Name"> Account No
          </label>
          <input type="text" name="acc_name" id="search_field" class="text" value="<?php if(isset($_POST['acc_name'])) echo $_POST['acc_name']; ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
		
      </form>
<?php
function checking_billing($units){
     
			if($units<=10){
				$bill=$units*18.71;
			}
			else if($units>10 && $units<=30){
					$bill=(10*18.71)+(($units-10)*28.07);	
			}
			else if($units>30 && $units<=60){
						$bill=(10*18.71)+(20*28.07)+(($units-30)*42.89);				
			}
			else if($units>60){
						$bill=(10*18.71)+(20*28.07)+(30*42.89)+(($units-60)*53.80);
			}


return $bill;
}

 
?>
<div id="disciplinary">

<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>#No</th><th>Acc Name</th><th>Account No</th><th>Meter No</th><th>Previous Reading</th><th>Current Reading</th><th>Reading Date</th><th>[Consumption]</th><th>Amount</th></tr>
<?php 

if(isset($_POST['search_account'])){
    
     $search_value=$_POST['acc_name'];

    $i=0;
  
        $queryss="select  distinct ad.meter_no,mobile_no,current_reading,reading_date,customer_name,previous_reading,ad.acc_no,ar.amount from account_details ad,account_reading ar,invoice inv  where    ar.acc_no=ad.acc_no and ad.acc_no = inv.acc_no and ar.current_reading = inv.current_units and ad.acc_no = '$search_value' and invoice_raised = 'no' order by  ar.reading_date asc";

        
        $resultss=mysql_query($queryss);

        $grand_total = 0;


        while($rows=mysql_fetch_array($resultss)){
         $meter_no= $rows['meter_no'];

           $mob_no= $rows['mobile_no'];
           $big=$rows['current_reading'];
           $cur_rd=$rows['current_reading'];
           $reading_date=$rows['reading_date'];
           $akt_nm= $rows['customer_name'];	
           $prev_reading= $rows['previous_reading']; 
           $acc_no= $rows['acc_no']; 
           $amount= $rows['amount']; 


               /////creating the previous reading
               //if ($prev_reading > 0){
               //  $unit_total=$big-$small;  
               //}
               //else{
                 //  $unit_total=$small;
             //  }
               $unit_total = $cur_rd - $prev_reading;

               $small = $rows['current_reading'];

               $grand_total += $amount;

               $i++; 
                                
                        
                                
                                 
                                
                                         

 ?>
 <style>
 .btn{
 margin:0px;
 

 
 </style>
<tr bgcolor="#CCCCCC"><td><?php echo $i;?> </td><td><?php echo $akt_nm; ?></td><td><?php echo $acc_no;  ?></td><td><?php echo $meter_no;  ?></td><td><?php echo  $prev_reading;?></td><td><?php echo $cur_rd;?> </td><td><?php echo $reading_date;?> </td><td><?php echo $unit_total." Units";?> </td><td><?php echo $amount;?> </td><?php
                          

			 
 }
 

			
}



?>
    

</tr>

<tr bgcolor="#CCCCCC"><td><?php echo ' ';?> </td><td><?php echo ''; ?></td><td><?php echo '';  ?></td><td><?php echo '';  ?></td><td><?php echo '';?></td><td><?php echo '';?> </td><td><?php echo '';?> </td><td><?php echo 'Total';?> </td><td><?php echo $grand_total;?> </td></tr>


</table>
</fieldset>

</div>
