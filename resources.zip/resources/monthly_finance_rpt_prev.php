<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Disconnections Report</title>
<link rel="stylesheet" href="./jquery-ui-1.10.4/themes/base/jquery.ui.all.css">
<script src="./jquery-ui-1.10.4/jquery-1.10.2.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.core.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.widget.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.datepicker.js"></script>
        
        <script>
	$(function() {
		$( "#datepicker" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
  $( "#datepickerto" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
	});
	</script>
</head>

<body>
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:10px 10px 10px 10px;width:830px;}
#disc{position:relative;border:1px solid  #CCCCFF;width:830px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}

#search_regulator{
margin-left:145px;
margin-right:100px;

height:auto;

}
#invoice_dv{
margin-left:10px;
margin-right:10px;

}
#payment_tbl{
margin-left:10px;
margin-right:10px;


height:auto;


}
#invoice_tbl{
margin-left:10px;
margin-right:10px;


height:auto;
}

.heads{
left:50px; top:100px;

}
.heads1{

}
#summary_headers{
margin-top:40px;
}
</style>
<div id="active_accounts">
    
    



<div id="disciplinary">

<!--   account name-->
<style>

</style>
<!--   payments-->	
<div id="payment_tbl">  
    
    <form action="#" method="post" >
        <fieldset id="search_regulator"><legend>Dates</legend> 
 <label for="label"  class="search" title="Account No"> From :
          </label>
         
    <input type="text" name="datefrom" id="datepicker" value="<?php  echo $search_value_from; ?>"   />
    
    &nbsp;&nbsp; &nbsp;&nbsp;
    <label for="label"  class="search" title="Account No"> To :
          </label>
     <input type="text" name="dateto" id="datepickerto" value="<?php  echo $search_value_to; ?>"  />
     <input type="submit"  name="search_account" id="search_btn"  value="Search"  /><br><br/>
		   
                       
 </fieldset>
                     

</form>
<fieldset id="payment_fieldset"><legend align="center">Monthly Financial Report</legend>

	  
<table id="disc"><tr bgcolor="#000000"><th>Month</th><th>Reading Count</th><th>Reading Amount</th><th>Invoice Amount</th><th>Water Collection</th><th>Loan Collection</th><th>Total Collection</th></tr>
<?php 
include("../includes/studentsconnect1.php");



echo"<tr bgcolor='#CCCCCC'>";
 ?>
 
 <?php 
 
 if(isset($_POST['search_account'])){
	

	$search_value_from=mysql_real_escape_string($_POST['datefrom']);
        $search_value_to=mysql_real_escape_string($_POST['dateto']);
        $date_from=substr($search_value_from,6,4).'-'.substr($search_value_from,3,2).'-'.substr($search_value_from,0,2);
        $date_to=substr($search_value_to,6,4).'-'.substr($search_value_to,3,2).'-'.substr($search_value_to,0,2);
	

	
	
	

}

 if (strlen($date_from) > 0) {
  $querynn=  "SELECT month(reading_date) reading_month,count(*) count_readings,sum(amount) reading_amount,
(SELECT  sum(amount) FROM `invoice` where month(periodbegin) = month(reading_date) and monthly_invoice = 1)
Invoice_Amount,
(SELECT  sum(amount) FROM `payment` where month(date) = month(reading_date) and payment_for in (1,3)) Water_Collection,
(SELECT  sum(amount) FROM `payment` where month(date) = month(reading_date) and payment_for in (2)) Loan_Collection,
(SELECT  sum(amount) FROM `payment` where month(date) = month(reading_date) ) Total_Collection
FROM account_reading where  month(reading_date) between month('$date_from') and month($date_to) group by month(reading_date) ";
  //   $querynn="select distinct 	acc_no, customer_name, phone_no,phone_no2,phone_no3 from account_details where entry_time between '$date_from' and  '$date_to' and account_status = 'inactive' ";
  }
else {
   // $querynn="select distinct 	acc_no, customer_name, phone_no,phone_no2,phone_no3 from account_details where account_status = 'inactive'";
    $querynn = "SELECT month(reading_date) reading_month,count(*) count_readings,sum(amount) Reading_Amount,
(SELECT  sum(amount) FROM `invoice` where month(periodbegin) = month(reading_date) and monthly_invoice = 1)
Invoice_Amount,
(SELECT  sum(amount) FROM `payment` where month(date) = month(reading_date) and payment_for in (1,3)) Water_Collection,
(SELECT  sum(amount) FROM `payment` where month(date) = month(reading_date) and payment_for in (2)) Loan_Collection,
(SELECT  sum(amount) FROM `payment` where month(date) = month(reading_date) ) Total_Collection
FROM account_reading group by month(reading_date) ";
}

if(isset($_POST['search_account'])||isset($_POST['export_data'])){
    
   //echo $queryss;
			

    while($rows=mysql_fetch_array($resultss)){
        $acc_no=$rows['acc_no'];
        $cust_name=$rows['customer_name'];
        $payment_date=$rows['date'];
        $payment_mode=$rows['type_of_payment'];
        $payment_for=$rows['payment_for'];
        $amount_paid=$rows['amount'];
        $who_entered=$rows['who_entered'];
        $date_entered=$rows['date_entered'];
        $total_amount+=$amount_paid;
         if(isset($_POST['export_data'])){
           fputcsv($handle, array($acc_no, $cust_name,$payment_date, $payment_mode, $payment_for,$amount_paid,$date_entered));  
         }

        $i++;  


 
 ?>

</table>

</fieldset>
 </div>
<!--   balance-->	

<style>
.bal_lbl{
left:400px; top:0px; position:relative; font-weight:bold;
}
.bal_thing{
left:20px; top:0px; position:relative; font-weight:bold;

}
</style> 
<div  id="summary_headers">

<?php

?>

	 <!-- <p  class="bal_lbl">Balance:<label class="bal_thing"><?php //echo  ($balance); ?></label> </p>-->
	  
	  </div>



</div>

</body>
</html>
