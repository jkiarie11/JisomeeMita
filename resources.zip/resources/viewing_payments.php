
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:900px;align:center;}
#disc{position:relative; left:5px; top:2px; border:1px solid  #CCCCFF;width:890px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}
</style>
<div id="active_accounts">
<fieldset><legend>View Payments</legend>
 <form method="post" action="#" >
  
  
		<label for="label"  class="search" title="Account Name"> Account No
          </label>
          <input type="text" name="acc_name" id="search_field" class="text" value="<?php if(isset($_POST['acc_name'])) echo $_POST['acc_name']; ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
		
      </form>

<div id="disciplinary">

<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>#No</th><th>Acc Name</th><th>Account No</th><th>Payment Date</th><th>Payment Mode</th><th>Payment For</th><th>Amount Paid</th><th>Transaction ID </th><th>Date Imported </th></tr>
<?php 

if(isset($_POST['search_account'])){
    
     $search_value=mysql_real_escape_string($_POST['acc_name']);

    $i=0;
 
    $queryss="select * from payment,account_details where payment.acc_no=account_details.acc_no and account_details.acc_no = '$search_value'  order by  payment.date desc";
      //echo $queryss;
    
     $resultss=mysql_query($queryss);
			

    while($rows=mysql_fetch_array($resultss)){
        $acc_no=$rows['acc_no'];
        $cust_name=$rows['customer_name'];
        $transaction_id=$rows['transaction_id'];
        $payment_date=$rows['date'];
        $payment_mode=$rows['type_of_payment'];
        $payment_for=$rows['payment_for'];
        if ($payment_mode==3){
            $payment_mode='MPESA';
        }
        elseif ($payment_mode==2){
              $payment_mode='CHEQUE';
        }
        else {
            $payment_mode='CASH';
        }
        
         if ($payment_for==1){
               $payment_for_desc='INVOICE';
           }
           elseif ($payment_for==2){
                 $payment_for_desc='LOAN';
           }
            elseif ($payment_for==3){
                 $payment_for_desc='UNAPPLIED CASH';
           }
		    elseif ($payment_for==4){
                 $payment_for_desc='SEWER LOAN';
           }
        
        $amount_paid=$rows['amount'];
        $who_entered=$rows['who_entered'];
        $date_entered=$rows['date_entered'];
         $total_amount+=$amount_paid;
       

        $i++;  
                                
                        
                                
                                 
                                
                                         

 ?>
 <style>
 .btn{
 margin:0px;
 

 
 </style>
<tr bgcolor="#CCCCCC"><td><?php echo $i;?> </td><td><?php echo $cust_name; ?></td><td><?php echo $acc_no;  ?></td><td><?php echo $payment_date;  ?></td><td><?php echo  $payment_mode;?></td><td><?php echo  $payment_for_desc;?></td><td><?php echo $amount_paid;?> </td><td><?php echo $transaction_id;?> </td><td><?php echo $date_entered;?> </td><td><?php echo "";?> </td><?php
                          

			 
 }
 

			
}

?>
<tr bgcolor="#CCCCCC"><td><?php echo ''; ?></td><td><?php echo '';  ?></td><td><?php echo '';  ?></td><td><?php echo '';?> </td><td><?php echo '';?></td><td><?php echo 'Total';?></td><td><?php echo $total_amount;?></td><td><?php echo $net_paid;?> </td></tr>
</tr>


</table>
</fieldset>

</div>
