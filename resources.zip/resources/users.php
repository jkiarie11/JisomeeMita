
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:10px 10px 10px 10px;width:900px;align:center;}
#disc{position:relative; left:5px; top:10px; border:1px solid  #CCCCFF;width:890px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}
</style>
<div id="active_accounts">
<fieldset><legend>Actions</legend>
    
    <a href="?choice=add_user">
        Add User
    </a>  &nbsp;
    
    <a href="?choice=edit_user">
        Edit User
	</a>
<div id="disciplinary">
<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>#No</th><th>User Name</th><th>Full Name</th><th>Designation</th><th>Region Name</th></tr>
<?php 

 $i=0;
  
 $query="select username,contactname,type,region_name from user left join regions on regions.region_code = user.region_code   ";
 $result=mysql_query($query);

 
 while($rows=mysql_fetch_array($result)){
  

             $username = $rows["username"];
			$contactname= $rows['contactname'];
                        $designation= $rows['type'];
                        $region_name= $rows['region_name'];
			 

		$i++;		  
							  
			  
		// echo"<tr bgcolor='#CCCCCC'>";	  
			 
 ?>
<tr bgcolor="#CCCCCC"><td><?php echo $i?> </td><td><?php echo '<a href="std_rollovers.php?choice=edit_user&varname='.$username.'">'.$username.'</a>';?> </td><td><?php echo $contactname;?></td><td><?php echo $designation;?></td><td><?php echo $region_name;?></td></tr>
<?php 
			 }
 
 




?>


</table>
</fieldset>

</div>
