<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Customer Detailed Statement</title>
</head>
    <link rel="stylesheet" href="./jquery-ui-1.10.4/themes/base/jquery.ui.all.css">
<script src="./jquery-ui-1.10.4/jquery-1.10.2.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.core.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.widget.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.datepicker.js"></script>
        
        <script>
	$(function() {
		$( "#datepicker" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
  $( "#datepickerto" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
	});
	</script>

<body>
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:830px;align:center;}
#disc{position:relative;border:1px solid  #CCCCFF;width:830px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}

#search_regulator{
margin-left:145px;
margin-right:100px;

height:auto;

}
#invoice_dv{
margin-left:10px;
margin-right:10px;

}
#payment_tbl{
margin-left:10px;
margin-right:10px;


height:auto;


}
#invoice_tbl{
margin-left:10px;
margin-right:10px;


height:auto;
}

.heads{
left:50px; top:100px;

}
.heads1{

}
#summary_headers{
margin-top:40px;
}
</style>
<div id="active_accounts">
    
<div id="disciplinary">

<!--   account name-->
<style>
.acc_nm{
left:20px; top:230px; position:absolute; font-weight:bold;

}
.cust_name{
left:150px; top:230px; position:absolute; font-weight:bold;
}
.meter_no_lbl{
left:500px; top:230px; position:absolute; font-weight:bold;}
.meter_no_db{
left:700px; top:230px; position:absolute; font-weight:bold;
}
</style>
<!--   payments-->	
<div id="payment_tbl">  
    <form action="#" method="post" >
        <fieldset id="search_regulator"><legend>Actions</legend> 
        <label for="label"  class="search" title="Account No"> Account No
          </label>
        
        <input type="text" name="acc_name" id="search_field" class="text" value="<?php if(isset($_POST['acc_name'])) echo $_POST['acc_name']; ?>"  />
 
 &nbsp;&nbsp; &nbsp;&nbsp;
 <label for="label"  class="search" title="Account No">  From
          </label>
         
    <input type="text" name="datefrom" id="datepicker" value="<?php  echo $search_value_from; ?>"   />
    
    &nbsp;&nbsp; &nbsp;&nbsp;
    <label for="label"  class="search" title="Account No">  To
          </label>
          
     <input type="text" name="dateto" id="datepickerto" value="<?php  echo $search_value_to; ?>"  />
     <input type="submit"  name="search_account" id="search_btn"  value="Search"  /><br><br/>
		   
                       
 </fieldset>
                     

</form>
<fieldset id="payment_fieldset"><legend align="center">Customer Detailed Statement</legend>

	  
<table id="disc"><tr bgcolor="#000000"><th>Date</th><th>Transaction ID</th><th>Transaction Amount</th><th>Balance</th></tr>
<?php 

include("../includes/studentsconnect1.php");



echo"<tr bgcolor='#CCCCCC'>";
 ?>
 
 <?php 
 
  if(isset($_POST['search_account'])){
	

	$search_value_from=mysql_real_escape_string($_POST['datefrom']);
        $search_value_to=mysql_real_escape_string($_POST['dateto']);
        $date_from=substr($search_value_from,6,4).'-'.substr($search_value_from,3,2).'-'.substr($search_value_from,0,2);
        $date_to=substr($search_value_to,6,4).'-'.substr($search_value_to,3,2).'-'.substr($search_value_to,0,2);
        $ls_acc_no=mysql_real_escape_string($_POST['acc_name']);
	

	
	
	

}



if (strlen($date_from) > 3) {
  $querynn="select entry_time,acc_no,last_cms_balance from account_details where acc_no = '$ls_acc_no' and last_cms_balance > 0  union "
	. "select periodbegin,invoice_no, amount"
        . " from invoice where  invoice.periodbegin between '$date_from' and '$date_to' and  invoice.acc_no ='$ls_acc_no' and monthly_invoice = 1 "
        . " union select reading_date,mobile_no,amount from account_reading where acc_no = '$ls_acc_no' "
        . " and month( reading_date ) = month(now()) AND year(reading_date) = year(now()) "
        . " and reading_date  between '$date_from' and '$date_to'"
        . " union select payment.date,payment.invoice_no , payment.amount*-1 from payment where acc_no = '$ls_acc_no' "
        . " and  payment_for in (1,3) and payment.date between '$date_from' and '$date_to' "
        . "order by 1";
        
   /* $querynn="select periodbegin,invoice_no, amount"
        . " from invoice where  invoice.periodbegin between '$date_from' and '$date_to' and invoice.acc_no ='$ls_acc_no' and monthly_invoice = 1"
        . "order by invoice.periodbegin";*/
  
   
}
else {
  if(strlen($ls_acc_no) > 2 ){
  $querynn= "select entry_time,acc_no,last_cms_balance from account_details where acc_no = '$ls_acc_no' and last_cms_balance > 0 union "
        ."select periodbegin,invoice_no, amount"
        . " from invoice where   invoice.acc_no ='$ls_acc_no' and monthly_invoice = 1 "
        . " union select reading_date,mobile_no,amount from account_reading where acc_no = '$ls_acc_no' "
        . " and month( reading_date ) = month(now()) AND year(reading_date) = year(now()) "
        . " union select payment.date,payment.invoice_no , payment.amount*-1 from payment where acc_no = '$ls_acc_no' "
        . " and  payment_for in (1,3)  order by 1";
        }
}

//echo $querynn;

$resultnn=mysql_query($querynn);
while($rownn=mysql_fetch_array($resultnn)){
    $reading_date=$rownn['entry_time'];
    $invoice_no=$rownn['acc_no'];
    $amount=$rownn['last_cms_balance'];
    /*$balance=$rownn['meter_no'];
    $dt_inv=$rownn['periodbegin'];
    $meter_no=$rownn['meter_no'];*/

    //calculating the balance
    $balance=$balance+$amount;
    $tester=substr($balance,0);
   if($tester=="-"){
  /////  $balance=substr($balance,1);


}
else{
  //  $balance="(".$balance.")";

} 
 ?>
 <td><?php echo $reading_date;?></td><td><?php echo  $invoice_no;?></td><td><?php echo $amount;?></td><td><?php echo $balance;?></td></tr>
 <?php
	}
 
 ?>

</table>

</fieldset>
 </div>
<!--   balance-->	

<style>
.bal_lbl{
left:400px; top:0px; position:relative; font-weight:bold;
}
.bal_thing{
left:20px; top:0px; position:relative; font-weight:bold;

}
</style> 
<div  id="summary_headers">

<?php

?>

	 <!-- <p  class="bal_lbl">Balance:<label class="bal_thing"><?php //echo  ($balance); ?></label> </p>-->
	  
	  </div>



</div>

</body>
</html>
