<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

<div id="view_account">
    
    
    
  <fieldset id="search_regulator"><legend>Actions</legend>   
    
    <label for="label"  class="search" title="Account No"> Month
          </label>
          <input type="text" name="acc_nos" id="search_field" class="text" value="<?php echo date('M-Y'); ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  /><br><br/>
                       
           </fieldset>
        
 </div>	    
        
        
        
         </form>
 </div>	   

<div id="header_lbl">
<form action="#" method="post" >
        
        class="text" value="<?php echo date('M-Y');
            
$meter_no_array[$x]
        $reading_date_array[$x]
        $prev_reading_array[$x]]"
        . "$cur_rd_array[$x]
        $unit_total_array[$x]
        $acc_no_array[$x]
        $bill_amount_array[$x]

