<style>
.labels{
position:absolute;
margin-left:200px;
margin-top:2px;
margin-bottom:2px;




}
#acc_combo{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#label{
position:relative;
margin-left:100px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}
#acc_combo1{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:20px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-left:50px;
margin-right:350px;

}
#create_acc_btn{
margin-left:170px;
height:25px;
}
#create_acc_btn:hover{
margin-left:170px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:600px; width:270px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:250px; position:absolute;

padding:5px;
background-color:#FF6633;



}
#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}
</style>


<style>
.search{
position:absolute;
margin-left:100px;

}
#search_field{
position:absolute;
margin-left:500px;

}
#search_btn{
position:absolute;
margin-left:680px;

}
#search_regulator{
margin-left:50px;
margin-right:100px;
height:50px;

}
</style>


<?php 
$result="";

$results="Alerts!";

if(isset($_POST['search_account'])){

$search_value=mysql_real_escape_string($_POST['acc_name']);

 
 $querynn="select * from account_details where acc_no = '$search_value' ";
 $resultnn=mysql_query($querynn);
 while($rownn=mysql_fetch_array($resultnn)){
     $account_no=$rownn['acc_no'];
     $meter_no_select=$rownn['meter_no'];
     

    $acc_names=$rownn['customer_name'];
 

 
 }
}

?>

<div id="create_new_account">

<fieldset id="search_regulator"><legend>Actions</legend>
  <form method="post" action="#" >

		<label for="label"  class="search" title="Account Name"> Account No:
          </label>
          <input type="text" name="acc_name" id="search_field" class="text"
		   value="<?php if(isset($_POST['acc_search'])) echo $_POST['acc_search']; ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
		
      </form>
	  </fieldset>


<form enctype="multipart/form-data" action="#" method="post" id="new_acc_fieldset">
<fieldset ><legend>Enter New Reading Details.</legend> 

		<label for="label" title="Please Enter  Account No" class="labels">Account No:
          </label><br />
          <input type="text" name="account_no" id="label" class="text" value="<?php echo htmlentities(test_req('account_no',$account_no));   ?>" readonly/><br />
          
           <label for="label" title="Please Enter Customer Name" class="labels">Customer Name:
          </label><br />
          <input type="text" name="customer_name" id="label" class="text" value="<?php echo htmlentities(test_req('customer_name',$acc_names));  ?>" readonly/><br />

		  <label for="label" title="Please Enter Meter No" class="labels">Meter No:
          </label><br />
          <input type="text" name="meter_no" id="label" class="text" value="<?php echo htmlentities(test_req('meter_no',$meter_no_select));  ?>" readonly/><br />
          
         


          <label for="label" title="Please Enter Reading" class="labels">Reading
          </label><br />
		  <input type="text" name="reading" id="label" class="text" value="<?php if(isset($_POST['reading']))echo $_POST['reading']; ?>" /><br />
		  
          
		  <label for="label" title="Please Enter the Meter Reader" class="labels">Meter Reader Name
          </label><br />
          <input type="text" name="payer" id="label" class="text" value="<?php if(isset($_POST['payer'])) {echo $_POST['payer'];}
		   ?> " /><br />
          
          
		  
		  File:<input name="uploaded" type="file" maxlength="20" /><input type="submit" name="upfile" value="Save Readings">
 
         
</fieldset>
</form>
    

   

<?php

function get_file_extension($file_name) {
    return end(explode('.',$file_name));
}
 
function errors($error){
    if (!empty($error))
    {
            $i = 0;
            while ($i < count($error)){
            $showError.= '<div class="msg-error">'.$error[$i].'</div>';
            $i ++;}
            return $showError;
    }// close if empty errors
} // close function
 
 

 


function test_req($key, $default = '') {
    if(isset($_REQUEST[$key]) and
       !empty($_REQUEST[$key])) {
        return $_REQUEST[$key];
    } else {
        return $default;
    }
}

/////////////////////////////////////////////////



////////////////////////////////////// End of function of smslistener

function calc_bill($reading,$reading_todate,$consumption,$basic_charge,$prev_basic_charge,$mysqli) {
	
	$amount=0;
        $amount2=0;
        
        $k=0;
        
        //echo "Reading is $reading Reading todate is $reading_todate Consumption is $consumption";
        //return;
      
       if(strlen($reading_todate) == 0){
           $reading_todate=0;
           
       }
       
     //  echo 'reading is '.$reading.' reading to date is '.$reading_todate.'cosumption is '.$consumption.'<BR>';
       
       $reading = $reading_todate + $consumption;
       
     //  echo 'reading is '.$reading.' reading to date is '.$reading_todate.'<BR>';
	
	////////////////////////////////////
	$amount1=0;
        
        
        
                       
        $remainder_reading = $reading ;
        
        
       
       
	
	$query = "SELECT id,band_start,band_end,water_rate FROM billing_rates order by id";
        
     //   echo $query;
        
       
         $result2=mysql_query($query);
         
          //while($rows=mysql_fetch_array($result2)){
      //  if ($result = $mysqli->query($query)) { //small if
            $i = 0;
            //echo 'now in the loop';
            
            $reading_applied = 0;
            $remainder_reading = $consumption;
            $consumption_todate=$reading_todate+$consumption;
            
            //while ($obj = $result->fetch_object()) {
            
             while($rows=mysql_fetch_array($result2)){
            
                
                

                
                $i ++;
               // echo 'amount 2 is '.$amount2.' and  i is '.$i.'<BR>';
                $id=$rows['id'] ;
                $band_start=$rows['band_start'] ;
                $band_end=$rows['band_end'] ;
                $water_rate=$rows['water_rate'] ;
                

                

                $band_diff[$i] = ($band_end - $band_start) + 1;
                $water_rates[$i] = $water_rate;
                
                 $prev_band_end = $current_band_end;
                 $current_band_end=$band_end;

            //   echo 'checking : band end is '.$band_end.' reading todate is '.$reading_todate.' reading is '.$reading.' remainder reading is '.$remainder_reading.'<BR>';
                if ($band_end > $reading_todate ) {
                  
              
                    if ($band_end >= $consumption_todate ) {

                             $reading_applied = $remainder_reading; 
                             $remainder_reading=0;




                      }
                      else {
                         
                          $reading_applied=$current_band_end - $prev_band_end;

                          $remainder_reading=$consumption_todate-$band_end;






                          //}

                      }
                



                
                $amount = $reading_applied * $water_rate;
               // echo 'reading applied is '.$reading_applied.' basic charge is '.$basic_charge.' water rate is '.$water_rate.' therefore amount is'.$amount.' and amount 2 is '.$amount2.'<BR>';
                
          
                
                if($i==1){
                    if($amount==0){
                        $j=1;
                        if($prev_basic_charge>0){
                            
                        }
                        else {
                            $amount2=$basic_charge;
                        }
                        
                    }
                }
                
                
                $amount2 = $amount2 + $amount;
                
                
                
                
                if ($remainder_reading==0){
                    break;
                }
                
            

             }//end if now
             
             if($j==1){
                 
            
                if($i>1){
                    $amount2=$amount2-50;
                }
             }
             
              } //end while now
      

           //echo 'now out of while '.$amount2.'<BR>';
           
          

            return $amount2;
                
      //  }//end if
			
		
	
} //end function







if(isset($_POST['upfile'])) {
        
	
		$expected = array('acc_no','meter_no','reading','payer');
		$required = array('acc_no','meter_no','reading','payer');
		$missing = array();

                foreach ($_POST as $key => $value) {
                    $temp = is_array($value) ? $value : trim($value);
                    if (empty($temp) && in_array($key, $required)) {
                        array_push($missing, $key);
                     }
                    elseif (in_array($key, $expected)) {
                        ${$key} = $temp;
                                }
                        }
                        if(!empty($missing)){
                                $result = "Please enter the highlighted values.";
                        }

                        if (!is_numeric($_POST['reading'])||($_POST['reading'] < 1)){
                                $result = "The reading can only contain numerical values.";
                        }


                

               
                ////inserting  the payments created 
                if(isset($_POST['upfile'])&& !$result) {
                   
                    
                  
                    
                    if(get_file_extension($_FILES["uploaded"]["name"])!= 'jpg')
                        {
                            $error[] = 'Only JPG files accepted!';
                            echo 'Only JPG files accepted!';
                            return;
                            
                           }
 
                    if (!$error){

                        $logged_in = "'Admin On ".date("d/m/y")."'";
 
                        $tot = 0;
                      //  $handle = fopen($_FILES["uploaded"]["tmp_name"], "rb");
                        
                        $reader_image = file_get_contents($_FILES['uploaded']['tmp_name']);
                        
                        if(!$reader_image) {
                            echo 'reader image not stored';
                            return;
                        }
                       
                        //echo $pdf_statement;
                    

                      //  fclose($handle);
                    
                    }
                    
                    //$acc_nos=$_POST['acc_nos'];
                    $acc_name=$_POST['account_no'];
                    $meter_no=$_POST['meter_no'];

                    $reading=$_POST['reading'];
                    $payer=$_POST['payer'];

                    /////check if  the account number and meter no are for a specified customer
                    $query="select count(*),phone_no from account_details where acc_no='$acc_name' and meter_no= '$meter_no' group by phone_no" ;

                    $result=mysql_query($query);

                    $count=mysql_result($result,0,0);





                    if($count==0)
                    {
                       $result='That Customer with that Account Number and Meter No does not exist';

                    }
                    else{
                        $mobile_no=mysql_result($result,0,1); 
                        
                        
                       






                        $previous_reading = 0;


                        $querys="select current_reading from account_reading where acc_no='$acc_name'";
                        $results=mysql_query($querys);

                        while($rows=mysql_fetch_array($results)){

                            $previous_reading=$rows['current_reading'] ;




                          }
                          
                          //get standard charge

                        $query = "SELECT standard_charge FROM billing_settings";
                        $results=mysql_query($query);
                        
                        while($rows=mysql_fetch_array($results)){

                            $standard_charge=$rows['standard_charge'] ;
                            
                          }
                          
                           if($standard_charge == 0) {
                                $standard_charge = 50;
                            }
                            
                $query = "SELECT standard_charge  FROM invoice where acc_no='$acc_name' and month( periodbegin ) = month( now())";
                $results=mysql_query($query);
    // echo $query."<BR>";

            
                        while($rows=mysql_fetch_array($results)){

                            $previous_standard=$rows['standard_charge'] ;
                            
                          }
      
     
                            
                            
     
      









 
 

 

                                //////checking the previous readings
                            $query="select count(*) from account_reading where acc_no='$acc_name' and meter_no= '$meter_no'" ;
                            $result=mysql_query($query);

                            $count=mysql_result($result,0,0);

                            if($count==0)
                            {
                               $previous_reading=0.0;
                               
                               
                               //$amount = calc_bill($reading,$sum_month);
                               
                               $consumption = $reading - $previous_reading;
                               
                               //echo 'consumption outside is'.$consumption;
                               
                            //   echo 'previous standard is '.$previous_standard."<BR>";
                               
                               $amount = calc_bill($reading,$sum_month,$consumption,$standard_charge,$previous_standard);

                                

                        
            
                                
                              
                            if($previous_standard==0){
                                $saved_std_charge=$standard_charge;
                            }
                            else {
                                $saved_std_charge=0;
                            }
                           

                               $query="insert into account_reading
                                   (meter_no, reading_date, current_reading,meter_reader, acc_no,previous_reading,mobile_no,consumption,amount,reader_image)
                                   values
                                   ('$meter_no',NOW(),'$reading', '$payer','$acc_name','$previous_reading','$mobile_no','$reading','$amount','" . addslashes(file_get_contents($_FILES['uploaded']['tmp_name'])) . "')";


                                   $result=mysql_query($query)
                                   or die(mysql_error());

                           ////inserting the values from the account_reading table  to the invoices table ready for  invoicing

                                $querys="insert into invoice
                                   (meter_no, pr_units,current_units,total_units, acc_no,periodbegin,invoice_no,amount,invoice_amount,standard_charge)
                                   values
                                   ('$meter_no','$previous_reading','$reading','$reading','$acc_name',NOW(),0,'$amount','$amount','$saved_std_charge')";

                               //  echo $querys;
                                   $result1=mysql_query($querys)
                                or die(mysql_error());
                                   
                                 
                                   
                   		$querys = "update account_details set account_status = 'active'
                                where acc_no='$acc_name'";
                                
                                 $result2=mysql_query($querys)
                                or die(mysql_error());

                                $result='Your Reading Has been entered successfully ';



                            }
                            else
                            {
                     
                  
                               
                                $query_sum = "SELECT sum( consumption ) AS summonth FROM account_reading WHERE acc_no ='$acc_name'
                                AND month( reading_date ) = month( now())  ";



                                $result=mysql_query($query_sum);



                                $sum_month=mysql_result($result,0,0);
                                
                                
                    
                                
                                 $consumption = $reading - $previous_reading;
                                //  echo 'previous standard is '.$previous_standard."<BR>";
                                 
                              //   echo 'reading is '.$reading.' and consumption  is '.$consumption;

                                //$amount = calc_bill($reading,$sum_month);
                                $amount = calc_bill($reading,$sum_month,$consumption,$standard_charge,$previous_standard);

                               
                              //  return;
                                
                               
                               
                               //////////////////////////////
                                $used=($reading-$previous_reading);

                                  $querym="select * from  account_reading where acc_no='$acc_name' and meter_no= '$meter_no' order by reading_date desc limit 1";
                                       $resultm=mysql_query($querym);
                                       while($rowm=mysql_fetch_array($resultm)){
                                       $prev_reads=$rowm['current_reading'];
                                       $make_curr_reads=$rowm['previous_reading'];
                                       $previous_reading=$prev_reads;
                                       $current_reads= $reading;
                                       $consumption = $reading - $previous_reading;
                                       
                                       
                                       if($previous_standard==0){
                                $saved_std_charge=$standard_charge;
                            }
                            else {
                                $saved_std_charge=0;
                            }

                                               $query="insert into account_reading
                                      (meter_no, reading_date, current_reading,meter_reader, acc_no,previous_reading,mobile_no,amount,consumption,reader_image)
                                      values
                                      ('$meter_no',NOW(),'$reading', '$payer','$acc_name','$previous_reading','$mobile_no','$amount','$consumption','" . addslashes(file_get_contents($_FILES['uploaded']['tmp_name'])) . "')";

                                      
                                    $result1=mysql_query($query)
                                    or die(mysql_error());

                                    ////inserting the values from the account_reading table  to the invoices table ready for  invoicing
                                     $querys="insert into invoice
                                            (meter_no, pr_units,current_units,total_units, acc_no,periodbegin,invoice_no,amount,invoice_amount,standard_charge)
                                            values
                                            ('$meter_no','$previous_reading','$current_reads', '$used','$acc_name',NOW(),0,'$amount','$amount','$saved_std_charge')";
                                     
                                     
                                


                                     $resultss=mysql_query($querys)
                                        or die(mysql_error());
                                     
                                     

                                    $result='Your Reading Has been entered successfully ';


                                }

                            



                        }
                    }
                }
				
	}		
		
  ?>
</div>
<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
</div>


