
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:900px;align:center;}
#disc{position:relative; left:5px; top:2px; border:1px solid  #CCCCFF;width:890px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}
</style>
<div id="active_accounts">
<fieldset><legend>Customer Detailed Summary</legend>
 <form method="post" action="#" >
  
  
		<label for="label"  class="search" title="Account Name"> Account No
          </label>
          <input type="text" name="acc_name" id="search_field" class="text" value="<?php if(isset($_POST['acc_name'])) echo $_POST['acc_name']; ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
		
      </form>
<?php
function checking_billing($units){
     
			if($units<=10){
				$bill=$units*18.71;
			}
			else if($units>10 && $units<=30){
					$bill=(10*18.71)+(($units-10)*28.07);	
			}
			else if($units>30 && $units<=60){
						$bill=(10*18.71)+(20*28.07)+(($units-30)*42.89);				
			}
			else if($units>60){
						$bill=(10*18.71)+(20*28.07)+(30*42.89)+(($units-60)*53.80);
			}


return $bill;
}

 
?>
<div id="disciplinary">

<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>#No</th><th>Acc Name</th><th>Account No</th><th>Raised By</th><th>Current Reading</th><th>[Usage]</th><th>Reading Date </th><th>Bill Amount </th><th>Image </th></tr>
<?php 

if(isset($_POST['search_account'])){
    
     $search_value=mysql_real_escape_string($_POST['acc_name']);
     

    $i=0;
  
$queryss="select * from account_reading,account_details where account_reading.acc_no=account_details.acc_no and account_details.acc_no = '$search_value'  order by  account_reading.reading_date desc";


 $resultss=mysql_query($queryss);


 while($rows=mysql_fetch_array($resultss)){
    $meter_no= $rows['meter_no'];
    $account_no = $rows['acc_no'];
    $reading_dt=$rows['reading_date'];
    $cur_rd=$rows['current_reading'];
    $mt_reader= $rows['meter_reader'];
    $cust_nm=$rows['customer_name'];
    $usage=$cur_rd-$rows['previous_reading'];
    $amount=$rows['amount'];
    $reader_image=$rows['reader_image'];

    $grand_total += $amount;







        $i++;  
                                
                        
                                
                                 
                                
                                         

 ?>
 <style>
 .btn{
 margin:0px;
 

 
 </style>
<tr bgcolor="#CCCCCC"><td><?php echo $i;?> </td><td><?php echo $cust_nm; ?></td><td><?php echo $account_no;  ?></td><td><?php echo $mt_reader;  ?></td><td><?php echo  $cur_rd;?></td><td><?php echo $usage;?> </td><td><?php echo $reading_dt;?> </td><td><?php echo $amount;?> </td><td><?php if(strlen($reader_image) >0) echo '<a href="std_rollovers.php?choice=view_reading_image&varname='.$account_no.'">View Image</a>';?> </td><td><?php echo "";?> </td><?php
                          

			 
 }
 

			
}

?>
</tr>

<tr bgcolor="#CCCCCC"><td><?php echo ' ';?> </td><td><?php echo ''; ?></td><td><?php echo '';  ?></td><td><?php echo '';  ?></td><td><?php echo '';?></td><td><?php echo '';?> </td><td><?php echo 'Total';?> </td><td><?php echo $grand_total;?> </td></tr>


</table>
</fieldset>

</div>
