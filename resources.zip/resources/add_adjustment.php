<style>
.labels{
position:absolute;
margin-left:200px;
margin-top:2px;
margin-bottom:2px;




}
#acc_combo{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#label{
position:relative;
margin-left:100px;
height:20px;
width:320px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-left:50px;
margin-right:350px;

}
#create_acc_btn{
margin-left:170px;
height:25px;
}
#create_acc_btn:hover{
margin-left:170px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:600px; width:270px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:250px; position:absolute;

padding:5px;
background-color:#FF6633;



}
#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}
</style>


<style>
.search{
position:absolute;
margin-left:100px;

}
#search_field{
position:absolute;
margin-left:500px;

}
#search_btn{
position:absolute;
margin-left:680px;

}
#search_regulator{
margin-left:145px;
margin-right:100px;
height:50px;

}
</style>


<div id="active_accounts">
<div id="disciplinary">

<?php  
$result="";
$results="Alerts!";

$logged_username = $_SESSION['username'];





?>

<div id="create_new_account">




<form action="#" method="post" id="new_acc_fieldset">
<fieldset ><legend>Adjustment Reasons</legend>

		<label for="label" title="Please Enter  Adjustment Reason" class="labels"<td align="right"><font color="#ff0000">*</font>Adjustment Reason:
          </label><br />
		  <input type="text" name="adjustment_reason" id="label" class="text" maxlength="10" value="<?php  if(isset($_POST['adjustment_reason'])) echo $_POST['adjustment_reason']; ?>" /><br />
		  
		  <label for="label" title="Please Enter The Description" class="labels">Description:
          </label><br />
		  <input type="text" name="description" id="label" class="text" value="<?php if(isset($_POST['description'])) echo $_POST['description']; ?>" /><br />
	
                 
              
		  
		  <input type="submit"  name="payments" id="create_acc_btn"  value="Save Settings"  />
         
</fieldset>
</form>

<?php




if(isset($_POST['payments'])) {
	
		$expected = array('user_name', 'password','account_designation');
		$required = array('user_name', 'password','account_designation');
		$missing = array();

			foreach ($_POST as $key => $value) {
			$temp = is_array($value) ? $value : trim($value);
			if (empty($temp) && in_array($key, $required)) {
			array_push($missing, $key);
				}
			elseif (in_array($key, $expected)) {
			${$key} = $temp;
					}
				}
				if(!empty($missing)){
					$result = "Please enter the mandatory values.";
				}
				


				
			}


			
			echo $result;
			////inserting  the payments created 
				if(isset($_POST['adjustment_reason'])&& !$result) {
                                    $adjustment_reason=$_POST['adjustment_reason'];
                                    $description=$_POST['description'];
				
                                
                                
                                    
                                
                                
				
				
				

				
				
				


				
				
				//$_POST['meter_no'];
				
					$query="replace into adjustment_reasons
					(adjustment_reason,reason_description)
					values
					( '$adjustment_reason','$description')";
					
					
					$result1=mysql_query($query)
                                        or die(mysql_error());
				
                                        $result='Adjustment reason has been inserted successfully ';


                             
				
		}		
		
  ?>
</div>
<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
</div>