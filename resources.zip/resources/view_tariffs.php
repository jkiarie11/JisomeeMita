
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:900px;align:center;}
#disc{position:relative; left:5px; top:2px; border:1px solid  #CCCCFF;width:890px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}
</style>
<div id="active_accounts">
<fieldset><legend>Actions</legend>
    
    <a href="?choice=add_tariff">
        Add Tariff
	</a>
<fieldset><legend>View Tariffs</legend>
 <form method="post" action="#" >
  
  
		<label for="label"  class="search" title="Account Name"> Account No
          </label>
          <input type="text" name="acc_name" id="search_field" class="text" value="<?php if(isset($_POST['acc_name'])) echo $_POST['acc_name']; ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
		
      </form>
<?php
function checking_billing($units){
     
			if($units<=10){
				$bill=$units*18.71;
			}
			else if($units>10 && $units<=30){
					$bill=(10*18.71)+(($units-10)*28.07);	
			}
			else if($units>30 && $units<=60){
						$bill=(10*18.71)+(20*28.07)+(($units-30)*42.89);				
			}
			else if($units>60){
						$bill=(10*18.71)+(20*28.07)+(30*42.89)+(($units-60)*53.80);
			}


return $bill;
}

 
?>
<div id="disciplinary">

<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>#No</th><th>Acc Name</th><th>Account No</th><th>Tariff Code</th><th>Tariff Description</th></tr>
<?php 

if(isset($_POST['search_account'])){
    
     $search_value=mysql_real_escape_string($_POST['acc_name']);
     

    $i=0;
  
$queryss="select * from account_tariffs a,tariff_codes t,account_details d where a.tariff_code=t.tariff_code and a.acc_no = d.acc_no and a.acc_no = '$search_value' ";

//echo $queryss;
 $resultss=mysql_query($queryss);


 while($rows=mysql_fetch_array($resultss)){
    $account_no= $rows['acc_no'];
  $tariff_code= $rows['tariff_code'];
   $tariff_description = $rows['tariff_description'];
   $cust_nm=$rows['customer_name'];
   
   

   







        $i++;  
                                
                        
                                
                                 
                                
                                         

 ?>
 <style>
 .btn{
 margin:0px;
 

 
 </style>
<tr bgcolor="#CCCCCC"><td><?php echo $i;?> </td><td><?php echo $cust_nm; ?></td><td><?php echo $account_no;  ?></td><td><?php echo $tariff_code;  ?></td><td><?php echo  $tariff_description;?></td><td><?php echo "";?> </td><?php
                          

			 
 }
 

			
}

?>
</tr>

<tr bgcolor="#CCCCCC"><td><?php echo ' ';?> </td><td><?php echo ''; ?></td><td><?php echo '';  ?></td><td><?php echo '';  ?></td><td><?php echo '';?></td><td><?php echo '';?> </td></tr>


</table>
</fieldset>

</div>
