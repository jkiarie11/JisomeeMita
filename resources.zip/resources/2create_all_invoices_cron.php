<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Create Many Invoices</title>
</head>


<body>
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:850px;align:center;}
#disc{position:relative; left:5px; top:2px; border:1px solid  #CCCCFF;width:890px; margin-top:10px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}
#active_accounts{
margin-left:10px;
margin-right:170px;


height:auto;
}
#alert_me{
border:1px solid #993300; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; padding:10px;
background-color:#FFFFCC; color:#FF0000;

}
#invoices_btn{

border:1px solid  #66CC99; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; padding:5px;
background-color:#99CCFF; color:#FF0000;
margin-right:80px;
margin-top:150px;
margin-left:10px;
background-image:url(../images/uninvoiced.png) repeat;

}
#invoices_btn:hover{

border:1px solid  #66CC99; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; padding:5px;
background-color:#6633CC; color:#FFFFFF;
margin-right:80px;
margin-left:10px;
}
#header_lbl{
position:absolute;
left:10px; top:50px;
}
#seperator{
border-top:1px solid  #66CC99; width:900px; margin-top:50px;

}
</style>
<div id="active_accounts">
<fieldset><legend align="center">Bill Customers</legend>
<?php
include("../includes/studentsconnect1.php");

function checking_billing($units){
     
			if($units<=10){
				$bill=$units*18.71;
			}
			else if($units>10 && $units<=30){
					$bill=(10*18.71)+(($units-10)*28.07);	
			}
			else if($units>30 && $units<=60){
						$bill=(10*18.71)+(20*28.07)+(($units-30)*42.89);				
			}
			else if($units>60){
						$bill=(10*18.71)+(20*28.07)+(30*42.89)+(($units-60)*53.80);
			}


return $bill;
}

global  $invoice_raised;
global  $new_invoice;
$invoice_raised=false;

/*////////a function to create an invoice
 function create_invoice($pass_meter_no){
 
 ///counter to increment
 $counter=1;
 ////check validity
 $sql="select count(*) from invoice where invoice_raised='no' and meter_no='$pass_meter_no' order by 1 desc ";
			 $res=mysql_query($sql);
			 $counts=mysql_result($res,0,0);
			 if($counts>0){
			 ///////take the last  invoice 
			 $sql1="select * from invoice where invoice_raised='yes' order by  1 desc limit 1";
			 $res1=mysql_query($sql1);
			 while($rows=mysql_fetch_array($res1)){
			  $inv= $rows['invoice_no'];
			  
			  ///increment the last invoice(creating  a new invoice)
			  $new_invoice=$inv+$counter;
			  $counter++;
			  }
			 
			 }
			 
			 echo  'bbbbbbbbbb  '.$new_invoice;
 
 
 
 }*/
 
  //create_invoice(9007);
?>



<div id="seperator"></div>
<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>#No</th><th>Acc No</th><th>Acc Name</th><th>Meter No.</th><th>Previous Reading</th><th>Current Reading</th><th>[Consumption]</th><th>Bill </th></tr>
<?php 
     $invoice_processed=0;
    $i=0;
    
    $querysc="select billing_month from billing_settings";
       
           $resultsc=mysql_query($querysc);
       while($rowsc=mysql_fetch_array($resultsc)){
          
           $billing_month= $rowsc['billing_month'];
          

       }
  
     if(strlen($billing_month) > 0){
        $querys="select * from account_details where acc_no not in (SELECT acc_no FROM `invoice` WHERE `loan_amount` = 150 and `amount` = 0)  order by  1 asc";
     }
     else{
        $querys="select * from account_details where acc_no not in (SELECT acc_no FROM `invoice` WHERE `loan_amount` = 150 and `amount` = 0)  order by  1 asc";
     }
     
     echo $querys;
    //AND month( period_began ) = month( now())
    $results=mysql_query($querys);
    while($rows=mysql_fetch_array($results)){
       $meter_no= $rows['meter_no'];
      
       $meter_no_array[$i] = $rows['meter_no'];
       
                
       
       $acc_no= $rows['acc_no'];
       $acc_no_array[$i]= $rows['acc_no'];
       $big=$rows['last_cms_reading']+10;
       $big_array[$i]=$rows['last_cms_reading'];
       $cur_rd=$rows['last_cms_reading'];	
       $cur_rd_array[$i]=$rows['last_cms_reading'];
       $prev_reading= $rows['last_cms_reading']; 
       $prev_reading_array[$i]= $rows['last_cms_reading']; 
       $bill_amount =0;
       $bill_amount_array[$i] = 0;
       $std_charge=0;
       $std_charge_array[$i] =0;
       $total_bill=$bill_amount+$std_charge;
       $total_water_array[$i]=$total_bill;
       $total_amount_array[$i] =0;
       $reading_date_array[$i] = $rows['reading_date'];
                                  ////////////////////////////////////generating  the names of the customers
       $querysc="select distinct  account_details.customer_name from account_details,invoice where account_details.acc_no=invoice.acc_no and invoice.acc_no='$acc_no'";
       $resultsc=mysql_query($querysc);
       while($rowsc=mysql_fetch_array($resultsc)){
           $cust_name= $rowsc['customer_name'];
           $cust_name_array[$i]= $rowsc['customer_name'];

       }

        /////creating the previous reading

        $unit_total=$big-$small;
         $unit_total_array[$i]=$big-$small;

        $i++; 
 ?>
 <style>
 .btn{
 margin:0px;
 
 }
 
 </style>
<tr bgcolor="#CCCCCC"><td><?php echo $i;?> </td><td><?php echo $acc_no; ?></td><td><?php echo $cust_name; ?></td><td><?php echo $meter_no;  ?></td><td><?php echo  $prev_reading;?></td><td><?php echo $cur_rd;?> </td><td><?php echo $total_units;?> </td><td  width="100px" style="color:#FF0000; font-family:Geneva, Arial, Helvetica, sans-serif; font-weight:bold; font-size:14px;" ><?php echo $total_bill; ?></td>
                          

	<?php
	

	
 }
 
//}
if(isset($_POST['raise_invoices'])){  //comment for production
    echo 'now start';
    $x=0;
    $m=0;
    

    $counter=1;
    
   //  $querysc="select standard_charge from billing_settings";
       
    //       $resultsc=mysql_query($querysc);
     //  while($rowsc=mysql_fetch_array($resultsc)){
          
      //     $standard_charge= $rowsc['standard_charge'];
          

    //   }
       
        
         

       
    
    
    
    for($x=0;$x<$i;$x++)
  {
  $total_amount_array[$x];
  echo "<br>";
  
    $querysc="select loan_amount,loan_balance,repayment_period,interest_amount,interest_balance from account_details where acc_no='$acc_no_array[$x]'";
       
           $resultsc=mysql_query($querysc);
       while($rowsc=mysql_fetch_array($resultsc)){
           $j++;
           $loan_amount= $rowsc['loan_amount'];
           $loan_balance= $rowsc['loan_balance'];
           $repayment_period= $rowsc['repayment_period'];
           $repayment_amount =  $loan_amount/$repayment_period;
           if ($repayment_amount > $loan_balance) {
               $repayment_amount=$loan_balance;
           }
           $interest_amount= $rowsc['interest_amount'];
           $interest_balance= $rowsc['interest_balance'];
           $interest_repayment = $interest_amount/$repayment_period;
           if ($interest_repayment > $interest_balance) {
               $interest_repayment=$interest_balance;
           }
           $total_loan_repayment = $repayment_amount +$interest_repayment;
       }
    $invoice_amount = $total_amount_array[$x];
  $sum_amount = $total_water_array[$x]+$total_loan_repayment;
  
    $total_amount+= $sum_amount;
  //  echo 'total amount is '.$total_amount;
    
   
     
  
 
       
    
      
    
       $m++;
  
    $querys="insert into invoice
           (meter_no, date_of_invoice,pr_units,current_units,total_units, acc_no,periodbegin,invoice_no,amount,monthly_invoice,invoice_raised,invoice_for,invoice_amount,loan_amount,standard_charge,payment_amount)
           values
            ('$meter_no_array[$x]','$reading_date_array[$x]','$prev_reading_array[$x]]','$cur_rd_array[$x]]','$unit_total_array[$x]','$acc_no_array[$x]','2014-05-31',0,'$total_amount_array[$x]',1,'done',1,'$bill_amount_array[$x]','$total_loan_repayment','$std_charge_array[$x]','$payment_amount')";
    
    

           // echo $querye;
           $resulte=mysql_query($querys)
            or die(mysql_error());
           
       
      
           
      
      $invoice_processed=1;
      
      $resultsss = '$m Invoices Processed successfully';
           
           
  }

  

    
}
                


?>
		


</tr>


</table>

<div id="header_lbl">
<form action="#" method="post" >
<input type="submit"  name="raise_invoices" id="invoices_btn"  value="Create All Invoices"  />
<label id="alert_me"><?php if($invoice_processed==1){echo $resultsss;}else{$resultsss='Click The [Create All Invoices] button to Create all the Customers Invoices'; echo $resultsss;}?> </label>
</form>

</div>	
</fieldset>

</div>


</body>
</html>
