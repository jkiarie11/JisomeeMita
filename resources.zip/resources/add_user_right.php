<style>
.labels{
position:absolute;
margin-left:200px;
margin-top:2px;
margin-bottom:2px;




}

.labels2{
position:absolute;
margin-left:100px;
margin-top:2px;
margin-bottom:2px;




}
#acc_combo{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#label{
position:relative;
margin-left:100px;
height:20px;
width:320px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#label2{
position:relative;
margin-left:70px;
height:20px;
width:320px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-left:50px;
margin-right:350px;

}
#create_acc_btn{
margin-left:150px;
height:25px;
}
#create_acc_btn:hover{
margin-left:150px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:600px; width:270px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:250px; position:absolute;

padding:5px;
background-color:#FF6633;



}
#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}
</style>


<style>
.search{
position:absolute;
margin-left:100px;

}
#search_field{
position:absolute;
margin-left:500px;

}
#search_btn{
position:absolute;
margin-left:680px;

}
#search_regulator{
margin-left:145px;
margin-right:100px;
height:50px;

}
</style>


<div id="active_accounts">
<div id="disciplinary">

<?php  

function test_req($key, $default = '') {
    if(isset($_REQUEST[$key]) and
       !empty($_REQUEST[$key])) {
        return $_REQUEST[$key];
    } else {
        return $default;
    }
}

$results="Alerts!";

$ls_search_value = $_GET['varname'];
$ls_screen_code = $_GET['varname2'];

$ls_screen_name = $_GET['varname3'];

//echo $ls_search_value2;

if (strlen($ls_search_value) > 0){
    $search_value =$ls_search_value;
    $query="select * from user  where  username = '$search_value' ";
}

$logged_username = $_SESSION['username'];






?>

<div id="create_new_account">




<form action="#" method="post" id="new_acc_fieldset">
<fieldset ><legend>User Details</legend>

		<label for="label" title="Please View the User Name" class="labels"<td align="right"><font color="#ff0000">*</font>User Name:
          </label><br />
		  <input type="text" name="user_name" id="label" class="text" value="<?php echo htmlentities(test_req('user_name',$ls_search_value));  ?>" readonly/><br />
                  
              <label for="label" title="Please view the screen code" class="labels">Screen Code:
          </label><br />
		   <input type="text" name="screen_code" id="label" class="text" value="<?php echo htmlentities(test_req('screen_code',$ls_screen_code));  ?>" readonly/><br />   
                  
		  
		  <label for="label" title="Please view the screen name" class="labels">Screen Name:
          </label><br />
		   <input type="text" name="screen_name" id="label" class="text" value="<?php echo htmlentities(test_req('screen_name',$ls_screen_name));  ?>" readonly/><br />
                   
                    <label for="label" title="Please assign the right" class="labels">Assign right:
          </label><br />
          <input type="checkbox" name="vehicle" id="label2" ><br><br />
	
                 
    
           
		  
		  <input type="submit"  name="payments" id="create_acc_btn"  value="Save Settings"  /> &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;
                  
                  <a href="std_rollovers.php?choice=security&varname=<?php echo $ls_search_value?>">back</a>
                  
                  
         
</fieldset>
</form>

<?php






                        
                         $user_name=$_POST['user_name'];
                         $user_right=$_POST['user_right'];
                         $allow_right=$_POST['vehicle'];
                          
                         
                         
                         if(strlen($allow_right) > 0){
                             $right_allocated=1;
                         }
                         else {
                            $right_allocated=0; 
                         }
                         
                        
                         
                       
                         
                         
                         
			
			
			////inserting  the payments created 
                        if(isset($_POST['payments'])) {
                            
                            
                            

                           
				
                                    
                                
                                
				
				
				

				
				
				


				
				
				//$_POST['meter_no'];
				
					$query="replace into userights
					(username,screen_code,allowed)
					values
					( '$user_name','$ls_screen_code', '$right_allocated')";
					
					
					$result1=mysql_query($query)
				or die(mysql_error());
				
				$result='Your user right details have been updated successfully ';


                            
				
		}		
		
  ?>
</div>
<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
</div>