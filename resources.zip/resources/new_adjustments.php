<style>
.labels{
position:absolute;
margin-left:200px;
margin-top:2px;
margin-bottom:2px;




}
#acc_combo{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;


}
#label{
position:relative;
margin-left:100px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}
#acc_combo1{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:20px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-left:50px;
margin-right:350px;

}
#create_acc_btn{
margin-left:170px;
height:25px;
}
#create_acc_btn:hover{
margin-left:170px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:600px; width:270px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:250px; position:absolute;

padding:5px;
background-color:#FF6633;



}
#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}
</style>


<style>
.search{
position:absolute;
margin-left:100px;

}
#search_field{
position:absolute;
margin-left:300px;

}
#search_btn{
position:absolute;
margin-left:480px;

}
#search_regulator{
margin-left:50px;
margin-right:100px;
height:50px;

}
</style>
<?php  
$results="Alerts!";

if(isset($_POST['search_account'])){
    
     $logged_username = $_SESSION['username'];

    $search_value=mysql_real_escape_string($_POST['acc_name']);


     $querynn="select * from account_details where acc_no like '%$search_value%' ";
     $resultnn=mysql_query($querynn);
     while($rownn=mysql_fetch_array($resultnn)){
         $account_no=$rownn['acc_no'];
         $meter_no_select=$rownn['meter_no'];


        $acc_names=$rownn['customer_name'];



     }
 
  $query = "select * from adjustment_reasons "; // Run your query
 

$result=mysql_query($query);



$options="";

while ($row=mysql_fetch_array($result)) {
  
    
    $adjustment_reason=$row["adjustment_reason"];
    
   
    
    $reason_description=$row["reason_description"];
    $options.="<OPTION VALUE=\"$adjustment_reason\">".$reason_description.'</option>';
    
} 

$query = "select * from user "; // Run your query
 

$result=mysql_query($query);



$options3="";

while ($row=mysql_fetch_array($result)) {
  
    
    $username=$row["username"];
    
   
    
    $contactname=$row["contactname"];
    $options3.="<OPTION VALUE=\"$contactname\">".$contactname.'</option>';
    
} 



$options2="";
$options2.='<option value="DR">DEBIT</option>';
$options2.='<option value="CR">CREDIT</option>';



}

?>

<div id="create_new_account">

<fieldset id="search_regulator"><legend>Actions</legend>
  <form method="post" action="#" >

		<label for="label"  class="search" title="Account Name"> Account No:
          </label>
          <input type="text" name="acc_name" id="search_field" class="text"
		   value="<?php if(isset($_POST['acc_search'])) echo $_POST['acc_search']; ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
		
      </form>
	  </fieldset>


<form action="#" method="post" id="new_acc_fieldset">
<fieldset ><legend>Enter New Adjustment Details</legend> 

		<label for="label" title="Please Enter  Account No" class="labels">Account No:
          </label><br />
          <input type="text" name="account_no" id="label" class="text" value="<?php echo $account_no; ?>" readonly/><br />
          
           <label for="label" title="Please Enter Customer Name" class="labels">Customer Name:
          </label><br />
          <input type="text" name="customer_name" id="label" class="text" value="<?php echo $acc_names; ?>" readonly/><br />
          
           <label for="label" title="Please Enter Adjustment Type" class="labels">Type Of Adjustment:
          </label><br />
           <SELECT NAME=type_of_adjustment id="acc_combo" <br>>

        <?php echo $options2;?>
        </SELECT>
        <br>

		  <label for="label" title="Please Enter Meter No" class="labels">Reason For Adjustment:
          </label><br />
          <SELECT NAME=reason_for_adjustment id="acc_combo" <br>>

        <?php echo $options;?>
        </SELECT>
        <br>
        
         


          <label for="label" title="Please Enter Amount" class="labels">Amount
          </label><br />
		  <input type="text" name="amount" id="label" class="text" value="<?php if(isset($_POST['amount']))echo $_POST['amount']; ?>" /><br />
		  
		  <label for="label" title="Please Enter the Adjustment Details" class="labels">Adjustment Details:
          </label><br />
		 
	 <input type="text" name="adjustment_details" id="label" class="text" value="<?php echo $adjustment_details; ?>" /><br />
	 
	   <label for="label" title="Please Enter the Approved by" class="labels">Approved By:
          </label><br />
		 
	  <SELECT NAME=approved_by id="acc_combo" <br>>

        <?php echo $options3;?>
        </SELECT>
        <br>
		  
          
		  <label for="label" title="Please Enter the Entered By" class="labels">Entered By
          </label><br />
          <input type="text" name="entered_by" id="label" class="text" value="<?php echo $logged_username;
		   ?> " readonly/><br />
		  
		  <input type="submit"  name="payments" id="create_acc_btn"  value="Save Adjustment"  />
         
</fieldset>
</form>

<?php

$result = "";
if(isset($_POST['payments'])) {
	
		$expected = array('account_no','type_of_adjustment','reason_for_adjustment','amount');
		$required = array('account_no','type_of_adjustment','reason_for_adjustment','amount');
		$missing = array();

                foreach ($_POST as $key => $value) {
                    $temp = is_array($value) ? $value : trim($value);
                    if (empty($temp) && in_array($key, $required)) {
                        array_push($missing, $key);
                     }
                    elseif (in_array($key, $expected)) {
                        ${$key} = $temp;
                                }
                        }
                        if(!empty($missing)){
                                $result = "Please enter the highlighted values.";
                        }

                        if (!is_numeric($_POST['amount'])||($_POST['amount'] < 1)){
                                $result = "The reading can only contain numerical values.";
                        }


                }

                       // echo 'now almost processing'.$result;
                ////inserting  the payments created 
                if(isset($_POST['payments'])&& !$result) {
                    
                    // echo 'now started processing';
                    
                    $account_no=$_POST['account_no'];
                    $reason_for_adjustment=$_POST['reason_for_adjustment'];
                    $type_of_adjustment=$_POST['type_of_adjustment'];
                    
                    $adjustment_details=$_POST['adjustment_details'];
                    $approved_by=$_POST['approved_by'];

                    $amount=$_POST['amount'];
                   // if($type_of_adjustment=='CR'){
                    //   $amount=$amount*-1; 
                  //  }
                    
                 //   echo $type_of_adjustment;
                  //  echo $amount;
                    
                    $payer=$_POST['payer'];
                    
                  
                 

                    $query="insert into adjustments
                       (adjustment_reason, acc_no, amount,adjustment_type,adjustment_date,adjustment_details,approved_by)
                       values
                        ('$reason_for_adjustment','$account_no', '$amount','$type_of_adjustment',NOW(),'$adjustment_details','$approved_by')";
                        
                           
                        
                        //,'$adjustment_details','$approved_by'

                        //echo $query;
                        $result=mysql_query($query)
                        or die(mysql_error());
                        
                        $result='Your Adjustment Has been saved successfully ';

                           


                   
                }
				
			
		
  ?>
</div>
<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
</div>