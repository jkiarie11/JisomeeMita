<style>
.labels{
position:absolute;
margin-left:200px;
margin-top:2px;
margin-bottom:2px;




}
#acc_combo{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}

#acc_paymenttype{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#label{
position:relative;
margin-left:100px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-left:50px;
margin-right:350px;

}
#create_acc_btn{
margin-left:170px;
height:25px;
}
#create_acc_btn:hover{
margin-left:170px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:600px; width:270px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:170px; position:absolute;
padding:5px;
background-color:#FF6633;



}
#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}
</style>


<style>
.search{
position:absolute;
margin-left:20px;

}
#search_field{
position:absolute;
margin-left:150px;

}
#search_btn{
position:absolute;
margin-left:350px;

}
#search_regulator{
margin-left:30px;
margin-right:400px;
height:50px;

}
</style>
<?php  
$results="Alerts!";

if(isset($_POST['search_account'])){

    $search_value=mysql_real_escape_string($_POST['acc_no']);
    
   // $date = "20120217";
 //$my_date = date('ymd', strtotime($date));
 //echo $my_date;


    $querynn="select * from account_details  where account_status='active' AND acc_no like '%$search_value%' ";
    $resultnn=mysql_query($querynn);
    while($rownn=mysql_fetch_array($resultnn)){
    $acc_noss=$rownn['acc_no'];

    $acc_names=$rownn['customer_name'];
    
    
    
    $querynn="select * from payment where acc_no= '$acc_noss' order by date_entered desc";

    $query = mysql_query($querynn); // Run your query
    
   



  

    // Loop through the query results, outputing the options one by one
    while ($row = mysql_fetch_array($query)) {
         $payment_date=$row['text_date'];
         $payment_mode=$row['type_of_payment'];
         $amount_paid=$row['amount'];
         $who_entered=$row['who_entered'];
        
    }

    



    $logged_username = $_SESSION['username'];
    

    


    }
}

?>

<div id="create_new_account">

<fieldset id="search_regulator"><legend>Actions</legend>
  <form method="post" action="#" >

		<label for="label"  class="search" title="Account Name"> Account No:
          </label>
          <input type="text" name="acc_no" id="search_field" class="text"
		   value="<?php if(isset($_POST['acc_no'])) echo $_POST['acc_no']; ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
		
      </form>
	  </fieldset>


<form action="#" method="post" id="new_acc_fieldset">
<fieldset ><legend>View Last Payment Details.</legend> 

		
		  
		  <label for="label" title="Please Enter  Amount Paid" class="labels">Account Name:
          </label><br />
		  <input type="text" name="acc_name" id="label" class="text" value="<?php echo $acc_names; ?>" readonly/><br />
		  <label for="label" title="Please Enter Payment Date" class="labels">Payment Date:
          </label><br />
		  <input type="text" name="payment_date" id="label" class="text" value="<?php echo $payment_date; ?>" readonly/><br />
		  
		<label for="label" title="Please Enter Mode Of Payment" class="labels">Mode Of Payment:
          </label><br />
		  <input type="text" name="mode_of_payment" id="label" class="text" value="<?php echo $payment_mode; ?>" readonly/><br />
           
                        
                     

          <label for="label" title="Please Enter  Amount Paid" class="labels">Amount Paid
          </label><br />
		  <input type="text" name="amount_paid" id="label" class="text" value="<?php echo $amount_paid; ?>" /><br />
		  
          
		  <label for="label" title="Please Enter the Payer Name" class="labels">Entered By
          </label><br />
          <input type="text" name="payer" id="label" class="text" value="<?php  echo $who_entered;
		   ?> " readonly/><br />
		  
		 
         
</fieldset>
</form>

<?php
if(isset($_POST['payments'])) {
	
		$expected = array('acc_now', 'acc_name','invoice_id','mode_of_payment','type_of_payment','amount_paid','payer');
		$required = array('acc_now', 'acc_name','invoice_id','mode_of_payment','type_of_payment','amount_paid','payer');
		$missing = array();

			foreach ($_POST as $key => $value) {
			$temp = is_array($value) ? $value : trim($value);
			if (empty($temp) && in_array($key, $required)) {
			array_push($missing, $key);
				}
			elseif (in_array($key, $expected)) {
			${$key} = $temp;
					}
				}
				if(!empty($missing)){
					$result = "Please enter the highlighted values.";
				}
				
				if (!is_numeric($_POST['amount_paid'])||($_POST['amount_paid'] < 1)){
					$result = "The Amount Paid can only contain numerical values.";
				}

				
			}
			
			
			////inserting  the payments created 
				if(isset($_POST['payments'])&& !$result) {
				$acc_nos=$_POST['acc_nos'];
				$acc_name=$_POST['acc_name'];
				$invoice_id=$_POST['invoice_id'];
				$payment_mode=$_POST['mode_of_payment'];
                                $type_of_payment=$_POST['type_of_payment'];
				$amount_paid=$_POST['amount_paid'];
				$payer=$_POST['payer'];
                                
                                
                                /////check if  the account number and meter no are for a specified customer
                    $query="select count(*) from invoice where acc_no='$acc_nos' and invoice_no= '$invoice_id'" ;

                    $result=mysql_query($query);

                    $count=mysql_result($result,0,0);





                    if($count==0)
                    {
                       $result='That Invoice Number for that customer does not exist';

                    }
                    else {
                        $query="insert into payment
                        (invoice_no, date, amount, type_of_payment,payment_for, payers_name,
                        acc_no)
                        values
                        ( '$invoice_id',NOW(),'$amount_paid', '$mode_of_payment', '$type_of_payment','$payer', 
                        '$acc_nos')";




                        $result1=mysql_query($query)
                        or die('Please enter correct invoice number');

                        $result='Your Payment Has been created successfully ';
                        
                    }
				
				
				
				
				
				//$_POST['meter_no'];
				
			
	
				
		}		
		
  ?>
</div>



<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
    
 
</div>

<div id="working_csv">
 <?php 
 

 
 
 ///////---------
function get_file_extension($file_name) {
    return end(explode('.',$file_name));
}
 
function errors($error){
    if (!empty($error))
    {
            $i = 0;
            while ($i < count($error)){
            $showError.= '<div class="msg-error">'.$error[$i].'</div>';
            $i ++;}
            return $showError;
    }// close if empty errors
} // close function
 
 
if (isset($_POST['upfile'])){
// check feilds are not empty
 
if(get_file_extension($_FILES["uploaded"]["name"])!= 'csv')
{
$error[] = 'Only CSV files accepted!';
}
 
if (!$error){

$logged_in = "'Admin On ".date("d/m/y")."'";
 
$tot = 0;
$handle = fopen($_FILES["uploaded"]["tmp_name"], "r");
while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
    for ($c=1; $c < 2; $c++) {
	
			
           
            //only run if the first column if not equal to firstname
            if($data[0] !='timestamp'){
                mysql_query("REPLACE INTO payment(
                 text_date,msisdn,amount,acc_no,transaction_id,type_of_payment,who_entered,date_entered
                        
                )VALUES(
                    '".mysql_real_escape_string($data[0])."',
                    '".mysql_real_escape_string($data[1])."',
                    '".mysql_real_escape_string($data[2])."',
					'".mysql_real_escape_string($data[3])."',
                                            '".mysql_real_escape_string($data[4])."',
                    'mpesa',
                    $logged_in,
					now() 
                                                       
					
                )" )or die(mysql_error());
               
               
            }
 
    $tot++;}
}

$tot = $tot - 1;
fclose($handle);
$content.= "<div class='success' id='message'> CSV File Imported, $tot records added </div>";
 
}// end no error
}//close if isset upfile
 
$er = errors($error);
$content.= <<<EOF
<h3>Import CSV Data</h3>
$er
<form enctype="multipart/form-data" action="" method="post">
    File:<input name="uploaded" type="file" maxlength="20" /><input type="submit" name="upfile" value="Upload File">
</form>
EOF;
echo $content;
?>

</div>