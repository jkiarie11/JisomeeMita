<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>All Payments</title>
<link rel="stylesheet" href="./jquery-ui-1.10.4/themes/base/jquery.ui.all.css">
<script src="./jquery-ui-1.10.4/jquery-1.10.2.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.core.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.widget.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.datepicker.js"></script>
        
        <script>
	$(function() {
		$( "#datepicker" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
  $( "#datepickerto" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
	});
	</script>
</head>

<body>
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 2px 2px;width:930px;align:center;}
#disc{position:relative;border:1px solid  #CCCCFF;width:930px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}

#search_regulator{
margin-left:145px;
margin-right:100px;

height:auto;

}
#invoice_dv{
margin-left:10px;
margin-right:10px;

}
#payment_tbl{
margin-left:10px;
margin-right:10px;


height:auto;


}
#invoice_tbl{
margin-left:10px;
margin-right:10px;


height:auto;
}

.heads{
left:50px; top:100px;

}
.heads1{

}
#summary_headers{
margin-top:40px;
}
</style>
<div id="active_accounts">
    
    



<div id="disciplinary">

<!--   account name-->
<style>
.acc_nm{
left:20px; top:230px; position:absolute; font-weight:bold;

}
.cust_name{
left:150px; top:230px; position:absolute; font-weight:bold;
}
.meter_no_lbl{
left:500px; top:230px; position:absolute; font-weight:bold;}
.meter_no_db{
left:700px; top:230px; position:absolute; font-weight:bold;
}
</style>
<!--   payments-->	
<div id="payment_tbl">  
    
    <form action="#" method="post" >
        <fieldset id="search_regulator"><legend>Dates</legend> 
 <label for="label"  class="search" title="Account No"> From :
          </label>
         
    <input type="text" name="datefrom" id="datepicker" value="<?php  echo $search_value_from; ?>"   />
    
    &nbsp;&nbsp; &nbsp;&nbsp;
    <label for="label"  class="search" title="Account No"> To :
          </label>
     <input type="text" name="dateto" id="datepickerto" value="<?php  echo $search_value_to; ?>"  />
     <input type="submit"  name="search_account" id="search_btn"  value="Search"  /><br><br/>
		   
                       
 </fieldset>
                     

</form>
<fieldset id="payment_fieldset"><legend align="center">Payments</legend>

	  
<table id="disc"><tr bgcolor="#000000"><th>Date</th><th>Account No</th><th>Account Name</th><th>Payment For</th><th>Invoice No</th><th>Amount</th><th>Paid By</th><th>Date Paid</th></tr>
<?php 
include("../includes/studentsconnect1.php");



echo"<tr bgcolor='#CCCCCC'>";
 ?>
 
 <?php 
 
 if(isset($_POST['search_account'])){
	

	$search_value_from=mysql_real_escape_string($_POST['datefrom']);
        $search_value_to=mysql_real_escape_string($_POST['dateto']);
        $date_from=substr($search_value_from,6,4).'-'.substr($search_value_from,3,2).'-'.substr($search_value_from,0,2);
        $date_to=substr($search_value_to,6,4).'-'.substr($search_value_to,3,2).'-'.substr($search_value_to,0,2);
	

	
	
	

}

if (strlen($date_from) > 0) {
    $querynn="select  	payment.acc_no,payment.invoice_no, payment.date, payment.amount, payment.type_of_payment, payment_for,payment.payers_name, payment.meter_no,payment.date_entered,account_details.customer_name from payment,account_details where payment.date between '$date_from' and  '$date_to' and account_details.acc_no =payment.acc_no";
}
else {
    $querynn="select  	payment.acc_no,payment.invoice_no, payment.date, payment.amount, payment.type_of_payment, payment_for,payment.payers_name, payment.meter_no,payment.date_entered,account_details.customer_name from payment left join account_details on account_details.acc_no =payment.acc_no";
}

$grand_total=0.00;
 $resultnn=mysql_query($querynn);
 while($rownn=mysql_fetch_array($resultnn)){
    $acc_no=$rownn['acc_no'];
    $inv_id=$rownn['invoice_no'];
    $payment_for=$rownn['payment_for'];
    $date_entered=$rownn['date_entered'];
    $customer_name=$rownn['customer_name'];
    if ($inv_id==0) {
        $inv_id='NONE';
    }
    $amt=$rownn['amount'];
     $grand_total += $amt;
   $mode_of_pur=$rownn['type_of_payment'];

     if ($mode_of_pur==3){
               $mode_of_pur='MPESA';
           }
           elseif ($mode_of_pur==2){
                 $mode_of_pur='CHEQUE';
           }
           else {
               $mode_of_pur='CASH';
           }
           
           if ($payment_for==1){
               $payment_for_desc='INVOICE';
           }
           elseif ($payment_for==2){
                 $payment_for_desc='LOAN';
           }
            elseif ($payment_for==3){
                 $payment_for_desc='UNAPPLIED CASH';
           }

           $payer=$rownn['payers_name'];
    $dt_inv=$rownn['date'];

    //calculating the balance
      $balance=$amt-$amount;
     $tester=substr($balance,0);
   if($tester=="-"){
   $balance=substr($balance,1);


   }
   else{
   $balance="(".$balance.")";

   } 
 ?>
 <td><?php echo $dt_inv;?></td><td><?php echo  $acc_no;?></td><td><?php echo  $customer_name;?></td><td><?php echo  $payment_for_desc;?></td><td><?php echo $inv_id;?></td><td><?php echo $amt;?></td><td><?php echo  $payer;?></td><td><?php echo  $date_entered;?></td></tr>
 <?php
	}
        $grand_total = round( $grand_total, 2, PHP_ROUND_HALF_UP);
 
 ?>
<tr bgcolor="#CCCCCC"><td><?php echo ''; ?></td><td><?php echo '';  ?></td><td><?php echo '';  ?></td><td><?php echo '';?></td><td><?php echo 'Total';?> </td><td><?php echo $grand_total;?> </td></tr>

</table>
    

</fieldset>
    
 </div>
<!--   balance-->	


<style>
.bal_lbl{
left:400px; top:0px; position:relative; font-weight:bold;
}
.bal_thing{
left:20px; top:0px; position:relative; font-weight:bold;

}
</style> 
<div  id="summary_headers">

<?php

?>

	 <!-- <p  class="bal_lbl">Balance:<label class="bal_thing"><?php //echo  ($balance); ?></label> </p>-->
	  
	  </div>



</div>

</body>
</html>
