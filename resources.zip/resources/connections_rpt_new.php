
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:900px;}
#disc{position:relative; left:5px; top:10px; border:1px solid  #CCCCFF;width:890px; }
#disc td{text-align:left;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}
</style>
<div id="active_accounts">
<fieldset><legend>View System Modules</legend>
<div id="disciplinary">
<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>Screen Code</th><th>Screen Name</th></tr>
<?php 

 $i=0;
  
 $query="select distinct acc_no from account_details";
 $result=mysql_query($query);

 
 while($row=mysql_fetch_array($result)){
  $meter_nos= $row['acc_no'];

$querys="sselect distinct 	acc_no, customer_name, phone_no,phone_no2,phone_no3 from account_details where acc_no='$meter_nos'   limit 1";

$results=mysql_query($querys);
$i++;



while($rows=mysql_fetch_array($results)){
    
    $acc_no=$rows['acc_no'];
 $customer_name=$rows['customer_name'];
$phone_no=$rows['phone_no'];
 $phone_no2=$rows['phone_no2'];
 $phone_no3=$rows['phone_no3'];


			  
		// echo"<tr bgcolor='#CCCCCC'>";	  
			 
 ?>
<td><?php echo  $acc_no;?></td><td><?php echo $customer_name;?></td><td><?php echo $phone_no;?></td><td><?php echo  $phone_no2;?></td><td><?php echo $phone_no3;?></td></tr>

<?php 
			 }
 }
 




?>


</table>
</fieldset>

</div>
