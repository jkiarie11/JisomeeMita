<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>All Invoices</title>
<link rel="stylesheet" href="./jquery-ui-1.10.4/themes/base/jquery.ui.all.css">
<script src="./jquery-ui-1.10.4/jquery-1.10.2.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.core.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.widget.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.datepicker.js"></script>
        
        <script>
	$(function() {
		$( "#datepicker" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
  $( "#datepickerto" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
	});
	</script>
</head>

<body>
<style>
    #table_s tr.cyan{background-color:#33ccff;  border:none; }
    #table_s tr.white{background-color:#FFFFFF;  border:none;  }
    #table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
    #num{ text-align:left; font-size:12px; font-family:verdana; }
    #table_s tr #num td{font-size:10px;}
    #std1{left:160px; top:100px; position:absolute; font-weight:bold;}
    #im{left:140px; top:250px; position:absolute;}
    #disciplinary fieldset{ margin:5px 5px 5px 5px;width:830px;align:center;}
    #disc{position:relative;border:1px solid  #CCCCFF;width:830px; }
    #disc td{text-align:center;font-family:Browallia New;font-size:20px;}
    #disc th{color:white;}
    legend{color:#330099; font-weight:bold;}

#search_regulator{
margin-left:10px;
margin-right:10px;

height:auto;

}
#invoice_dv{
margin-left:10px;
margin-right:10px;

}
#payment_tbl{
margin-left:10px;
margin-right:10px;


height:auto;


}
#invoice_tbl{
margin-left:10px;
margin-right:10px;


height:auto;
}

.heads{
left:50px; top:100px;

}
.heads1{

}
#summary_headers{
margin-top:40px;
}
</style>
<div id="active_accounts">
<div id="disciplinary">

<!--   account name-->
<style>
.acc_nm{
left:0px; top:230px; position:absolute; font-weight:bold;

}
.cust_name{
left:150px; top:230px; position:absolute; font-weight:bold;
}
.meter_no_lbl{
left:500px; top:230px; position:absolute; font-weight:bold;}
.meter_no_db{
left:700px; top:230px; position:absolute; font-weight:bold;
}
</style>
<!--   payments-->	
<div id="payment_tbl">  
     <form action="#" method="post" >
        <fieldset id="search_regulator"><legend>Dates</legend> 
 <label for="label"  class="search" title="Account No"> From :
          </label>
         
    <input type="text" name="datefrom" id="datepicker" value="<?php  echo $search_value_from; ?>"   />
    
    &nbsp;&nbsp; &nbsp;&nbsp;
    <label for="label"  class="search" title="Account No"> To :
          </label>
     <input type="text" name="dateto" id="datepickerto" value="<?php  echo $search_value_to; ?>"  />
     <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
          <input type="submit"  name="export_data" id="export_btns"  value="Export"  /><br><br/>   
		   
                       
 </fieldset>
                     

</form>
<fieldset id="payment_fieldset"><legend align="center">Invoices</legend>

	  
<table id="disc"><tr bgcolor="#000000"><th>Date Of Invoice</th><th>Acount No</th><th>Account Name</th><th>Invoice No</th><th>Water</th><th>Loan</th><th>Total Bill</th><th>Paid Amount</th></tr>
<?php 
include("../includes/studentsconnect1.php");


echo"<tr bgcolor='#CCCCCC'>";
 ?>
 
 <?php
 
 
	$search_value_from=mysql_real_escape_string($_POST['datefrom']);
        $search_value_to=mysql_real_escape_string($_POST['dateto']);
        $date_from=substr($search_value_from,6,4).'-'.substr($search_value_from,3,2).'-'.substr($search_value_from,0,2);
        $date_to=substr($search_value_to,6,4).'-'.substr($search_value_to,3,2).'-'.substr($search_value_to,0,2);
	
 
if (strlen($date_from) > 0) {
    $querynn="select distinct * from account_details,invoice  where  date(invoice.periodbegin) between '$date_from' and '$date_to' and account_details.acc_no=invoice.acc_no  and invoice.monthly_invoice=1 order by  1 desc";
   
}
else {
    $querynn="select distinct * from account_details,invoice  where  account_details.acc_no=invoice.acc_no  and invoice.monthly_invoice=1 order by  1 desc";
}

 $resultnn=mysql_query($querynn);
 
 
if(isset($_POST['export_data'])){
    
    $search_value_from=mysql_real_escape_string($_POST['datefrom']);
    $search_value_to=mysql_real_escape_string($_POST['dateto']);
    $date_from=substr($search_value_from,6,4).'-'.substr($search_value_from,3,2).'-'.substr($search_value_from,0,2);
    $date_to=substr($search_value_to,6,4).'-'.substr($search_value_to,3,2).'-'.substr($search_value_to,0,2);
    
    $results = mysql_query($querynn);

    // Pick a filename and destination directory for the file
    // Remember that the folder where you want to write the file has to be writable
    $filename = "/tmp/all_invoices_export_".time().".csv";

    // Actually create the file
    // The w+ parameter will wipe out and overwrite any existing file with the same name
    $handle = fopen($filename, 'w+');

    // Write the spreadsheet column titles / labels
    fputcsv($handle, array('Date of invoice','Account no','Customer Name','invoice No','Water','Loan','Total Bill','Paid Amount'));

    

    // Finish writing the file
   // fclose($handle);
    
    //exit;
}


 if(isset($_POST['search_account'])||isset($_POST['export_data'])){


 $net_paid=0.00;
 while($rownn=mysql_fetch_array($resultnn)){
 $invoice_no=$rownn['invoice_no'];
 $payment_amount=$rownn['payment_amount'];
 $net_paid+=$payment_amount;
 $amt=$rownn['amount'];
 $invoice_amount=$rownn['invoice_amount'];
 $loan_amount=$rownn['loan_amount'];
 $total_loan+=$loan_amount;
 $total_bill=$amt+$loan_amount;
 $net_bill+=$total_bill;
 $standard_charge=$rownn['standard_charge'];
// $total_water= $invoice_amount+$standard_charge;
  $total_water= $invoice_amount;
 $net_water+=$total_water;
 $invoice_for=$rownn['invoice_for'];
 if($invoice_for==1){
     $invoice_type = 'BILL';
  }
  elseif ($invoice_for==2) {
      $invoice_type = 'STANDARD_CHARGE';  
  }
  else{
     $invoice_type = 'OTHER';  
  }
      
$acc=$rownn['acc_no'];
 $payer=$rownn['customer_name'];
 $dt_inv=$rownn['periodbegin'];
 
   if(isset($_POST['export_data'])){
           fputcsv($handle, array($dt_inv, $acc,$payer, $invoice_no, $total_water,$amount_paid,$date_entered));  
         }
 
 //calculating the balance
   $balance=$amt-$amount;
  $tester=substr($balance,0);
if($tester=="-"){
$balance=substr($balance,1);


}
else{
$balance="(".$balance.")";

}
 ?>
 <td><?php echo $dt_inv;?></td><td><?php echo  $acc;?></td><td><?php echo $payer;?></td><td><?php echo $invoice_no;?></td><td><?php echo  $total_water;?></td><td><?php echo  $amount_paid;?></td><td><?php echo  $total_bill;?></td><td><?php echo  $payment_amount;?></td></tr>
 <?php
	}
 }
 
   // Finish writing the file
    fclose($handle);
 ?>

<tr bgcolor="#CCCCCC"><td><?php echo ''; ?></td><td><?php echo '';  ?></td><td><?php echo '';  ?></td><td><?php echo 'Total';?> </td><td><?php echo $net_water;?></td><td><?php echo $total_loan;?></td><td><?php echo $net_bill;?></td><td><?php echo $net_paid;?> </td></tr>

</table>

</fieldset>
 </div>
<!--   balance-->	

<style>
.bal_lbl{
left:400px; top:0px; position:relative; font-weight:bold;
}
.bal_thing{
left:20px; top:0px; position:relative; font-weight:bold;

}
</style> 
<div  id="summary_headers">

<?php

?>

	 <!-- <p  class="bal_lbl">Balance:<label class="bal_thing"><?php //echo  ($balance); ?></label> </p>-->
	  
	  </div>



</div>


</body>
</html>
