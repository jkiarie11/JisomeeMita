<?php
function checking_billing($units){

if($units<=10){
			 $querys="select * from billing_rates where id=1";
						 $results=mysql_query($querys);
					$i++;	
						 
						 while($rows=mysql_fetch_array($results)){
						  $water_rate= $rows['water_rate'];
			$bill=water_rate_units*$units;
			}
}
elseif($units>10  ){
			$querys="select * from billing_rates where id=1";
						 $results=mysql_query($querys);
					$i++;	
						 
						 while($rows=mysql_fetch_array($results)){
						  $water_rate= $rows['water_rate'];
			$bill=water_rate_units*$units;
			}
}
else if($units<=10){
			$querys="select * from billing_rates where id=1";
						 $results=mysql_query($querys);
					$i++;	
						 
						 while($rows=mysql_fetch_array($results)){
						  $water_rate= $rows['water_rate'];
			$bill=water_rate_units*$units;
			}
}
else if($units<=10){
			$querys="select * from billing_rates where id=1";
						 $results=mysql_query($querys);
					$i++;	
						 
						 while($rows=mysql_fetch_array($results)){
						  $water_rate= $rows['water_rate'];
			$bill=water_rate_units*$units;
			}
}



}
?>