<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Process All Payments</title>
</head>


<body>
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:850px;align:center;}
#disc{position:relative; left:5px; top:2px; border:1px solid  #CCCCFF;width:890px; margin-top:10px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}
#active_accounts{
margin-left:10px;
margin-right:170px;


height:auto;
}
#alert_me{
border:1px solid #993300; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; padding:10px;
background-color:#FFFFCC; color:#FF0000;

}
#payments_btn{

border:1px solid  #66CC99; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; padding:5px;
background-color:#99CCFF; color:#FF0000;
margin-right:80px;
margin-top:150px;
margin-left:10px;
background-image:url(../images/unpaymentd.png) repeat;

}
#payments_btn:hover{

border:1px solid  #66CC99; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; padding:5px;
background-color:#6633CC; color:#FFFFFF;
margin-right:80px;
margin-left:10px;
}
#header_lbl{
position:absolute;
left:10px; top:50px;
}
#seperator{
border-top:1px solid  #66CC99; width:900px; margin-top:50px;

}
</style>
<div id="active_accounts">
<fieldset><legend align="center">Process All Payments</legend>
<?php
include("../includes/studentsconnect1.php");

?>



<div id="seperator"></div>
<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>#No</th><th>Transaction Id</th><th>Account No</th><th>Account Name</th><th>Date Of Payment</th><th>Mobile No</th><th>Amount</th></tr>
<?php 

$file_path[0] = 'test'; /* global scope */ 



function process_dir($dir,$recursive = FALSE) {
    
    global $file_path;
  
    if (is_dir($dir)) {
      for ($list = array(),$handle = opendir($dir); (FALSE !== ($file = readdir($handle)));) {
          $p++;
         
        if (($file != '.' && $file != '..') && (file_exists($path = $dir.'/'.$file))) {
            
          if (is_dir($path) && ($recursive)) {
            $list = array_merge($list, process_dir($path, TRUE));
            
          } else {
            $entry = array('filename' => $file, 'dirpath' => $dir);
            

                
                 

            $entry['modtime'] = filemtime($path);

            do if (!is_dir($path)) {
 
                $entry['size'] = filesize($path);
                if (strstr(pathinfo($path,PATHINFO_BASENAME),'csv')) {
                  
                 
                  if (!$entry['handle'] = fopen($path,r)) $entry['handle'] = "FAIL";
                  $ls_file = substr($path,strlen($path)-16,16);
                 
                  $file_path[$p]=$path;
                
                }
 
 
                break;
            } else {
 
              break;
            } while (FALSE);
            $list[] = $entry;
          }
        }
      }
      closedir($handle);
      return $list;
    } else return FALSE;
  }//end function
  

  
 
  
  $querya= "select payments_path from billing_settings";
  $resulta=mysql_query($querya);
  $repayments_path=mysql_result($resulta,0,0);
  
  
 // $result = process_dir("/home/jkiarie11/Documents/billing/import/mashinani",TRUE);
  
  $result = process_dir($repayments_path,TRUE);
  
    $logged_username = strtoupper($_SESSION['username']);
    
  
 $l=0;
 $k=0;
 $m=0;
 $transaction_code=0;
  
 
 // Output each opened file and then close
  foreach ($result as $file) {
      
     ;
     
    if (is_resource($file['handle'])) {
        
        ///////////////////////////////////////////
       
        while (($data = fgetcsv($file['handle'], 10000, ",")) !== FALSE) {
             
            for ($c=0; $c < 1; $c++) {
                
               $transaction_code++;
                $date_of_payment =  '';
                $mobile_no = '';
                $amount = 0;

                $acc_no = '';
                $tran_id = '';
                  
                   
                    //only run if the first column if not equal to firstname
                if($data[0] !='timestamp') {
                   if(strpos($data[0], 'Kate') ==false ) {
                   //if(substr(trim($data[0]),0,5)!='Kate' ){


                        $date_of_payment = substr($data[0],4,2).'/'.substr($data[0],6,2).'/'.substr($data[0],8,4).' '.substr($data[0],0,2).':'.substr($data[0],2,2);

                        $date_of_payment_save = substr($data[0],8,4).'/'.substr($data[0],6,2).'/'.substr($data[0],4,2).' '.substr($data[0],0,2).':'.substr($data[0],2,2);


                        $dateInfo = date_parse_from_format('dd/mm/Y:HH:MM', $date_of_payment);

                        $datetosave = mktime(
                            $dateInfo['hour'], $dateInfo['minute'], $dateInfo['second'],
                            $dateInfo['month'], $dateInfo['day'], $dateInfo['year'],
                            $dateInfo['is_dst']
                        );
                            
                                                   
                        
                            
                            
                            
                        //////////////////////
                        $mobile_no = $data[1];
                        $amount = $data[2];
                        
                       // echo 'amount is '.$amount."<BR>";
                        $amount_remaining=$amount;
                        

                        $acc_no = 'ES'.$data[3];
                        
                      
                        $tran_id = $data[4];
                        
                         

                      ///////////////////////////

                        $querye= "select loan_balance,interest_balance,loan_amount,interest_amount,repayment_period,customer_name from account_details where acc_no= '$acc_no'";
                        
                         $resulte=mysql_query($querye);
                        $loan_duration=mysql_result($resulte,0,4);
                        $loan_balance=mysql_result($resulte,0,0);
                        $loan_topay = $loan_amount/$loan_duration;
                        $interest_topay = $interest_amount/$loan_duration;
                        
                       
                        $loan_balance=mysql_result($resulte,0,0);
                        $interest_balance=mysql_result($resulte,0,1);
                        $customer_name=mysql_result($resulte,0,5);
                        $loan_amount=mysql_result($resulte,0,2);
                        $interest_amount=mysql_result($resulte,0,3);
                        
                        
                        
                        
                        
                        
                        $querye="select sum(amount) from payment where payment_for = 2 and acc_no= '$acc_no'";
                       
                        $resulte=mysql_query($querye);
                        $loan_payment=mysql_result($resulte,0,0);
                        
                        //echo 'loan payment is '.$loan_payment."<BR>";
                        
                        
                        
                         $repayment_amount = $loan_amount+$interest_amount;
                         
                         $repayment_amount=$repayment_amount/$loan_duration;
                         $repayment_amount=round( $repayment_amount, 2, PHP_ROUND_HALF_UP);
                       //  echo 'repayment_amount is '.$repayment_amount."<BR>";
                      //   echo 'loan payment is is '.$loan_payment."<BR>";
                         $loan_remainder=$repayment_amount-$loan_payment;
                        
                       // echo 'loan remainder1 is '.$loan_remainder."<BR>";
                      //  echo 'amount is '.$amount."<BR>";
                      //  echo 'amount remaining is '.$amount_remaining."<BR>";
                      //  echo 'loan balance is '.$loan_balance."<BR>";
                        
                        
                        if($loan_remainder>0){
                            
                            $repayment_amount= 0;
                            
                          
                            
                            if($loan_remainder > $amount) {
                                $loan_remainder = $amount;
                                $invoice_amount = 0;
                               
                            }
                            else {
                                $invoice_amount = $amount - $loan_remainder;
                            }
                            
                            // echo 'invoice amount after loan is '.$invoice_amount."<BR>";
                            
                            if($loan_remainder > $loan_balance){
                                $loan_remainder = $loan_balance;
                              
                            }
                            
                            
                          
                        }
                        else {
                            
                            $invoice_amount = $amount;
                        }
                            
                       // echo 'invoice amount is '.$invoice_amount; 
                       // echo 'amount remaining is '.$amount_remaining."<BR>";; 
                       
                       // echo 'amount remaining is '.$amount_remaining."<BR>";
                      //  echo 'loan remainder is '.$loan_remainder."<BR>";
                        
                         if($loan_remainder < 0 ) {
                            $loan_remainder=0;
                        }
                        
                        $amount_remaining= $amount_remaining - $loan_remainder;
                       
                      // echo 'amount remaining 1 is '.$amount_remaining."<BR>";
                        if ($invoice_amount > 0) {
                            
                            $querye="select invoice_no,amount-payment_amount as balance from invoice "
                            . "where acc_no='$acc_no' and amount > payment_amount"
                                    . " and monthly_invoice > 0 order by periodbegin ";
                            
                            echo $querye."<BR>";



                                //////////////////////////
                            $t=0;
                            $results=mysql_query($querye);
                            $amount_to_apply = $invoice_amount;
                            $invoice_paid[$t]= $invoice_amount;

                            while($rows=mysql_fetch_array($results)){
                               // echo 'row 1';


                                $invoice_no[$t]= $rows['invoice_no'];

                                $balance= $rows['balance'];


                                if ($amount_to_apply > $balance) {
                                    $amount_to_apply = $amount_to_apply - $balance;
                                    $invoice_paid[$t]=$balance;

                                }
                                else{
                                    $invoice_paid[$t]=$amount_to_apply;

                                }

                                //if($invoice_paid[$t] > $amount){
                                //    $invoice_paid[$t]=$amount;
                              //  }

                                $t++;
                            }
                       
                        
                        
                                    
                        
                                                    
                            //////////-------------------
                            $k=0;    
                           foreach ($invoice_no as $value) {
                                $amount_remaining = $amount_remaining - $invoice_paid[$k];
                                if($amount_remaining>=0){
                                    
                                    
                                    $ls_query[$k]="INSERT INTO payment(acc_no,invoice_no,date,amount,type_of_payment,payment_for,payers_name,transaction_id,who_entered,transaction_id_code)VALUES('ES".mysql_real_escape_string($data[3])."',$value,'".$date_of_payment_save."','$invoice_paid[$k]','3','1','$mobile_no','$tran_id','$logged_username','$transaction_code')";
                                
                                 //   echo 'ls_query is '.$ls_query[$k]."<BR>";
                                    $ls_update[$k]="UPDATE invoice set payment_amount = payment_amount + '$invoice_paid[$k]' where invoice_no = $value";
                                 // echo  $ls_update[$k];
                                 //  echo $ls_update[$k]."<BR>";
                              
                                }
                                else
                                {
                                    break;
                                }

                               $k++;
                               $transaction_code++;

                           }     
                           
                        }
                       
                      // echo 'test one';
                      
                                                
                         $k++;   
                         $l++;  
                         $m++; 
                         
                        
                         
                         if($loan_remainder>0){
                             
                             
                         
                      
                                $value=9999999;
                               
                                $ls_query_loan[$l]="INSERT INTO payment(acc_no,date,amount,type_of_payment,payment_for,payers_name,transaction_id,who_entered,transaction_id_code)VALUES('ES".mysql_real_escape_string($data[3])."','".$date_of_payment_save."','$loan_remainder','3','2','$mobile_no','$tran_id','$logged_username','$transaction_code')";
                                $ls_customer_loan[$l]="UPDATE account_details set loan_balance = loan_balance - ".$loan_remainder." where acc_no =  'ES".mysql_real_escape_string($data[3])."'";
                               // echo  $ls_customer_loan[$l];
                                
                                $transaction_code++;
                               //echo 'query loan is '.$ls_query_loan[$l]." and l is ".$l."<BR>";
                            
                         }
                         
                        ///////////--------------------
                          //echo 'Loan sql '.$k.' is'. $ls_query_loan."<BR>"; 
                         
                      //   echo 'amount remaining is '.$amount_remaining."<BR>"; 
                         
                         if($amount_remaining>0){
                              $ls_unapplied_cash[$m]="INSERT INTO payment(acc_no,date,amount,type_of_payment,payment_for,payers_name,transaction_id,who_entered,transaction_id_code)VALUES('ES".mysql_real_escape_string($data[3])."','".$date_of_payment_save."','$amount_remaining','3','3','$mobile_no','$tran_id','$logged_username','$transaction_code')";
                             $transaction_code++;
// echo  $ls_unapplied_cash[$m];
                         }
                         
                         if($amount>99){
                              $ls_update_first_payment[$m]="UPDATE account_details set first_payment = 1 where acc_no =  'ES".mysql_real_escape_string($data[3])."'";
                             
// echo  $ls_unapplied_cash[$m];
                         }
                         
                         $ls_date = date("Y/m/d");
                         $ls_time =date("h:i:sa");
                         $ls_sent = "$ls_date saa $ls_time";
                        
                          $ls_payments_received[$m]="INSERT INTO payments_received(acc_no,phone_no,date_sent)VALUES('ES".mysql_real_escape_string($data[3])."','".$mobile_no."','$ls_sent')";
                          //echo $ls_payments_received[$m];


                    }
                    
                }
                   
                    

     $tot++;}
       
 

  
    

  
  

if($amount>0) {
 ?>
 <style>
 .btn{
 margin:0px;
  
 }
 
 </style>
<tr bgcolor="#CCCCCC"><td><?php if($amount>0) echo $c;?> </td><td><?php if($amount>0) echo $tran_id; ?></td><td><?php if($amount>0) echo $acc_no; ?></td><td><?php echo $customer_name;  ?></td><td><?php echo  $date_of_payment;?></td><td><?php echo $mobile_no;?> </td><td><?php echo $amount;?> </td><td  width="100px" style="color:#FF0000; font-family:Geneva, Arial, Helvetica, sans-serif; font-weight:bold; font-size:14px;" ><?php echo $bill_amount; ?></td><?php
  
}
 }
        
        fclose($file['handle']);

        
      

        //}
            
        
    }

	
}

if(isset($_POST['raise_payments'])){
  //  echo 'now raise payments';
    
  
  
  
   
           
    
   
    
    foreach ($ls_query_loan as $value1) {
      //  echo 'a'."<BR>";
       // echo $value1."<BR>";
   
     
           $resulte=mysql_query($value1)
            or die(mysql_error());
           
    }
    
   
    foreach ($ls_customer_loan as $value2) {
      //  echo 'a'."<BR>";
       // echo $value1."<BR>";
   
     
           $resulte=mysql_query($value2)
            or die(mysql_error());
           
    }
    
    
    
     foreach ($ls_update as $value1) {
        //  echo 'b'."<BR>";
          //  echo $value1."<BR>";
     
           $resulte=mysql_query($value1)
            or die(mysql_error());
           
    }
           
           
     // $k=0;
      foreach ($ls_query as $value) {
        //   echo 'c'."<BR>";
         //   echo $value."<BR>";
   
          
      
        $resulte=mysql_query($value)
         or die(mysql_error());
      }
      
       foreach ($ls_unapplied_cash as $value) {
         //  echo 'd'."<BR>";
          //  echo $value."<BR>";
   
          
      
        $resulte=mysql_query($value)
         or die(mysql_error());
      }
      
       foreach ($ls_update_first_payment as $value) {
        
      
        $resulte=mysql_query($value)
         or die(mysql_error());
      }
      
       foreach ($ls_payments_received as $value) {
        
      
        $resulte=mysql_query($value)
         or die(mysql_error());
      }
      
      $payment_processed=1;
      
      $resultsss = 'Payments Processed successfully';
     
      
       foreach ($file_path as $value) {
                          
             
            $ls_result= rename($value, substr($value,0,strlen($value)- 4).'read');
           
                       
                           
          }     
           
           
  }

  

    

                

			//}
			//}

?>
		


</tr>


</table>

<div id="header_lbl">
<form action="#" method="post" >
<input type="submit"  name="raise_payments" id="payments_btn"  value="Process All Payments"  />
<label id="alert_me"><?php if($payment_processed==1){echo $resultsss;}else{$resultsss='Click The [Process All Payments] button to Process all the Customers Payments'; echo $resultsss;}?> </label>
</form>

</div>	
</fieldset>

</div>


</body>
</html>
