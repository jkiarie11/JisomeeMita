<style>
.labels{
position:absolute;
margin-left:200px;
margin-top:2px;
margin-bottom:2px;




}
#acc_combo{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#label{
position:relative;
margin-left:100px;
height:20px;
width:320px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-left:50px;
margin-right:350px;

}
#create_acc_btn{
margin-left:170px;
height:25px;
}
#create_acc_btn:hover{
margin-left:170px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:600px; width:270px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:250px; position:absolute;

padding:5px;
background-color:#FF6633;



}
#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}
</style>


<style>
.search{
position:absolute;
margin-left:100px;

}
#search_field{
position:absolute;
margin-left:500px;

}
#search_btn{
position:absolute;
margin-left:680px;

}
#search_regulator{
margin-left:145px;
margin-right:100px;
height:50px;

}
</style>


<div id="active_accounts">
<div id="disciplinary">

<?php  

$result="";
$results="Alerts!";

$logged_username = $_SESSION['username'];


//echo $logged_username;
//change to actual user in production
$querynn="select id,maximum_consumption,loan_amount,repayment_period,payments_path from billing_settings  ";

$resultnn=mysql_query($querynn);
while($rownn=mysql_fetch_array($resultnn)){
    $id =$rownn['maximum_consumption'];
    $maximum_consumption=$rownn['maximum_consumption'];
    $loan_amount=$rownn['loan_amount'];
    $repayment_period=$rownn['repayment_period'];
    $payments_path=$rownn['payments_path'];
    
    




    


}



?>

<div id="create_new_account">




<form action="#" method="post" id="new_acc_fieldset">
<fieldset ><legend>User Details</legend>

		<label for="label" title="Please Enter  User Name" class="labels"<td align="right"><font color="#ff0000">*</font>User Name:
          </label><br />
		  <input type="text" name="user_name" id="label" class="text" value="<?php  if(isset($_POST['user_name'])) echo $_POST['user_name']; ?>" /><br />
		  
		  <label for="label" title="Please Enter The Full Name" class="labels">Full name:
          </label><br />
		  <input type="text" name="full_name" id="label" class="text" value="<?php if(isset($_POST['full_name'])) echo $_POST['full_name']; ?>" /><br />
	
                 
    <label for="label" title="Account Designation" class="labels"<td align="right"><font color="#ff0000">*</font>User Designation
          </label><br />
          <select  name="account_designation" id="acc_combo"  >
		  <option>-</option>
		   <option>Administrator</option>
		    <option>Manager</option>
			<option>User</option>
                        <option>Query Only</option>
			</select>
			<br />
          
          <label for="label" title="Please Enter  Email Address" class="labels">Email Address
          </label><br />
		  <input type="text" name="email_address" id="label" class="text" value="<?php if(isset($_POST['email_address'])) echo $_POST['email_address'];  ?>" /><br />
          <label for="label" title="Please Enter  Password" class="labels"<td align="right"><font color="#ff0000">*</font>Password
          </label><br />
		  <input type="password" name="password" id="label" class="text" value="<?php if(isset($_POST['password'])) echo $_POST['password'];  ?>" /><br />
           <label for="label" title="Please Confirm Password" class="labels"<td align="right"><font color="#ff0000">*</font>Confirm Password
          </label><br />
		  <input type="password" name="confirm_password" id="label" class="text" value="<?php if(isset($_POST['confirm_password'])) echo $_POST['confirm_password'];  ?>" /><br />
           
		  
		  <input type="submit"  name="payments" id="create_acc_btn"  value="Save Settings"  />
         
</fieldset>
</form>

<?php



//echo 'first result is '.$result;


if(isset($_POST['payments'])) {
	
		$expected = array('user_name', 'password','account_designation');
		$required = array('user_name', 'password','account_designation');
		$missing = array();

			foreach ($_POST as $key => $value) {
			$temp = is_array($value) ? $value : trim($value);
			if (empty($temp) && in_array($key, $required)) {
			array_push($missing, $key);
				}
			elseif (in_array($key, $expected)) {
			${$key} = $temp;
					}
				}
				if(!empty($missing)){
					$result = "Please enter the mandatory values.";
				}
				


				
			


			
			
			////inserting  the payments created 
				if(isset($_POST['user_name'])&& !$result) {
                                   
				$user_name=$_POST['user_name'];
				$full_name=$_POST['full_name'];
				$password=$_POST['password'];
                                $account_designation=$_POST['account_designation'];
                                $confirm_password=$_POST['confirm_password'];
                                 $email_address=$_POST['email_address'];
                                 
                                 
				
				////////////////////////
				$query="select count(*) from user where username='$user_name'";
                                
                                
				
				//password='$pass' and
				$result=mysql_query($query);
				$count=mysql_result($result,0,0);
				/////////////////////
                                
                                if($count > 0) {
                                    $result='Username exists ';
                                }
                                elseif ($password <> $confirm_password) {
                                    $result='Password confirmation failed'; 
                                }
                                else {
                                    
                                
                                
				
				
				

				
				
				


				
				
				//$_POST['meter_no'];
				
					$query="replace into user
					(username,encrypted_pass,type, contactname,email,language,theme)
					values
					( '$user_name',SHA1('$password'), '$account_designation','$full_name','$email_address','english','default')";
					
					
					$result1=mysql_query($query)
				or die(mysql_error());
				
				$result='Your user details have been updated successfully ';


                             }
				
		}	
                
                }
		
  ?>
</div>
<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
</div>