<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>All Payments</title>
</head>

<body>
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:830px;align:center;}
#disc{position:relative;border:1px solid  #CCCCFF;width:830px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}

#search_regulator{
margin-left:145px;
margin-right:100px;

height:auto;

}
#invoice_dv{
margin-left:10px;
margin-right:10px;

}
#payment_tbl{
margin-left:10px;
margin-right:10px;


height:auto;


}
#invoice_tbl{
margin-left:10px;
margin-right:10px;


height:auto;
}

.heads{
left:50px; top:100px;

}
.heads1{

}
#summary_headers{
margin-top:40px;
}
</style>
<div id="active_accounts">
<div id="disciplinary">

<!--   account name-->
<style>
.acc_nm{
left:20px; top:230px; position:absolute; font-weight:bold;

}
.cust_name{
left:150px; top:230px; position:absolute; font-weight:bold;
}
.meter_no_lbl{
left:500px; top:230px; position:absolute; font-weight:bold;}
.meter_no_db{
left:700px; top:230px; position:absolute; font-weight:bold;
}
</style>
<!--   payments-->	
<div id="payment_tbl">  
<fieldset id="payment_fieldset"><legend align="center">Connections</legend>

	  
<table id="disc"><tr bgcolor="#000000"><th>account No</th><th>Customer Name</th><th>phone No</th><th>Altenative Phone No</th><th>Altenative Phone no 2</th>></tr>
<?php 
include("../includes/studentsconnect1.php");



echo"<tr bgcolor='#CCCCCC'>";
 ?>
 
 <?php 
$querynn="select distinct 	acc_no, customer_name, phone_no,phone_no2,phone_no3 from account_details ";
 $resultnn=mysql_query($querynn);
 while($rownn=mysql_fetch_array($resultnn)){
 $acc_no=$rownn['acc_no'];
 $customer_name=$rownn['customer_name'];
$phone_no=$rownn['phone_no'];
 $phone_no2=$rownn['phone_no2'];
 $phone_no3=$rownn['phone_no3'];
 
 
 ?>
 <td><?php echo  $acc_no;?></td><td><?php echo $customer_name;?></td><td><?php echo $phone_no;?></td><td><?php echo  $phone_no2;?></td><td><?php echo $phone_no3;?></td></tr>
 <?php
	}
 
 ?>

</table>

</fieldset>
 </div>
<!--   balance-->	

<style>
.bal_lbl{
left:400px; top:0px; position:relative; font-weight:bold;
}
.bal_thing{
left:20px; top:0px; position:relative; font-weight:bold;

}
</style> 
<div  id="summary_headers">

<?php

?>

	 <!-- <p  class="bal_lbl">Balance:<label class="bal_thing"><?php //echo  ($balance); ?></label> </p>-->
	  
	  </div>



</div>

</body>
</html>
