<style>
.labels{
position:absolute;
margin-left:200px;
margin-top:2px;
margin-bottom:2px;




}
#acc_combo{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#acc_combo1{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:20px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#label{
position:relative;
margin-left:100px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-left:50px;
margin-right:350px;

}
#create_acc_btn{
margin-left:170px;
height:25px;
}
#create_acc_btn:hover{
margin-left:170px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:600px; width:270px; height:45px; background-color:#FFCC99; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:170px; position:absolute;color:#660099;
padding:5px;




}
#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}
</style>


<style>
.search{
position:absolute;
margin-left:100px;

}
#search_field{
position:absolute;
margin-left:500px;

}
#search_btn{
position:absolute;
margin-left:680px;

}
#generate_inv{
position:relative;
margin-left:180px;
margin-top:20px;

}
#search_regulator{
margin-left:145px;
margin-right:100px;
height:50px;

}
label title{
color:#FF0000;

}
</style>
<?php  
$results="Alert Me!";

//$invoices_determ=$_POST['acc_no'];

//echo 'nnnnn '.$invoices_determ;
		   

if(isset($_POST['search_account'])){

$search_value=$_POST['acc_search'];

 
 $querynn="select * from account_details  where account_status='active' AND acc_no like '%$search_value%' ";
 $resultnn=mysql_query($querynn);
 while($rownn=mysql_fetch_array($resultnn)){
 $acc_noss=$rownn['meter_no'];

 $acc_names=$rownn['customer_name'];
 

 
 }
}

?>

<div id="create_new_account">
<?php /*******************************commented code (search)************/ ?>
<!--<fieldset id="search_regulator"><legend>Actions</legend>
  <form method="post" action="#" >

		<label for="label"  class="search" title="Account Name"> Account No:
          </label>
          <input type="text" name="acc_search" id="search_field" class="text"
		   value="<?php //if(isset($_POST['acc_search'])) echo $_POST['acc_search']; ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
		
      </form>
	  </fieldset>-->


<form action="#" method="post" id="new_acc_fieldset">
<fieldset ><legend align="center">Enter The Payment Details.</legend> 
         <fieldset ><legend>Generate Invoices</legend> 
		<label for="label" title="Please Enter Account No" class="labels">Account No:
          </label><br />
             <input type="text" name="acc_search" id="label" class="text" value="<?php ?>" /><br />
 <input type="submit"  name="get_invoices" id="generate_inv"  value="Select Invoices"  />
 </fieldset>
					
		<!--  <input type="text" name="acc_number"   id="label" class="text" value="<?php // if(isset($_POST['acc_number'])) echo $_POST['acc_number']; ?>" /><br />
		  
		  <label for="label" title="Please Enter  Account Name" class="labels">Account Name:
          </label><br />
		  <input type="text"  name="acc_name" id="label" class="text" value="
		  " /><br />-->
    <label for="label" title="Please Enter Invoice No" class="labels">Invoice No:
    </label><br />
    <select  name="invoice_no"  id="acc_combo1" >
		 
		   <?php




		   
		   if(isset($_POST['get_invoices'])){


		   
		   $invoices_determ=$_POST['acc_search'];

               echo $invoices_determ;
		  
		   
		   }

		  // $invoices_determ=$_POST['acc_no'];
		   $queryp="select * from invoice  where acc_no='$invoices_determ'";
					 $resultp=mysql_query($queryp);
					 while($rowp=mysql_fetch_array($resultp)){
					 $invoice=$rowp['invoice_no'];

					
					// $acc_names=$rownn['customer_name'];
					 
					echo'<option>'; echo $invoice; echo '</option>';
 
 }  ?>
		   			</select><br />
		
		  
		 <label for="label" title="Please Enter the Mode Of Payment" class="labels"> Mode Of Payment
          </label><br />
		  <select  name="mode_of_payment" id="acc_combo"  >
		  <option>-</option>
		   <option>credit</option>
		    <option>cash</option>
			<option>cheque</option>
			</select>
			<br />

          <label for="label" title="Please Enter  Amount Paid" class="labels">Amount Paid
          </label><br />
		  <input type="text" name="amount_paid" id="label" class="text" value="<?php if(isset($_POST['amount_paid']))echo $_POST['amount_paid']; ?>" /><br />
		  
          
		  <label for="label" title="Please Enter the Payer Name" class="labels">Payers Name
          </label><br />
          <input type="text" name="payer" id="label" class="text" value="<?php if(isset($_POST['payer'])) {echo $_POST['payer'];}
		   ?> " /><br />
		  
		  <input type="submit"  name="payments" id="create_acc_btn"  value="Save Payment(s)"  />
         
</fieldset>
</form>

<?php


if(isset($_POST['payments'])) {
	
		$expected = array('invoice_no','mode_of_payment','amount_paid','payer','acc_search');
		$required = array('invoice_no','mode_of_payment','amount_paid','payer','acc_search');
		$missing = array();

			foreach ($_POST as $key => $value) {
			$temp = is_array($value) ? $value : trim($value);
			if (empty($temp) && in_array($key, $required)) {
			array_push($missing, $key);
				}
			elseif (in_array($key, $expected)) {
			${$key} = $temp;
					}
				}
				if(!empty($missing)){
					$result = "Please enter the highlighted values.";
				}
				
				if (!is_numeric($_POST['amount_paid'])||($_POST['amount_paid'] < 1)){
					$result = "The Amount Paid can only contain numerical values.";
				}

				
			}
			
		if(isset($_POST['payments'])&&!$result) {	
			////inserting  the payments created 
				if(isset($_POST['payments'])&& !$result) {
				//$acc_name=$_POST['acc_name'];
				$invoice_id=$_POST['invoice_no'];
				$mode_of_payment=$_POST['mode_of_payment'];
				$amount_paid=$_POST['amount_paid'];
				$payer=$_POST['payer'];
                $invoices_determ=$_POST['acc_search'];

                 echo 'acc no is'.$invoices_determ;
				
				
				
				
				
				//$_POST['meter_no'];
		$query="select count(*) from account_details where acc_no='$invoices_determ'" ;
				$result=mysql_query($query);
				
				 $count=mysql_result($result,0,0);
				
				 if($count==0)
				 {
                 $result='That Customer Has no account, Create an account First';
				 
				 }
				 else{
				 
				  $queryfff="select meter_no from account_details where acc_no='$invoices_determ'";
   $resultfff=mysql_query($queryfff);
 $i=0;
 while($row=mysql_fetch_array($resultfff)){
 
  
    $meter_nos= $row['meter_no'];
 
  }
 
				 
				 		
			$query="insert into payment
	(invoice_no, date, amount, type_of_payment, payers_name, 
	meter_no,acc_no)
	values
	( '$invoice_id',NOW(),'$amount_paid', '$mode_of_payment', '$payer', 
	'$meter_nos','$invoices_determ')";
	
	
	$result1=mysql_query($query)
or die(mysql_error());

$result='Your Payment Has been created successfully ';
	
				
		}	
		}	
		}
  ?>
</div>
<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
</div>