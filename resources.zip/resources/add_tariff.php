<style>
.labels{
position:absolute;
margin-left:200px;
margin-top:2px;
margin-bottom:2px;




}
#acc_combo{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#label{
position:relative;
margin-left:100px;
height:20px;
width:320px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-left:50px;
margin-right:350px;

}
#create_acc_btn{
margin-left:170px;
height:25px;
}
#create_acc_btn:hover{
margin-left:170px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:600px; width:270px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:250px; position:absolute;

padding:5px;
background-color:#FF6633;



}
#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}
</style>


<style>
.search{
position:absolute;
margin-left:100px;

}
#search_field{
position:absolute;
margin-left:500px;

}
#search_btn{
position:absolute;
margin-left:680px;

}
#search_regulator{
margin-left:145px;
margin-right:100px;
height:50px;

}
</style>


<div id="active_accounts">
<div id="disciplinary">

<?php  
$results="Alerts!";

$logged_username = $_SESSION['username'];

$query = "select * from tariff_codes "; // Run your query
 

$result=mysql_query($query);

$options3="";

while ($row=mysql_fetch_array($result)) {
  
    
    $tariff_code=$row["tariff_code"];
    $tariff_description=$row["tariff_description"];
    
   
    
    //$contactname=$row["contactname"];
    $options3.="<OPTION VALUE=\"$tariff_description\">".$tariff_description.'</option>';
    
} 




?>

<div id="create_new_account">




<form action="#" method="post" id="new_acc_fieldset">
<fieldset ><legend>Add Tariff</legend>

<label for="label" title="Please Enter  The Account Number" class="labels"<td align="right"><font color="#ff0000">*</font>Account Number:
          </label><br />
		  <input type="text" name="acc_no" id="label" class="text" maxlength="10" value="<?php  if(isset($_POST['acc_no'])) echo $_POST['acc_no']; ?>" /><br />
		<label for="label" title="Please Select The Tariff" class="labels"<td align="right"><font color="#ff0000">*</font>Tariff:
          </label><br />
		  
		 <SELECT NAME=tariff id="acc_combo" <br>>

        <?php echo $options3;?>
        </SELECT>
        <br> 
		 
                 
              
		  
		  <input type="submit"  name="payments" id="create_acc_btn"  value="Save Settings"  />
         
</fieldset>
</form>

<?php




if(isset($_POST['payments'])) {
	$result="";
		$expected = array('acc_no', 'tariff');
		$required = array('acc_no', 'tariff');
		$missing = array();

			foreach ($_POST as $key => $value) {
			$temp = is_array($value) ? $value : trim($value);
			if (empty($temp) && in_array($key, $required)) {
			array_push($missing, $key);
				}
			elseif (in_array($key, $expected)) {
			${$key} = $temp;
					}
				}
				if(!empty($missing)){
					$result = "Please enter the mandatory values.";
				}
				


				
			}


			//echo $result;
			
			////inserting  the payments created 
				if(isset($_POST['acc_no'])&& !$result) {
                                    $acc_no=$_POST['acc_no'];
                                    $tariff=$_POST['tariff'];
                                    
                                    //please pick from table in future
                                    if($tariff=='SEWER'){
				      $tariff='TRF02'; 
				    }
				    else
				    {
				    $tariff='TRF01'; 
				    }
                                    
                                   // echo $_POST['tariff'];
                                   // echo $tariff;
				
                                
                                
                                    
                                
                                
				
				
				

				
				
				


				
				
				//$_POST['meter_no'];
				
					$query="replace into account_tariffs
					(acc_no,tariff_code)
					values
					( '$acc_no','$tariff')";
					//echo $query; 
					
					$result1=mysql_query($query)
                                        or die(mysql_error());
				
                                        $result='Tariff has been inserted successfully ';


                             
				
		}		
		
  ?>
</div>
<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
</div>