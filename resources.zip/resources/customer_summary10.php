<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:830px;align:center;}
#disc{position:relative;border:1px solid  #CCCCFF;width:830px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}

#search_regulator{
margin-left:145px;
margin-right:100px;

height:auto;

}
#invoice_dv{
margin-left:10px;
margin-right:10px;

}
#payment_tbl{
margin-left:10px;
margin-right:10px;


height:auto;


}
#invoice_tbl{
margin-left:10px;
margin-right:10px;


height:auto;
}

.heads{
left:50px; top:100px;

}
.heads1{

}
#summary_headers{
margin-top:40px;
}
</style>
<div id="active_accounts">
<div id="disciplinary">
<fieldset id="search_regulator"><legend>Actions</legend>
  <form method="post" action="#" >
		<label for="label"  class="search" title="Account Name">Account No:
          </label>
          <input type="text" name="acc_name" id="search_field" class="text"
		   value="<?php if(isset($_POST['acc_name'])) echo $_POST['acc_name']; ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  />		
      </form>
</fieldset>
<?php
if(isset($_POST['search_account'])){

$search_value=mysql_real_escape_string($_POST['acc_name']);

$querynn="select max(customer_name) customer_name ,sum(amount)  as amount,sum(payment_amount)  as payment_amount,sum(i.loan_amount)  as loan_invoice_amount,max(periodbegin) date_of_invoice ,max(current_units) current_units ,min(pr_units) pr_units ,sum(total_units) total_units ,max(i.meter_no) meter_no from invoice i,account_details a  where a.acc_no=i.acc_no and monthly_invoice = 1 and a.acc_no = '$search_value' ";

//echo $querynn;
 $resultnn=mysql_query($querynn);
 
 
 while($rownn=mysql_fetch_array($resultnn)){
    $acc_noss=$rownn['acc_no'];


    $cust_name=$rownn['customer_name'];
    $amount=$rownn['amount'];
    $invoice_paid=$rownn['payment_amount'];
    $dt_invoice=$rownn['date_of_invoice'];
    $current_units=$rownn['current_units'];
    $pr_units=$rownn['pr_units'];
    $total_units=$rownn['total_units'];
    $meter_no=$rownn['meter_no'];
    $loan_invoice_amount=$rownn['loan_invoice_amount'];
    $amount=$amount-$invoice_paid;
    if($amount<0){
        $amount=0;
    }

  //  echo '<BR><BR>invoice amount is '.$amount."<BR>";
 }
 
 
 $querynn="SELECT sum(amount) as reading_amount FROM account_reading where  month( reading_date ) = month(now()) and acc_no= '$search_value' ";

//
//echo $querynn;
 $resultnn=mysql_query($querynn);
 
 
 while($rownn=mysql_fetch_array($resultnn)){
 $acc_noss=$rownn['acc_no'];


    $reading_amount=$rownn['reading_amount'];

   // echo "Reading amount is $reading_amount<BR>";
 
 }
 
 $querynn="SELECT standard_charge FROM billing_settings";

$resultnn=mysql_query($querynn);

while($rownn=mysql_fetch_array($resultnn)){
    $standard_charge=$rownn['standard_charge']; 
 }
     
    
      
    if($standard_charge==0) {
                $standard_charge=50; 
      }
      
       if($reading_amount <= $standard_charge) {
        $reading_amount=$standard_charge;

    }
 
 $amount=$amount+$reading_amount;
 }
?>
<!--   account name-->
<style>
.acc_nm{
left:20px; top:230px; position:absolute; font-weight:bold;

}
.cust_name{
left:150px; top:230px; position:absolute; font-weight:bold;
}
.meter_no_lbl{
left:500px; top:230px; position:absolute; font-weight:bold;}
.meter_no_db{
left:700px; top:230px; position:absolute; font-weight:bold;
}
</style>
<div  id="summary_headers">
	  <p><label class="acc_nm" >Account Name:</label><label class="cust_name"><?php echo  $cust_name; ?></label><label class="meter_no_lbl">Meter No:</label><label class="meter_no_db"><?php echo $meter_no; ?></label></p>
	  
	  </div>
	  
<!--   invoices-->	  
<div id="invoice_dv">	
<fieldset id="invoice_tbl"><legend>Invoices</legend>
  
<table id="disc"><tr bgcolor="#000000"><th>Last Invoice Date</th><th>Current Reading</th><th>Initial Reading</th><th>Units</th><th>Amount</th></tr>
<?php 

echo"<tr bgcolor='#CCCCCC'>";
 ?>
<td><?php echo $dt_invoice;?></td><td><?php echo $current_units;?></td><td><?php echo  $pr_units;?></td><td><?php echo $total_units;?></td><td><?php echo $amount;?></td></tr>
</table>

</fieldset>
 </div>


<!--   payments-->	
<div id="payment_tbl">  
<fieldset id="payment_fieldset"><legend>Payments</legend>
	  
<table id="disc"><tr bgcolor="#000000"><th>Last Payment Date</th><th>Last Invoice No</th><th>Total Amount</th><th>Paid By</th></tr>
<?php 

echo"<tr bgcolor='#CCCCCC'>";
 ?>
 
 <?php 
 
 if(isset($_POST['search_account'])){
$querynn="select 	max(payment.invoice_no) invoiceid, max(payment.date) date, sum(payment.amount) amount,  max(payment.payers_name) payers_name, max(payment.meter_no) meter_no from payment,account_details where account_details.acc_no =payment.acc_no and payment_for in (1,3) and account_details.acc_no    = '$search_value' ";
//echo  $querynn;
$resultnn=mysql_query($querynn);
 while($rownn=mysql_fetch_array($resultnn)){
 $inv_id=$rownn['invoiceid'];
 $amt=$rownn['amount'];
 $payer=$rownn['payers_name'];
 $dt_inv=$rownn['date'];
 //echo 'amt is '.$amt;
 
	}
        
       
 }
 
 ?>
<td><?php echo  $dt_inv;?></td><td><?php echo $inv_id;?></td><td><?php echo $amt;?></td><td><?php echo  $payer;?></td></tr>
</table>

</fieldset>
 </div>


<!--   payments-->	
<div id="adjustments_tbl">  
<fieldset id="payment_fieldset"><legend>Adjustments</legend>
	  
<table id="disc"><tr bgcolor="#000000"><th>Last Adjustment Date</th><th>Last Adjustment No</th><th>Total Amount</th><th>Customer Name</th></tr>
<?php 

echo"<tr bgcolor='#CCCCCC'>";
 ?>
 
 <?php 
 
 if(isset($_POST['search_account'])){
$querynn="select 	max(adjustments.adjustment_no) invoiceid, max(adjustments.adjustment_date) date, sum(CASE
        WHEN adjustment_type = 'DR' THEN amount
        ELSE amount*-1 end) amount, max(account_details.customer_name) payers_name from adjustments,account_details where account_details.acc_no =adjustments.acc_no and account_details.acc_no    = '$search_value' ";

$resultnn=mysql_query($querynn);
 while($rownn=mysql_fetch_array($resultnn)){
 $adjustment_no=$rownn['invoiceid'];
 $adjustment_amt=$rownn['amount'];
 $customer_name=$rownn['payers_name'];
 $adjustment_date=$rownn['date'];
 
	}
        
    $querynn="select  last_cms_balance from account_details where   account_details.acc_no    = '$search_value'";
    $resultnn=mysql_query($querynn);
    while($rownn=mysql_fetch_array($resultnn)){
        $last_cms_balance =$rownn['last_cms_balance'];
    }
    
 }
 
 ?>
<td><?php echo  $adjustment_date;?></td><td><?php echo $adjustment_no;?></td><td><?php echo $adjustment_amt;?></td><td><?php echo  $customer_name;?></td></tr>
</table>

</fieldset>
 </div>

<div id="loan_tbl">  
<fieldset id="payment_fieldset"><legend>Loan</legend>
	  
<table id="disc"><tr bgcolor="#000000"><th>Last Invoice No</th><th>Last Invoice Date</th><th>Last Payment Date</th><th>Total Amount</th><th>Customer Name</th></tr>
<?php 

echo"<tr bgcolor='#CCCCCC'>";
 ?>
 
 <?php 
 
 if(isset($_POST['search_account'])){
$querynn="select 	max(invoice_no) as invoice_no,max(date_of_invoice) as invoice_date ,sum(loan_amount) as loan_amount from invoice where invoice_raised = 'done' and acc_no    = '$search_value' ";

$resultnn=mysql_query($querynn);
 while($rownn=mysql_fetch_array($resultnn)){
 $invoice_no=$rownn['invoice_no'];
 $invoice_date=$rownn['invoice_date'];
 $loan_amount=$rownn['loan_amount'];

 
	}
        
    $querynn="select  max(date) as date,sum(amount) as amount from payment where payment_for = 2 and acc_no  = '$search_value'";
    $resultnn=mysql_query($querynn);
    while($rownn=mysql_fetch_array($resultnn)){
        $payment_date =$rownn['date'];
        $payment_amount =$rownn['amount'];
    }
    
    
    $querynn="select 	loan_amount,loan_balance,interest_amount,repayment_period from account_details where  acc_no   = '$search_value' ";

$resultnn=mysql_query($querynn);
 while($rownn=mysql_fetch_array($resultnn)){
    $loan_amount=$rownn['loan_amount'];
    $loan_balance=$rownn['loan_balance'];
    $interest_amount=$rownn['interest_amount'];
    $repayment_period=$rownn['repayment_period'];
    
    $loan_topay = $loan_amount/$repayment_period;
    $interest_topay = $interest_amount/$repayment_period;
    $loan_amount2= $loan_topay+$interest_topay;
 
	}
     
        $current_loantopay=0; 
        $querynn="select 	sum(amount) as sum_unapplied from payment where payment_for = 3 and  acc_no   = '$search_value' ";
        $resultnn=mysql_query($querynn);
        
        ///////////////
         while($rownn=mysql_fetch_array($resultnn)){
            $sum_unapplied=$rownn['sum_unapplied']; 
         }
        
         
         //echo "sum unapplied is ".$sum_unapplied;
        /////////////
       // $current_loantopay= $loan_amount2-$sum_unapplied;
       // if($current_loantopay< 0) {
       //     $current_loantopay=0;
       // }
        
        $total_loan = $loan_amount2+$loan_invoice_amount-$payment_amount -$sum_unapplied;
        if($total_loan < 0){
            $total_loan=0;
        }
    //echo "loan to pay is $loan_topay Interest to pay is $interest_topay repayment period is $repayment_period<BR>";   
   $loan_balance_amount= $loan_balance+$total_loan;
   
   if($loan_balance_amount<0){
       $loan_balance_amount=0;
   }
   //echo "loan balance amount = loan amount $loan_balance plus loan invoice amount $loan_invoice_amount plus loan amount2 $loan_amount2 minus payment amount $payment_amount<BR>"; 
   //echo "Loan balance amount is $loan_balance_amount";
 }
 
 ?>
<td><?php echo  $invoice_no;?></td><td><?php echo $invoice_date;?></td><td><?php echo $payment_date;?></td><td><?php echo  $loan_balance_amount;?></td><td><?php echo  $customer_name;?></td></tr>
</table>

</fieldset>
 </div>
<!--   balance-->	

<style>
.bal_lbl{
left:400px; top:0px; position:relative; font-weight:bold;
}
.bal_thing{
left:20px; top:0px; position:relative; font-weight:bold;

}
</style> 
<div  id="summary_headers">

<?php

////////////////////

//--------------------




//////////////
 


$additions = $amount +$adjustment_amt+ $total_loan + $last_cms_balance;
$subtractions= $amt;
$balance_disp = $additions-$amt;

//echo "Additions $additions = amount $amount plus adjustment $adjustment_amt plus total_loan $total_loan plus last cms balance $last_cms_balance<BR>";
//echo "Additions $additions minus subtractions $subtractions = $balance_disp<BR>";
 
 //echo "total_loan is '$total_loan'<BR>";
 
 
  if($total_loan<0){
       $total_loan=0;
   }
   
   echo "balance = amount '$amount' plus adjustment amount '$adjustment_amt' minus payment '$amt'"
         . " plus loan balance amount $total_loan plus last cms balance '$last_cms_balance'<BR>";
   
$balance=$amount+$adjustment_amt-$amt+$total_loan+$last_cms_balance;
  
  
 // echo "balance is $balance";
  
  $tester=substr($balance,0);
if($tester=="-"){
$balance=substr($balance,1);


}
else{
$balance="(".$balance.")";

} ?>

	  <p  class="bal_lbl">Balance:<label class="bal_thing"><?php echo  ($balance); ?></label> </p>
	  
	  </div>



</div>
