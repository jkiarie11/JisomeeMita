
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:900px;}
#disc{position:relative; left:5px; top:10px; border:1px solid  #CCCCFF;width:890px; }
#disc td{text-align:left;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}
</style>
<div id="active_accounts">
<fieldset><legend>View System Modules</legend>
<div id="disciplinary">
<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>Screen Code</th><th>Screen Name</th></tr>
<?php 

 $i=0;
  
 $query="select distinct screen_code from system_screens";
 $result=mysql_query($query);

 
 while($row=mysql_fetch_array($result)){
  $meter_nos= $row['screen_code'];

$querys="select screen_code,screen_name from system_screens where screen_code='$meter_nos'   limit 1";

$results=mysql_query($querys);
$i++;



while($rows=mysql_fetch_array($results)){

$screen_code = $rows["screen_code"];
$screen_name= $rows['screen_name'];
			  
		// echo"<tr bgcolor='#CCCCCC'>";	  
			 
 ?>
<tr bgcolor="#CCCCCC"><td><?php echo $screen_code?> </td><td><?php echo $screen_name;?></td></tr>
<?php 
			 }
 }
 




?>


</table>
</fieldset>

</div>
