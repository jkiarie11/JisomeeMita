<style>
.search{
position:absolute;
margin-left:0px;

}
#search_field{
position:absolute;
margin-left:285px;

}
#search_btn{
position:absolute;
margin-left:485px;

}
</style>
<div id="active_accounts">
<fieldset><legend>Actions</legend>
  <form method="post" action="#" >
   &nbsp;
        &nbsp;
 
		<label for="label"  class="search" title="Account Name"> Account/Meter No/ID No or Name:
          </label>
          <input type="text" name="acc_name" id="search_field" class="text" value="<?php if(isset($_POST['acc_name'])) echo $_POST['acc_name']; ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
		
      </form>


<!---TABLE DETAILS START HERE-->
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:25px 5px 5px 5px;width:900px;align:center;}
#disc{position:relative; left:5px; top:10px; border:1px solid  #CCCCFF;width:890px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}
</style>

<div id="disciplinary">
<table id="disc"><tr bgcolor="#000000"><th>Account No</th><th>ID No.</th><th>Account Name</th><th>Meter No</th><th>Registered By</th></tr>
<?php 

if(isset($_POST['search_account'])){

$search_value=trim(mysql_real_escape_string($_POST['acc_name']));

//$query="select 	*	from 	neobill.account_details  where customer_name like '%$search_value%'  or phone_no like '%$search_value%' and account_status='active'	limit 0, 50";
 
 $query="select * from account_details  where account_status='pending' AND (customer_name like '%$search_value%' or acc_no like '%$search_value%' or meter_no like '%$search_value%' or national_id like '%$search_value%')";

}
/*else{
 $query="select * from account_details  where account_status='pending'";
}*/

 // $query="select * from account_details  where account_status='pending'";
 $result=mysql_query($query);
 $i=0;
 while($row=mysql_fetch_array($result)){
 $i++;
 $account_no=$row['acc_no'];
 $nat_id=$row['national_id'];
 $name=$row['customer_name'];
 $met=$row['meter_no'];
 $entry_user=$row['entry_user'];
	 
	/* $querya="select * from staff where id_no=$tid";
 $resulta=mysql_query($querya);
 while($rowa=mysql_fetch_array($resulta)){
 $names=$rowa['name'];
 
 
 }
 */
 echo"<tr bgcolor='#CCCCCC'>";
 ?>
<td><?php echo '<a href="std_rollovers.php?choice=edit_account&varname='.$account_no.'">'.$account_no.'</a>';?> </td><td><?php echo $nat_id;?></td><td><?php echo $name;?></td><td><?php echo $met;?></td><td><?php echo $entry_user;?></td><td><?php //echo $time;?></td></tr>
 <?php
 }


?>
</table>


</fieldset>

</div>