
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:900px;align:center;}
#disc{position:relative; left:5px; top:10px; border:1px solid  #CCCCFF;width:890px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}
</style>
<div id="active_accounts">
<fieldset><legend>Actions</legend>
    
    
<div id="disciplinary">
<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>#No</th><th>Band Start</th><th>Band End</th><th>Water Rate</th><th>Sewer Rate</th></tr>
<?php 

 $i=0;
  
 $query="select distinct id from billing_rates";
 $result=mysql_query($query);

 
 while($row=mysql_fetch_array($result)){
  $rate_id= $row['id'];

 			 $querys="select * from billing_rates where id='$rate_id'   limit 1";

			 $results=mysql_query($querys);
		$i++;


			 
			 while($rows=mysql_fetch_array($results)){

                            $band_start = $rows["band_start"];
                            $band_end = $rows["band_end"];
                            $water_rate = $rows["water_rate"];
                            $sewer_rate = $rows["sewer_rate"];
                            
			
			 

				  
							  
			  
		// echo"<tr bgcolor='#CCCCCC'>";	  
			 
 ?>
<tr bgcolor="#CCCCCC"><td><?php echo $i?> </td><td><?php echo $band_start;?></td><td><?php echo $band_end;?></td><td><?php echo $water_rate;?></td><td><?php echo $sewer_rate;?></td></tr>
<?php 
			 }
 }
 




?>


</table>
</fieldset>

</div>
