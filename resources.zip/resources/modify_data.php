<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Create Many Invoices</title>
</head>


<body>
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:850px;align:center;}
#disc{position:relative; left:5px; top:2px; border:1px solid  #CCCCFF;width:890px; margin-top:10px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}
#active_accounts{
margin-left:10px;
margin-right:170px;


height:auto;
}
#alert_me{
border:1px solid #993300; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; padding:10px;
background-color:#FFFFCC; color:#FF0000;

}
#invoices_btn{

border:1px solid  #66CC99; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; padding:5px;
background-color:#99CCFF; color:#FF0000;
margin-right:80px;
margin-left:10px;
background-image:url(../images/uninvoiced.png) repeat;

}
#invoices_btn:hover{

border:1px solid  #66CC99; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; padding:5px;
background-color:#6633CC; color:#FFFFFF;
margin-right:80px;
margin-left:10px;
}
#header_lbl{
position:absolute;
left:10px; top:50px;
}
#seperator{
border-top:1px solid  #66CC99; width:900px; margin-top:50px;

}
</style>
<div id="active_accounts">
<fieldset><legend align="center">Modify data</legend>
<?php
include("../includes/studentsconnect1.php");



/*////////a function to create an invoice
 function create_invoice($pass_meter_no){
 
 ///counter to increment
counter=1;
 ////check validity
 $sql="select count(*) from invoice where invoice_raised='no' and meter_no='$pass_meter_no' order by 1 desc ";
			 $res=mysql_query($sql);
			 $counts=mysql_result($res,0,0);
			 if($counts>0){
			 ///////take the last  invoice 
			 $sql1="select * from invoice where invoice_raised='yes' order by  1 desc limit 1";
			 $res1=mysql_query($sql1);
			 while($rows=mysql_fetch_array($res1)){
			  $inv= $rows['invoice_no'];
			  
			  ///increment the last invoice(creating  a new invoice)
			  $new_invoice=$inv+$counter;
			  $counter++;
			  }
			 
			 }
			 
			 echo  'bbbbbbbbbb  '.$new_invoice;
 
 
 
 }*/
 
  //create_invoice(9007);
?>




<?php 

    $i=0;
  

    $querys="select * from account_details ";
    $results=mysql_query($querys);
    while($rows=mysql_fetch_array($results)){
       $acc_no= $rows['acc_no'];
       $meter_no= $rows['meter_no'];

      $findme   = '-';
      $pos = strpos($meter_no, $findme);

    // Note our use of ===.  Simply == would not work as expected
    // because the position of 'a' was the 0th (first) character.
    if ($pos === false) {
      // echo 'hiphen found' ;
    }
                                   ////////////////////////////////////generating  the names of the customers
       // $query="update account_details set meter_no = '$new_string' where  acc_no = '$acc_no' ";
        
        //$result1=mysql_query($query)
        //or die(mysql_error());

        $i++;
    }
 ?>
 <style>
 .btn{
 margin:0px;
 
 }
 
 
 </style>

 <?php 
/*
if(isset($_POST['raise_invoices'])){


 $counter=1;
        ///////////////invoicing  a group of invoices\
        $queryds1="select count(*) from invoice where invoice_raised='no' order by 1 desc ";
                 $resultds1=mysql_query($queryds1);
                 $count=mysql_result($resultds1,0,0);

                for($n=0;$n<=$count;$n++){
                    echo '<td>';
                    //////////////////////////////////////////////////////////////////creating a bill for the invoice
                    $querydss="select * from invoice where invoice_raised='no' order by 1 desc ";
                    $resultdss=mysql_query($querydss);
                    while($rowdss=mysql_fetch_array($resultdss)){
                       $usage=$rowdss['total_units'];
                       $passed_meter_no=$rowdss['meter_no'];
                       $passed_account_no=$rowdss['acc_no'];
                       
                       

                          // echo  $passed_meter_no;

                           

   ////check validity
                      
                      ///////take the last  invoice 
                        $sql1="select * from invoice where invoice_raised='no' and acc_no='$passed_account_no' order by 1 desc";
                        $res1=mysql_query($sql1);
                        while($rowsss=mysql_fetch_array($res1)){
                          $inv= $rowsss['invoice_no'];
                          echo 'inv   '.$inv;
                          ///increment the last invoice(creating  a new invoice)
                          $new_invoice=++$inv;
                          $amount2 = $amount2 + $amount;
                        
                        



                            echo 'invoices  '.$new_invoice;
                            
                             $querye="update invoice
                            set invoice_raised='yes' where invoice_raised='no' and invoice_no = $inv ";
                            echo $querye;
                            $resulte=mysql_query($querye)
                            or die(mysql_error());



                        }

                



              
                        
                        $querys="insert into invoice
                        (meter_no, pr_units,current_units,total_units, acc_no,periodbegin,invoice_no,amount)
                        values
                        ('$meter_no','$previous_reading','$reading','$reading','$acc_name',NOW(),0,$amount)";
                        
                        echo $querye;
                        $resulte=mysql_query($querys)
                        or die(mysql_error());
                        $counter++;
                    }
                }

               $invoice_raised=true;
			
			
			

}

			//}
			//}*/

?>
		


</tr>


</table>



</body>
</html>
