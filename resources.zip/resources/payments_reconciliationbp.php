
<style>
.labels{
position:absolute;
margin-left:100px;
margin-top:2px;
margin-bottom:2px;




}

.required { background-color:#FF0 }

.labels2{
position:absolute;
margin-left:600px;
margin-top:2px;
margin-bottom:2px;




}

#label{
position:relative;
margin-left:10px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#label2{
position:relative;
margin-left:400px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-top:100px;
margin-left:5px;
margin-right:450px;

}



#new_acc_fieldset1{

/*margin:10px,100px,10px,100px;*/
margin-left:5px;
margin-right:450px;

}


#create_acc_btn{
margin-left:100px;
height:25px;
}


#create_acc_btn:hover{
margin-left:100px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:500px; width:400px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:170px; position:absolute;

padding:5px;
background-color:#FF6633;



}
#communication{
border:5px ; left:500px; width:400px; height:100px;  border-radius:5px; top:462px; position:absolute;

padding:5px;




}

#reading{
border:2px ; left:475px; width:440px;  top:839px; position:absolute;






}

#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}


         
       
</style>


<?php

function test_req($key, $default = '') {
    if(isset($_POST[$key]) and
       !empty($_POST[$key])) {
        return $_POST[$key];
    } else {
        return $default;
    }
}
//echo htmlentities(test_req('my_field'))

$result = "";
$content= "";
$error="";


$national_id="";
$phone_no=0;
$postal_address="";
$land_reg="";
$street="";
$gps_coord="";
$meter_route_no=0;
$email="";
$meter_nosss= "";
$loan_amount=0;
$repayment_period= 0;
$logged_in='ADMIN';//until we get the correct user from logon window









 
 


		
		
?>		 
<form action="#" method="post" id="new_acc_fieldset1">
<div id="create_new_account">
    


    <fieldset id="search_regulator"><legend>Actions</legend>


    <label for="label"  class="search" title="Quotation Number"> Quotation No:
    </label>
    <input type="text" name="search_quotation" id="search_field" class="text"
       value="<?php  ?>"  />
    <input type="submit"  name="search_account" id="search_btn"  value="Search"  />


</fieldset>

<fieldset ><legend>Edit Settings</legend>

	<label for="label" title="Please Enter  Maximum Consumption" class="labels">Maximum Consumption:
        </label><br />
        <input type="text" name="maximum_consumption" id="label" class="text" value="<?php echo htmlentities(test_req('maximum_consumption',$maximum_consumption));   ?>" /><br />
		  
        <label for="label" title="Please Enter The Loan Principal Amount" class="labels">Loan Principal Amount:
        </label><br />
        <input type="text" name="loan_amount" id="label" class="text" value="<?php echo htmlentities(test_req('loan_amount',$loan_amount));?>" /><br />
	 <input type="submit"  name="create_acc_btn" id="create_acc_btn"  value="Update data>>"  />
        
         
</fieldset>



 
    
 
    
    

    





     
     
        
      
     
      
		
    
    
      
</form>
     

<div id="validator">
<?php echo $result.'<br />'/*. $meter_nosss*/; ?>
</div>

<div id="working_csv">
<?php 
function get_file_extension($file_name) {
    return end(explode('.',$file_name));
}
 
function errors($error){
    if (!empty($error))
    {
            $i = 0;
            while ($i < count($error)){
            $showError.= '<div class="msg-error">'.$error[$i].'</div>';
            $i ++;}
            return $showError;
    }// close if empty errors
} // close function


function process_dir($dir,$recursive = FALSE) {
    
    global $file_path;
    
    echo 'file path is '.$file_path;
  
    if (is_dir($dir)) {
      for ($list = array(),$handle = opendir($dir); (FALSE !== ($file = readdir($handle)));) {
          $p++;
         
        if (($file != '.' && $file != '..') && (file_exists($path = $dir.'/'.$file))) {
            
          if (is_dir($path) && ($recursive)) {
            $list = array_merge($list, process_dir($path, TRUE));
            
          } else {
            $entry = array('filename' => $file, 'dirpath' => $dir);
            

                
                 

            $entry['modtime'] = filemtime($path);

            do if (!is_dir($path)) {
 
                $entry['size'] = filesize($path);
                if (strstr(pathinfo($path,PATHINFO_BASENAME),'csv')) {
                  
                 
                  if (!$entry['handle'] = fopen($path,r)) $entry['handle'] = "FAIL";
                  $ls_file = substr($path,strlen($path)-16,16);
                 
                  $file_path[$p]=$path;
                  echo 'file path is '.$file_path[$p].'<BR>';
                
                }
 
 
                break;
            } else {
 
              break;
            } while (FALSE);
            $list[] = $entry;
          }
        }
      }
      closedir($handle);
      return $list;
    } else return FALSE;
  }//end function
 
echo 'now starting' ;

echo 'upfile is '.$_POST['upfile'];


if (isset($_POST['put upfile for it to work'])){  //upfile for production put upfile for it to work
// check feilds are not empty
 
if(get_file_extension($_FILES["uploaded"]["name"])!= 'csv')
{
$error[] = 'Only CSV files accepted!';
}
 
if (!$error){

$logged_in = "'Admin On ".date("d/m/y")."'";
 
$tot = 0;
$handle = fopen($_FILES["uploaded"]["tmp_name"], "r");
while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
    for ($c=0; $c < 1; $c++) {
	
			
           
            //only run if the first column if not equal to firstname
            if($data[0] !='Receipt'){
               /* mysql_query("UPDATE account_details_notimported set last_cms_reading_date = '".mysql_real_escape_string($data[1])."',
                    last_cms_reading='".mysql_real_escape_string($data[2])."',
                        last_cms_balance='".mysql_real_escape_string($data[3])."' "
                        . "where acc_no = 'ES".mysql_real_escape_string($data[0])."'" )or die(mysql_error());*/
                
                 /*mysql_query("UPDATE account_details set last_cms_reading_date = '".mysql_real_escape_string($data[1])."',
                    last_cms_reading='".mysql_real_escape_string($data[2])."',
                        last_cms_balance='".mysql_real_escape_string($data[3])."' "
                        . "where acc_no = 'ES".mysql_real_escape_string($data[0])."'" )or die(mysql_error());*/
                
               /*  mysql_query("REPLACE INTO account_balances(
                acc_no,reading_date,reading,
                total_balance
                )VALUES(
                    '".mysql_real_escape_string($data[0])."',
                    '".mysql_real_escape_string($data[1])."',
                    '".mysql_real_escape_string($data[2])."',
					'".mysql_real_escape_string($data[3])."'
                                                       
					
                )" )or die(mysql_error());*/
                
                
              /*  echo "REPLACE INTO safaricom_payments(
                transaction_id,transaction_date,transaction_details,
                transaction_status, withdrawn,  paid_in,
  balance ,  balance_confirmed ,  transaction_type ,  other_party_info ,
  transaction_party_detals                 )VALUES(
                    '".mysql_real_escape_string($data[0])."',
                    '".mysql_real_escape_string($data[1])."',
                    '".mysql_real_escape_string($data[2])."',
					'".mysql_real_escape_string($data[3])."',
                                            '".mysql_real_escape_string($data[4])."',
                                                '".mysql_real_escape_string($data[5])."',
                                                    '".mysql_real_escape_string($data[6])."',
                                    '".mysql_real_escape_string($data[7])."',
                                        '".mysql_real_escape_string($data[8])."',
                         '".mysql_real_escape_string($data[9])."',
                           '".mysql_real_escape_string($data[10])."'
                                                       
					
                )";*/
                
              
                
                   mysql_query("REPLACE INTO safaricom_payments(
                transaction_id,transaction_date,transaction_details,
                transaction_status, withdrawn,  paid_in,
  balance ,  balance_confirmed ,  transaction_type ,  other_party_info ,
  transaction_party_detals                 )VALUES(
                    '".mysql_real_escape_string($data[0])."',
                    '".mysql_real_escape_string($data[1])."',
                    '".mysql_real_escape_string($data[2])."',
					'".mysql_real_escape_string($data[3])."',
                                            '".mysql_real_escape_string($data[4])."',
                                                '".mysql_real_escape_string($data[5])."',
                                                    '".mysql_real_escape_string($data[6])."',
                                    '".mysql_real_escape_string($data[7])."',
                                        '".mysql_real_escape_string($data[8])."',
                         '".mysql_real_escape_string($data[9])."',
                           '".mysql_real_escape_string($data[10])."'
                                                       
					
                )" )or die(mysql_error());
                
              /*  echo "UPDATE account_details_test set last_cms_reading = '".mysql_real_escape_string($data[1])."',
                    last_cms_reading_date='".mysql_real_escape_string($data[2])."',
                        last_cms_balance='".mysql_real_escape_string($data[3])."' "
                        . "where acc_no = 'ES".mysql_real_escape_string($data[0])."'";*/
                
              //  return;
               
            }
 
    $tot++;}
}


fclose($handle);
$content.= "<div class='success' id='message'> CSV File Imported, $tot records updated </div>";
 
}// end no error
}//close if isset upfile




 
$er = errors($error);
$content.= <<<EOF
<h3>Import CSV Data</h3>
$er
<form enctype="multipart/form-data" action="" method="post">
    File:<input name="uploaded" type="file" maxlength="20" /><input type="submit" name="upfile" value="Upload File">
</form>
EOF;
echo $content;
?>

</div>
