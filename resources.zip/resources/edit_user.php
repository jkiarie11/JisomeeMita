<style>
.labels{
position:absolute;
margin-left:200px;
margin-top:2px;
margin-bottom:2px;




}
#acc_combo{
position:absolute;
margin-left:-64px;
height:20px;
width:325px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#label{
position:relative;
margin-left:100px;
height:20px;
width:320px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-top:100px;
margin-left:5px;
margin-right:450px;

}

#new_acc_fieldset1{

/*margin:10px,100px,10px,100px;*/
margin-left:5px;
margin-right:450px;

}


#new_acc_fieldset2{

/*margin:10px,100px,10px,100px;*/

margin-left:400px;
margin-right:70px;
margin-top:-30px;

}

#new_acc_fieldset3{

/*margin:10px,100px,10px,100px;*/

margin-left:350px;
margin-right:70px;
margin-top:-30px;

}

#create_acc_btn{
margin-left:170px;
height:25px;
}
#create_acc_btn:hover{
margin-left:170px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:600px; width:270px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:250px; position:absolute;

padding:5px;
background-color:#FF6633;



}
#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}
</style>


<style>
.search{
position:absolute;
margin-left:10px;

}
#search_field{
position:absolute;
margin-left:120px;

}
#search_btn{
position:absolute;
margin-left:320px;

}
#search_regulator{
margin-left:10px;
margin-right:1px;
height:50px;

}
</style>


<div id="view_account">
  
<div id="disciplinary">

<?php  

function test_req($key, $default = '') {
    if(isset($_REQUEST[$key]) and
       !empty($_REQUEST[$key])) {
        return $_REQUEST[$key];
    } else {
        return $default;
    }
}
$results="Alerts!";

$logged_username = $_SESSION['username'];
$ls_search_value = $_GET['varname'];

if (strlen($ls_search_value) > 0){
    $search_value =$ls_search_value;
    $query="select * from user  where  username = '$search_value' ";
}


if(isset($_POST['search_account'])){
	

	$search_value=mysql_real_escape_string($_POST['acc_nos']);
	//echo 'posted'.$search_value;

	//$query="select 	*	from 	neobill.account_details  where customer_name like '%$search_value%'  or phone_no like '%$search_value%' and account_status='active'	limit 0, 50";

	$query="select * from user  where  username = '$search_value' ";
	
	

}

$results=mysql_query($query);
$i=0;
while($row=mysql_fetch_array($results)){
    
        
	$i++;
	$username=$row['username'];
	
	$contactname=$row['contactname'];

	$email=$row['email'];
	$type=$row['type'];
	$user_region=$row['region_code'];
       
       
	
}

$result = "";
$content= "";
$error="";

/* $account_no=$account_no;
$customer_name=$customer_name;
$national_id=$nat_id;
$phone_no=0;
$postal_address="";
$land_reg="";
$street="";
$gps_coord="";
$meter_route_no=0;
$email="";
$meter_nosss= ""; */

$query = "select region_code,region_name from regions where region_code = '$user_region'"
          . " union select region_code,region_name from regions where region_code <> '$user_region'"; // Run your query
 
//echo $query;
$result=mysql_query($query);

$options2="";

while ($row=mysql_fetch_array($result)) {
  
    
    $region_code=$row["region_code"];
    
    $region_name=$row["region_name"];
    $options2.="<OPTION VALUE=\"$region_code\">".$region_name.'</option>';
    
} 



$result = "";

?>

<div id="view_account">

<form action="#" method="post" id="new_acc_fieldset1">
    
  <fieldset id="search_regulator"><legend>Actions</legend>   

<label for="label"  class="search" title="Account No"> User Name
          </label>
          <input type="text" name="acc_nos" id="search_field" class="text" value="<?php  echo $ls_search_value; ?>"  />
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  /><br><br/>
                   
                   
 </fieldset>




<form action="#" method="post" id="new_acc_fieldset">
<fieldset ><legend>User Details</legend>

		<label for="label" title="Please Enter  User Name" class="labels"<td align="right"><font color="#ff0000">*</font>User Name:
          </label><br />
		  <input type="text" name="user_name" id="label" class="text" value="<?php echo htmlentities(test_req('user_name',$username));  ?>" readonly/><br />
		  
		  <label for="label" title="Please Enter The Full Name" class="labels">Full name:
          </label><br />
		  <input type="text" name="full_name" id="label" class="text" value="<?php echo htmlentities(test_req('full_name',$contactname));  ?>" /><br />
	
                 
    <label for="label" title="Account Designation" class="labels"<td align="right"><font color="#ff0000">*</font>User Designation
          </label><br />
          <select  name="account_designation" id="acc_combo" value="<?php echo htmlentities(test_req('account_designation',$type));  ?>" >
		  <option>-</option>
		   <option>Administrator</option>
		    <option>Manager</option>
			<option>User</option>
                        <option>Query Only</option>
			</select>
			<br />
			
			
	<label for="label" title="region" class="labels"<td align="right"><font color="#ff0000">*</font>Region
          </label><br />
         <SELECT NAME=region value="<?php echo $region; ?>"id="acc_combo" <br>>

        <?php echo $options2;?>
        </SELECT>
        <br>
    
          
          <label for="label" title="Please Enter  Email Address" class="labels">Email Address
          </label><br />
		  <input type="text" name="email_address" id="label" class="text" value="<?php echo htmlentities(test_req('email_address',$email));  ?>" /><br />
          <label for="label" title="Please Enter  Password" class="labels"<td align="right"><font color="#ff0000">*</font>Password
          </label><br />
		  <input type="password" name="password" id="label" class="text" value="<?php if(isset($_POST['password'])) echo $_POST['password'];  ?>" /><br />
           <label for="label" title="Please Confirm Password" class="labels"<td align="right"><font color="#ff0000">*</font>Confirm Password
          </label><br />
		  <input type="password" name="confirm_password" id="label" class="text" value="<?php if(isset($_POST['confirm_password'])) echo $_POST['confirm_password'];  ?>" /><br />
           
		  
		  <input type="submit"  name="payments" id="create_acc_btn"  value="Save Settings"  />
         
</fieldset>
</form>

<?php


//echo $result;

if(isset($_POST['payments'])) {
	
		$expected = array('user_name', 'account_designation','region');
		$required = array('user_name', 'account_designation','region');
		$missing = array();

			foreach ($_POST as $key => $value) {
			$temp = is_array($value) ? $value : trim($value);
			if (empty($temp) && in_array($key, $required)) {
			array_push($missing, $key);
				}
			elseif (in_array($key, $expected)) {
			${$key} = $temp;
					}
				}
				if(!empty($missing)){
					$result = "Please enter the mandatory values.";
				}
				


				
			


			
			
			////inserting  the payments created 
				if(isset($_POST['user_name'])&& !$result) {
				$user_name=$_POST['user_name'];
				$full_name=$_POST['full_name'];
				$password=$_POST['password'];
                                $account_designation=$_POST['account_designation'];
                                $confirm_password=$_POST['confirm_password'];
                                $email_address=$_POST['email_address'];
                                $region=$_POST['region'];
                                echo $region;
                                
                                 if ($password <> $confirm_password) {
                                    $result='Password confirmation failed'; 
                                }
                                else {
                                    
                                
                                
				
				
				

				
				
				


				
				
				//$_POST['meter_no'];
                                   
                                    if(strlen($password) < 3) {
                                        $query="update user
					set type = '$account_designation', contactname = '$full_name' ,email = '$email_address',language = 'english',
					theme = 'default',who_changed ='$logged_username',date_changed = now(),region_code = '$region' where username= '$user_name'
					"; 
                                      }
                                   else {
                                        
					$query="replace into user
					(username,encrypted_pass,type, contactname,email,language,theme,who_changed,date_changed,region_code)
					values
					( '$user_name',SHA1('$password'), '$account_designation','$full_name','$email_address','english','default','$logged_username',now(),'$region')";
					
                                        }
                                        
                                    //  echo $query;
					
					$result1=mysql_query($query)
				or die(mysql_error());
				
				$result='Your user details have been updated successfully ';


                             }
				
		}
                
}
                
		
  ?>
</div>
<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
</div>