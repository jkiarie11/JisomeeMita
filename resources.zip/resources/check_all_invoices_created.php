<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Create Many Invoices</title>
</head>


<body>
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:850px;align:center;}
#disc{position:relative; left:5px; top:2px; border:1px solid  #CCCCFF;width:890px; margin-top:10px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}
#active_accounts{
margin-left:250px;
margin-right:170px;


height:auto;
}
#alert_me{
border:1px solid #993300; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; padding:10px;
background-color:#FFFFCC; color:#FF0000;

}
#invoices_btn{

border:1px solid  #66CC99; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; padding:5px;
background-color:#99CCFF; color:#FF0000;
margin-right:80px;
margin-left:200px;
background-image:url(../images/uninvoiced.png) repeat;

}
#invoices_btn:hover{

border:1px solid  #66CC99; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; padding:5px;
background-color:#6633CC; color:#FFFFFF;
margin-right:80px;
margin-left:200px;
}
#header_lbl{
position:absolute;
left:170px; top:36px;
}
#seperator{
border-top:1px solid  #66CC99; width:900px; margin-top:50px;

}
</style>
<div id="active_accounts">
<fieldset><legend align="center">Check Created Invoices</legend>
<?php
include("../includes/studentsconnect1.php");

function checking_billing($units){
     
			if($units<=10){
				$bill=$units*18.71;
			}
			else if($units>10 && $units<=30){
					$bill=(10*18.71)+(($units-10)*28.07);	
			}
			else if($units>30 && $units<=60){
						$bill=(10*18.71)+(20*28.07)+(($units-30)*42.89);				
			}
			else if($units>60){
						$bill=(10*18.71)+(20*28.07)+(30*42.89)+(($units-60)*53.80);
			}


return $bill;
}

global  $invoice_raised;
$invoice_raised=false;
 
?>



<div id="seperator"></div>
<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>#No</th><th>ACC NAME:</th><th>METER NO:</th><th>INVOICE</th><th>PREVIOUS READING</th><th>CURRENT READING</th><th>[Consumption]</th><th>BILL </th><th>[Check If Billed]</th><th>Date Invoiced</th></tr>
<?php 

 $i=0;

 			 $querys="select * from invoice where invoice_raised='yes' order by  1 desc";
			 $results=mysql_query($querys);
			 while($rows=mysql_fetch_array($results)){
			  $meter_no= $rows['meter_no'];
			  $total_units= $rows['total_units'];
			   
			$acc_no= $rows['acc_no'];
			$big=$rows['current_reading'];
				 $cur_rd=$rows['current_units']." Units ";
				 $dt_inv= $rows['date_of_invoice'];	
				 $prev_reading= $rows['pr_units']; 
				 $invoice_nos= $rows['invoice_no'];
				 //////////////////////creating the names of the customers
				 $querysc="select distinct  account_details.customer_name from account_details,invoice where account_details.acc_no=invoice.acc_no and invoice.acc_no='$acc_no'";
			 $resultsc=mysql_query($querysc);
			 while($rowsc=mysql_fetch_array($resultsc)){
			  $cust_name= $rowsc['customer_name'];

			  }
				
				/////creating the previous reading
				
				$unit_total=$big-$small;
	
 				$i++; 
 ?>
 <style>
 .btn{
 margin:0px;
 
 }
 
 </style>
<tr bgcolor="#CCCCCC"><td><?php echo $i;?> </td><td><?php echo $cust_name; ?></td><td><?php echo $meter_no;  ?></td><td><?php echo $invoice_nos;  ?></td><td><?php echo  $prev_reading;?></td><td><?php echo $cur_rd;?> </td><td><?php echo $total_units." Units";?> </td><td  width="100px" style="color:#FF0000; font-family:Geneva, Arial, Helvetica, sans-serif; font-weight:bold; font-size:14px;" ><?php echo checking_billing($total_units); ?></td>
                          

	<?php
	$invoice_raised=true;

			
			
			if($invoice_raised==true){
$resultsss='Your Invoice Has been created successfully ';
}
   if($invoice_raised==true){echo '<td>'; echo '<img src="../images/invoiced.png"  height="20" width="20" />'; echo '</td>';}

		 

 ?>
 <td><?php echo $dt_inv;  ?></td>
 
 <?php
}

?>
		


</tr>


</table>

<div id="header_lbl">
<form action="#" method="post" >
<input type="submit"  name="raise_invoices" id="invoices_btn"  value="Create All Invoices"  />
<label id="alert_me"><?php if($invoice_raised==true){echo $resultsss;}else{$resultsss='Click The [Create All Invoices] button to Create all the Customers Invoices'; echo $resultsss;}?> </label>
</form>

</div>
</fieldset>

</div>


</body>
</html>
