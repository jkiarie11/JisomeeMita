<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>All Payments</title>
<link rel="stylesheet" href="./jquery-ui-1.10.4/themes/base/jquery.ui.all.css">
<script src="./jquery-ui-1.10.4/jquery-1.10.2.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.core.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.widget.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.datepicker.js"></script>
        
        <script>
	$(function() {
		$( "#datepicker" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
  $( "#datepickerto" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
	});
	</script>
</head>
<style>
#table_s tr.cyan{background-color:#33ccff;  border:none; }
#table_s tr.white{background-color:#FFFFFF;  border:none;  }
#table_s tr:hover{background-color:#000000; color:#FFFFFF;  border:none;}
#num{ text-align:left; font-size:12px; font-family:verdana; } 
#table_s tr #num td{font-size:10px;}
#std1{left:160px; top:100px; position:absolute; font-weight:bold;}
#im{left:140px; top:250px; position:absolute;}
#disciplinary fieldset{ margin:5px 5px 5px 5px;width:900px;align:center;}
#disc{position:relative; left:5px; top:2px; border:1px solid  #CCCCFF;width:890px; }
#disc td{text-align:center;font-family:Browallia New;font-size:20px;}
#disc th{color:white;}
legend{color:#330099; font-weight:bold;}


</style>
<div id="active_accounts">
<fieldset><legend>All Payments Report</legend>
 <form method="post" action="#" >
  
  
		<label for="label"  class="search" title="Account Name"> From :
          </label>
           <input type="text" name="datefrom" id="datepicker" value="<?php  echo $search_value_from; ?>"   />
    
    &nbsp;&nbsp; &nbsp;&nbsp;
    <label for="label"  class="search" title="Account No"> To :
          </label>
     <input type="text" name="dateto" id="datepickerto" value="<?php  echo $search_value_to; ?>"  />
     <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
      <input type="submit"  name="export_data" id="export_btns"  value="Export"  /><br><br/>   
		
      </form>

<div id="disciplinary">

<table id="disc"><tr bgcolor="#000000" style="color:#FFFFFF;"><th>#No</th><th>Acc Name</th><th>Account No</th><th>Payment Date</th><th>Payment Mode</th><th>Payment For</th><th>Amount Paid</th><th>Imported By </th><th>Date Imported </th></tr>
<?php 


    
     $search_value_from=mysql_real_escape_string($_POST['datefrom']);
        $search_value_to=mysql_real_escape_string($_POST['dateto']);
        $date_from=substr($search_value_from,6,4).'-'.substr($search_value_from,3,2).'-'.substr($search_value_from,0,2);
        $date_to=substr($search_value_to,6,4).'-'.substr($search_value_to,3,2).'-'.substr($search_value_to,0,2);

    $i=0;
    
   if (strlen($date_from) > 0) {
    $queryss="select  	payment.acc_no,payment.invoice_no, payment.date, payment.amount, payment.type_of_payment, payment_for,payment.payers_name, payment.meter_no,payment.date_entered,account_details.customer_name from payment left join account_details on account_details.acc_no =payment.acc_no where date(payment.date) between '$date_from' and  '$date_to'  ";
}
else {
    $queryss="select  	payment.acc_no,payment.invoice_no, payment.date, payment.amount, payment.type_of_payment, payment_for,payment.payers_name, payment.meter_no,payment.date_entered,account_details.customer_name from payment left join account_details on account_details.acc_no =payment.acc_no";
}
 
 $resultss = mysql_query($queryss);
 
 if(isset($_POST['export_data'])){
    
   
    
   

    // Pick a filename and destination directory for the file
    // Remember that the folder where you want to write the file has to be writable
    $filename = "/tmp/all_payments_export_".time().".csv";

    // Actually create the file
    // The w+ parameter will wipe out and overwrite any existing file with the same name
    $handle = fopen($filename, 'w+');

    // Write the spreadsheet column titles / labels
    fputcsv($handle, array('Account no','Customer Name','Payment Date','Payment Mode','Payment For','Amount Paid','Date Imported'));

    

    // Finish writing the file
  //  fclose($handle);
    
    //exit;
}   

if(isset($_POST['search_account'])||isset($_POST['export_data'])){
    
   //echo $queryss;
			

    while($rows=mysql_fetch_array($resultss)){
        $acc_no=$rows['acc_no'];
        $cust_name=$rows['customer_name'];
        $payment_date=$rows['date'];
        $payment_mode=$rows['type_of_payment'];
        $payment_for=$rows['payment_for'];
        if ($payment_mode==3){
            $payment_mode='MPESA';
        }
        elseif ($payment_mode==2){
              $payment_mode='CHEQUE';
        }
        else {
            $payment_mode='CASH';
        }
        
         if ($payment_for==1){
               $payment_for_desc='INVOICE';
           }
           elseif ($payment_for==2){
                 $payment_for_desc='LOAN';
           }
            elseif ($payment_for==3){
                 $payment_for_desc='UNAPPLIED CASH';
           }
        
        $amount_paid=$rows['amount'];
        $who_entered=$rows['who_entered'];
        $date_entered=$rows['date_entered'];
        $total_amount+=$amount_paid;
         if(isset($_POST['export_data'])){
           fputcsv($handle, array($acc_no, $cust_name,$payment_date, $payment_mode, $payment_for,$amount_paid,$date_entered));  
         }

        $i++;  
                                
                        
                                
                                 
                                
                                         

 ?>
 <style>
 .btn{
 margin:0px;
 

 
 </style>
<tr bgcolor="#CCCCCC"><td><?php echo $i;?> </td><td><?php echo $cust_name; ?></td><td><?php echo $acc_no;  ?></td><td><?php echo $payment_date;  ?></td><td><?php echo  $payment_mode;?></td><td><?php echo  $payment_for_desc;?></td><td><?php echo $amount_paid;?> </td><td><?php echo $who_entered;?> </td><td><?php echo $date_entered;?> </td><td><?php echo "";?> </td><?php
                          

			 
 }
 
    $total_amount = number_format($total_amount);
			
}

 // Finish writing the file
    fclose($handle);

?>
<tr bgcolor="#CCCCCC"><td><?php echo ''; ?></td><td><?php echo '';  ?></td><td><?php echo '';  ?></td><td><?php echo '';?> </td><td><?php echo '';?></td><td><?php echo 'Total';?></td><td><?php echo $total_amount;?></td><td><?php echo $net_paid;?> </td></tr>


</table>
</fieldset>

</div>
