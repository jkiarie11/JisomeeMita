<style>
.labels{
position:absolute;
margin-left:200px;
margin-top:2px;
margin-bottom:2px;




}
 
#label{
position:relative;
margin-left:100px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}
#quotation_status{
position:absolute;
margin-left:5x;
height:20px;
width:500px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}




#new_acc_fieldset{
margin:10px,100px,10px,100px;
margin-left:20px;
margin-right:350px;

}



#create_acc_btn{
margin-left:170px;
height:25px;
}
#create_acc_btn:hover{
margin-left:170px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}

#acc_combo{
position:absolute;
margin-left:-50px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;


}
#validator{
border:5px ridge  #FFFFFF; left:600px; width:270px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:250px; position:absolute;

padding:5px;
background-color:#FF6633;



}

</style>


<style>
.search{
position:absolute;
margin-left:0px;

}
#search_field{
position:absolute;
margin-left:200px;

}

#search_field{
position:absolute;
margin-left:125px;
width:100;

}

.search2{
position:absolute;
margin-left:380px;

}
#search_field2{
position:absolute;
margin-left:570px;
width:100;

}
#search_btn{
position:absolute;
margin-left:300px;

}

#generate_btn{
position:absolute;
margin-left:750px;

}
#search_regulator{
margin-left:20px;
margin-right:40px;
height:50px;

}
</style>

<?php  


 if(empty($_SESSION['username']))
     
{  
    exit();
    
}

$results="Alerts!";
 $readonly = true;
 
 

if(isset($_POST['search_account'])) {
    $logged_username = $_SESSION['username'];
    $search_value = mysql_real_escape_string($_POST['search_quotation']);
    
    
    
    


    IF (!empty($search_value)){




        $querrn="select * from quotations where quotation_no = '$search_value' and acc_no = '' ";
   
        $j=0;
        $resultnn=mysql_query($querrn);
        while($rownn=mysql_fetch_array($resultnn)){
            
            $quotation_no=$rownn['quotation_no'];
            $quotation_status=$rownn['quotation_status'];
            $quotation_status_array[j]=$rownn['quotation_status'];
           
            $quotation_status ++;
           
            $customer_name=$rownn['customer_name'];
            $payer=$rownn['who_entered'];
            $acc_names=$rownn['customer_name'];
            $region=$rownn['region'];

            
            $j++;


        }
        $j = $j-1;
        $queryw = "select workflow_description from account_workflow where workflow_code = '$quotation_status_array[j]' ";
        $result=mysql_query($queryw);





        while ($row=mysql_fetch_array($result)) {
  
    
    
    
            $prev_status=$row["workflow_description"];
    
    
        } 
        
        
    }
}

if(isset($_POST['generate_quotation'])) {
    
    if(!empty($_POST["search_name"])){


        $quotation_status = 1;
        $search_name=$_POST['search_name'];

         $logged_username = $_SESSION['username'];
         
         


        $querynn="select max(quotation_no) as max_no from quotations ";
        
        
        $resultnn=mysql_query($querynn);
        while($rownn=mysql_fetch_array($resultnn)){
            $quotation_no=$rownn['max_no'];
            
           
            
            $quotation_no ++;

            $customer_name = $search_name;


        }
    }
}

//$quotation_status_next = $quotation_no;

 $query = "select workflow_code,workflow_description from account_workflow where workflow_code = '$quotation_status' "; // Run your query
 

$result=mysql_query($query);



$options="";

while ($row=mysql_fetch_array($result)) {
  
    
    $workflow_code=$row["workflow_code"];
    
    $workflow_description=$row["workflow_description"];
    $options.="<OPTION VALUE=\"$workflow_code\">".$workflow_description.'</option>';
    
} 

$query = "select region_code,region_name from regions "; // Run your query
 

$result=mysql_query($query);

$options2="";

while ($row=mysql_fetch_array($result)) {
  
    
    $region_code=$row["region_code"];
    
    $region_name=$row["region_name"];
    $options2.="<OPTION VALUE=\"$region_code\">".$region_name.'</option>';
    
} 

$result = ""



?>

<div id="create_new_account">

<fieldset id="search_regulator"><legend>Actions</legend>
  <form method="post" action="#" >

		<label for="label"  class="search" title="Quotation Number"> Quotation No:
          </label>
          <input type="text" name="search_quotation" id="search_field" class="text"
		   value="<?php  ?>"  />
        
                
		   <input type="submit"  name="search_account" id="search_btn"  value="Search"  />
		
      </form>
	  </fieldset>


<form action="#" method="post" id="new_acc_fieldset">
<fieldset ><legend>Update Contracting Details.</legend> 

    <label for="label" title="Please Enter  Account No" class="labels">Quotation No:
      </label><br />
      <input type="text" name="quotation_no" id="label" class="text" value="<?php echo $quotation_no; ?>" readonly/><br />

       <label for="label" title="Please Enter Customer Name" class="labels">Customer Name:
      </label><br />
      <input type="text" name="customer_name" id="label" class="text" value="<?php echo $customer_name; ?>" readonly/><br />


       <label for="label" title="Please Enter Previous Status" class="labels">Previous Quotation Status
      </label><br />
      <input type="text" name="previous_status" id="label" class="text" value="<?php echo $prev_status; ?>" readonly/><br />


      <label for="label" title="Please Enter Status" class="labels">New Quotation Status
      </label><br />

        <SELECT NAME=quotation_status id="acc_combo" <br>>

        <?php echo $options;?>
        </SELECT>
        <br>
		 
   
                        





                  
                   <br><label for="label" title="Please Enter Region" class="labels">Region
          </label><br />
		   <SELECT NAME=region id="acc_combo" <br>>

        <?php echo $options2;?>
        </SELECT>
        <br>
		  
          
		  <label for="label" title="Please Enter the Meter Reader" class="labels">Entered By
          </label><br />
          <input type="text" name="payer" id="label" class="text" value="<?php echo $logged_username;
		   ?> " /><br />
		  
		  <input type="submit"  name="payments" id="create_acc_btn"  value="Save Quotation Status"  />
         
</fieldset>
</form>

<?php


if(isset($_POST['payments'])) {
	
    $expected = array('quotation_no','region','quotation_status','customer_name','payer');
    $required = array('quotation_no','region','quotation_status','customer_name','payer');
    $missing = array();

    foreach ($_POST as $key => $value) {
        $temp = is_array($value) ? $value : trim($value);
        if (empty($temp) && in_array($key, $required)) {
            array_push($missing, $key);
         }
        elseif (in_array($key, $expected)) {
            ${$key} = $temp;

            }
        }
        if(!empty($missing)){
                $result = "Please enter the highlighted values.";
        }

       


 }


////inserting  the payments created 
if(isset($_POST['payments'])&& !$result) {
    //$acc_nos=$_POST['acc_nos'];
    $quotation_no=$_POST['quotation_no'];
    $customer_name=$_POST['customer_name'];
    $quotation_status=$_POST['quotation_status'];
    $reading=$_POST['reading'];
    $payer=$_POST['payer'];
    $quot_no=$_POST['test1'];
   





// return $amount;
     $querynn="select max(quotation_id) as max_id from quotations where quotation_no = '$quotation_no' ";
    $resultnn=mysql_query($querynn);
    while($rownn=mysql_fetch_array($resultnn)){
        $quotation_id=$rownn['max_id'];
        
       



    }
    
    $querynn="select quotation_status  from quotations where quotation_no = '$quotation_no' and quotation_id = '$quotation_id' "; 
   
    $resultnn=mysql_query($querynn);
    while($rownum=mysql_fetch_array($resultnn)){
      
     
        $quotation_status_last=$rownum['quotation_status'];
       
        
       
             



    }
  
    

if ($quotation_status ==     $quotation_status_last) {
    $result='Your Status cannot be the same as the previous one ';
   
}
else {
    
    $querynn="select max(workflow_code) as max_workflow from account_workflow "; 
   
    $resultnn=mysql_query($querynn);
    while($rownum=mysql_fetch_array($resultnn)){
      
     
        $max_workflow=$rownum['max_workflow'];
            

    }

    
   $quotation_id ++;
   
    $last_status = 0;
   
   if($max_workflow == $quotation_status) {
     //-----------------------------------------------
        $querynn="select max(substr(acc_no,3,length(acc_no) - 2)) as max_acc from account_details"; 

        $resultnn=mysql_query($querynn);
        while($rownum=mysql_fetch_array($resultnn)){


         $max_acc=$rownum['max_acc'];
         
         


        }
        
        $max_acc ++;
        
        $acc_no = $region.$max_acc;
      
        $last_status = 1;

    //------------------------------------------------
    }
    
    
   
   $query="replace into quotations
    (quotation_no, customer_name, quotation_status, region,who_entered,acc_no,quotation_id,status_date)
    values
   ('$quotation_no','$customer_name','$quotation_status', '$region','$payer','$acc_no','$quotation_id',now())";
   
   


    $result=mysql_query($query)
    or die(mysql_error());


    if ($last_status == 1){
        $result='Your Status has been updated successfully. Account Number  '.$acc_no.' has been created';
    }
    else {
        $result='Your Status has been updated successfully ';
    }
    
}




}






    
                 
				
			
		
  ?>
    
</div>
<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
</div>

