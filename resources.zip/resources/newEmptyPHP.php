<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

 <fieldset ><legend>Communication Details</legend>    
      
     
      
		  <label for="label" title="Please Enter the Phone No" class="labels">Phone No:
          </label><br />
          <input type="text" name="phone_no" id="label" class="text" value="<?php if(isset($_POST['phone_no'])) echo $_POST['phone_no']; ?> " /><br />
           <label for="label" title="Please Enter the Phone No2" class="labels">Altenative Phone No:
          </label><br />
          <input type="text" name="phone_no" id="label" class="text" value="<?php if(isset($_POST['phone_no2'])) echo $_POST['phone_no2']; ?> " /><br />

           <label for="label" title="Please Enter the Phone No" class="labels">Alternative Phone No2:
          </label><br />
          <input type="text" name="phone_no" id="label" class="text" value="<?php if(isset($_POST['phone_no3'])) echo $_POST['phone_no3']; ?> " /><br />

		  <label for="label" title="Please Enter the Postal Address" class="labels">Postal Address:
          </label><br />
<input type="text" name="postal_address" id="label" class="text"  value="<?php if(isset($_POST['postal_address'])) echo $_POST['postal_address']; ?>" /><br />
		  <label for="label" title="Please Enter the email Address" class="labels">Email Address
          </label><br />
          <input type="text" name="email" id="label" class="text"  value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>" /><br />
      
     
      
      
    
                  </fieldset>  

