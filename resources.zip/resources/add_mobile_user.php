<style>
.labels{
position:absolute;
margin-left:200px;
margin-top:2px;
margin-bottom:2px;




}
#acc_combo{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#label{
position:relative;
margin-left:100px;
height:20px;
width:320px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-left:50px;
margin-right:350px;

}
#create_acc_btn{
margin-left:170px;
height:25px;
}
#create_acc_btn:hover{
margin-left:170px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:600px; width:270px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:250px; position:absolute;

padding:5px;
background-color:#FF6633;



}
#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}
</style>


<style>
.search{
position:absolute;
margin-left:100px;

}
#search_field{
position:absolute;
margin-left:500px;

}
#search_btn{
position:absolute;
margin-left:680px;

}
#search_regulator{
margin-left:145px;
margin-right:100px;
height:50px;

}
</style>


<div id="active_accounts">
<div id="disciplinary">

<?php  
$result="";
$results="Alerts!";

$logged_username = $_SESSION['username'];





?>

<div id="create_new_account">




<form action="#" method="post" id="new_acc_fieldset">
<fieldset ><legend>Mobile User</legend>

		<label for="label" title="Please Enter the User Name" class="labels"<td align="right"><font color="#ff0000">*</font>User Name:
          </label><br />
		  <input type="text" name="user_name" id="label" class="text" maxlength="20" value="<?php  if(isset($_POST['user_name'])) echo $_POST['user_name']; ?>" /><br />
		  
		  <label for="label" title="Please Enter The Phone No" class="labels">Phone No:
          </label><br />
		  <input type="text" name="phone_no" id="label" class="text" value="<?php if(isset($_POST['phone_no'])) echo $_POST['phone_no']; ?>" /><br />
		  
		  <label for="label" title="Please Enter The Second Phone No" class="labels">Phone No 2:
          </label><br />
		  <input type="text" name="phone_no2" id="label" class="text" value="<?php if(isset($_POST['phone_no2'])) echo $_POST['phone_no2']; ?>" /><br />
		  
		  <label for="label" title="Please Enter The Third Phone No" class="labels">Phone No3:
          </label><br />
		  <input type="text" name="phone_no3" id="label" class="text" value="<?php if(isset($_POST['phone_no3'])) echo $_POST['phone_no3']; ?>" /><br />
		  
		  
		  
		  
		  
	
                 
              
		  
		  <input type="submit"  name="payments" id="create_acc_btn"  value="Save Settings"  />
         
</fieldset>
</form>

<?php

/////$result="";


if(isset($_POST['payments'])) {
	
		$expected = array('user_name', 'phone_no');
		$required = array('user_name', 'phone_no');
		$missing = array();

			foreach ($_POST as $key => $value) {
			$temp = is_array($value) ? $value : trim($value);
			if (empty($temp) && in_array($key, $required)) {
			array_push($missing, $key);
				}
			elseif (in_array($key, $expected)) {
			${$key} = $temp;
					}
				}
				if(!empty($missing)){
					$result = "Please enter the mandatory values.";
				}
				


				
			}


			//echo $_POST['user_name'];
			//echo 'result is '.$result;
			
			
			////inserting  the payments created 
				if(isset($_POST['user_name'])&& !$result) {
                                    $user_name=$_POST['user_name'];
                                    $phone_no=$_POST['phone_no'];
                                    $phone_no2=$_POST['phone_no2'];
                                    $phone_no3=$_POST['phone_no3'];
				
                                
                                
                                    
                                
                                //echo 'phone no is '.$phone_no;
				
				  $query2="select max(id) as max_id from mobile_users";
				 // echo $query2;
				    $result2=mysql_query($query2);
				    while($row2=mysql_fetch_array($result2)){
				      $max_id= $row2['max_id'];
			    
				    }
				
				    $max_id++;
				
				
				


				
				
				//$_POST['meter_no'];
				
					$query="replace into mobile_users
					(id,user_name,phone_no,phone_no2,phone_no3)
					values
					( '$max_id','$user_name','$phone_no','$phone_no2','$phone_no3')";
					
					//echo $query;
					$result1=mysql_query($query)
                                        or die(mysql_error());
				
                                        $result='Mobile User has been inserted successfully ';


                             
				
		}		
		
  ?>
</div>
<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
</div>