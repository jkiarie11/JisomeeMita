<head>

<link rel="stylesheet" href="./jquery-ui-1.10.4/themes/base/jquery.ui.all.css">
<script src="./jquery-ui-1.10.4/jquery-1.10.2.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.core.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.widget.js"></script>
	<script src="./jquery-ui-1.10.4/ui/jquery.ui.datepicker.js"></script>
        
        <script>
	$(function() {
		$( "#datepicker" ).datepicker({
          dateFormat:"dd-mm-yy"
  });
	});
	</script>

</head>

<style>
.labels{
position:absolute;
margin-left:200px;
margin-top:2px;
margin-bottom:2px;




}
#acc_combo{
position:absolute;
margin-left:-20px;
height:20px;
width:300px;
padding:0px;
margin-top:4px;
margin-bottom:2px;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
color:red;

}
#label{
position:relative;
margin-left:100px;
height:20px;
width:320px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#datepicker{
position:relative;
margin-left:100px;
height:20px;
width:320px;
padding:0px;
margin-top:4px;
margin-bottom:2px;

}

#new_acc_fieldset{
/*margin:10px,100px,10px,100px;*/
margin-left:50px;
margin-right:350px;

}
#create_acc_btn{
margin-left:170px;
height:25px;
}
#create_acc_btn:hover{
margin-left:170px;
background-color:#000000;
color:#FFFFFF;
height:25px;

}
#validator{
border:5px ridge  #FFFFFF; left:600px; width:270px; height:45px; background-color:#FFFFFF; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; top:250px; position:absolute;

padding:5px;
background-color:#FF6633;



}
#working_csv{

border:1px solid   #000000; background-color:#CCCCCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; left:20px; position:absolute;
margin-left:-100px;
margin-right:5px;
top:250px;
left:700px;

}
</style>


<style>
.search{
position:absolute;
margin-left:100px;

}
#search_field{
position:absolute;
margin-left:500px;

}
#search_btn{
position:absolute;
margin-left:680px;

}
#search_regulator{
margin-left:145px;
margin-right:100px;
height:50px;

}
</style>


<div id="active_accounts">
<div id="disciplinary">

<?php  
$result="";

function test_req($key, $default = '') {
    if(isset($_REQUEST[$key]) and
       !empty($_REQUEST[$key])) {
        return $_REQUEST[$key];
    } else {
        return $default;
    }
}

$results="Alerts!";

$logged_username = $_SESSION['username'];






//echo $logged_username;
//change to actual user in production
$querynn="select * from billing_settings  ";

$resultnn=mysql_query($querynn);
while($rownn=mysql_fetch_array($resultnn)){
    $id =$rownn['maximum_consumption'];
    $maximum_consumption=$rownn['maximum_consumption'];
    $loan_amount=$rownn['loan_amount'];
    $interest_amount=$rownn['interest_amount'];
    $repayment_period=$rownn['repayment_period'];
    $payments_path=$rownn['payments_path'];
    $standard_charge=$rownn['standard_charge'];
    $billing_month=$rownn['billing_month'];
    $billing_month= substr($billing_month,8,2).'-'.substr($billing_month,5,2).'-'. substr($billing_month,0,4);
    $repayment_amount = $loan_amount/$repayment_period;
    $repayment_amount = round( $repayment_amount, 2, PHP_ROUND_HALF_UP);
    $interest_repayment = $interest_amount/$repayment_period;
    $interest_repayment = round( $interest_repayment, 2, PHP_ROUND_HALF_UP);
    $admin_phoneno1=$rownn['admin_phoneno1'];
    $admin_phoneno2=$rownn['admin_phoneno2'];
    $admin_phoneno3=$rownn['admin_phoneno3'];
    $meter_size=$rownn['default_meter_size'];
    
    




    


}



?>

<div id="create_new_account">




<form action="#" method="post" id="new_acc_fieldset">
<fieldset ><legend>Edit Settings</legend>

	<label for="label" title="Please Enter  Maximum Consumption" class="labels">Maximum Consumption:
        </label><br />
        <input type="text" name="maximum_consumption" id="label" class="text" value="<?php echo htmlentities(test_req('maximum_consumption',$maximum_consumption));   ?>" /><br />
		  
        <label for="label" title="Please Enter The Loan Principal Amount" class="labels">Loan Principal Amount:
        </label><br />
        <input type="text" name="loan_amount" id="label" class="text" value="<?php echo htmlentities(test_req('loan_amount',$loan_amount));?>" /><br />
	
        <label for="label" title="Please Enter The Loan Interest Amount" class="labels">Loan Interest Amount:
        </label><br />
	<input type="text" name="interest_amount" id="label" class="text" value="<?php echo htmlentities(test_req('interest_amount',$interest_amount)); ?>" /><br />
                 
        <label for="label" title="Repayment Period" class="labels">Repayment Period
          </label><br/>
          
          <input type="text" name="repayment_period" id="label" class="text" value="<?php echo htmlentities(test_req('repayment_period',$repayment_period));  ?> " /><br />
      
       
        <label for="label" title="Standard Charge" class="labels">Standard Charge
          </label><br/>
          
          <input type="text" name="standard_charge" id="label" class="text" value="<?php echo htmlentities(test_req('standard_charge',$standard_charge));  ?> " /><br />
<label for="label" title="Default Meter Size" class="labels"> Default Meter Size
          </label><br/>
          
          <input type="text" name="meter_size" id="label" class="text" value="<?php echo htmlentities(test_req('meter_size',$meter_size));  ?> " /><br />

          
                   
          <label for="label" title="Please Enter  Payments Path" class="labels">Payments Path
          </label><br />
		  <input type="text" name="payments_path" id="label" class="text" value="<?php echo htmlentities(test_req('payments_path',$payments_path)); ?>" /><br />
                  
                    <label for="label" title="Please Enter  Payments Path" class="labels">Billing Date
          </label><br />
		  <input type="text" name="billing_month" id="label" class="text" value="<?php echo htmlentities(test_req('billing_month',$billing_month)); ?>" /><br />
    
                  
                   <label for="label" title="Please Enter  Admin phone no 1" class="labels">Admin Phone No
          </label><br />
		  <input type="text" name="admin_phoneno1" id="label" class="text" value="<?php echo htmlentities(test_req('admin_phoneno1',$admin_phoneno1)); ?>" /><br />
                  
                  <label for="label" title="Please Enter  Admin phone no 2" class="labels">Alternate PhoneNo
          </label><br />
		  <input type="text" name="admin_phoneno2" id="label" class="text" value="<?php echo htmlentities(test_req('admin_phoneno2',$admin_phoneno2)); ?>" /><br />
                  <label for="label" title="Please Enter  Admin phone no 3" class="labels">Alternate Phone No
          </label><br />
		  <input type="text" name="admin_phoneno3" id="label" class="text" value="<?php echo htmlentities(test_req('admin_phoneno3',$admin_phoneno3)); ?>" /><br />
                  
                      
           
		  
		  <input type="submit"  name="payments" id="create_acc_btn"  value="Save Settings"  />
         
</fieldset>
</form>

<?php




if(isset($_POST['payments'])) {
	
		$expected = array('maximum_consumption', 'loan_amount','repayment_period');
		$required = array('maximum_consumption', 'loan_amount','repayment_period');
		$missing = array();

			foreach ($_POST as $key => $value) {
			$temp = is_array($value) ? $value : trim($value);
			if (empty($temp) && in_array($key, $required)) {
			array_push($missing, $key);
				}
			elseif (in_array($key, $expected)) {
			${$key} = $temp;
					}
				}
				if(!empty($missing)){
					$result = "Please enter the highlighted values.";
				}
				


				
			}


			
			echo 'result is '.$result;
			////inserting  the payments created 
				if(isset($_POST['maximum_consumption'])&& !$result) {
				$loan_amount=$_POST['loan_amount'];
                                $interest_amount=$_POST['interest_amount'];
                               // echo 'loan amount is '.$loan_amount;
                               	$repayment_period=$_POST['repayment_period'];
				$maximum_consumption=$_POST['maximum_consumption'];
                                $payments_path=$_POST['payments_path'];
                                $standard_charge=$_POST['standard_charge'];
                                $billing_month=$_POST['billing_month'];
                                $admin_phoneno1=$_POST['admin_phoneno1'];
                                $admin_phoneno2=$_POST['admin_phoneno2'];
                                $admin_phoneno3=$_POST['admin_phoneno3'];
                                $meter_size=$_POST['meter_size'];
                                
                                $save_bill_month=substr($billing_month,6,4).'-'.substr($billing_month,3,2).'-'.substr($billing_month,0,2);
                                
                                
				
				////////////////////////
				$query="select count(*) from user where password='$pass' and  username='$user'";
				
				//password='$pass' and
				$result=mysql_query($query);
				$count=mysql_result($result,0,0);
				/////////////////////
				
				
				

				
				
				


				
				
				//$_POST['meter_no'];
				
					$query="replace into billing_settings
					(id,maximum_consumption,loan_amount, repayment_period,payments_path,standard_charge,billing_month,interest_amount,admin_phoneno1,admin_phoneno2,admin_phoneno3,default_meter_size)
					values
					( 1,'$maximum_consumption','$loan_amount', '$repayment_period', '$payments_path', '$standard_charge', '$save_bill_month','$interest_amount','$admin_phoneno1','$admin_phoneno2','$admin_phoneno3','$meter_size')";
					
					//echo $query;
					$result1=mysql_query($query)
				or die(mysql_error());
				
				$result='Your settings have been updated successfully ';


	
				
		}		
		
  ?>
</div>
<div id="validator">

<?php if($result!=""){$results=""; echo $result;} else{  $result=""; echo $results; } ?>
</div>